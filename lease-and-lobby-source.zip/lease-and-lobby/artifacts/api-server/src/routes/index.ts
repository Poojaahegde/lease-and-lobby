import { Router, type IRouter } from "express";
import healthRouter from "./health";
import portalRouter from "./portal";
import onboardingRouter from "./onboarding";
import actionsRouter from "./actions";
import maintenanceRouter from "./maintenance";
import amenitiesRouter from "./amenities";
import storageRouter from "./privateStorage";

const router: IRouter = Router();

router.use(healthRouter);
router.use(portalRouter);
router.use(onboardingRouter);
router.use(actionsRouter);
router.use(storageRouter);
router.use(maintenanceRouter);
router.use(amenitiesRouter);

export default router;
