import { Router, type IRouter } from "express";
import { and, desc, eq, inArray, isNotNull, or } from "drizzle-orm";
import {
  chargeQuestions,
  contentReports,
  db,
  documents,
  eventRsvps,
  events,
  households,
  invitations,
  leases,
  listingMessages,
  listings,
  memberships,
  notices,
  payments,
  properties,
  propertyPhotos,
  rentAccounts,
  rentStatements,
  units,
} from "@workspace/db";
import {
  GetDemoResponse,
  GetPortalQueryParams,
  GetPortalResponse,
  GetSessionResponse,
} from "@workspace/api-zod";
import {
  getClerkIdentity,
  getMembershipsForUser,
  publicMembership,
  requireAuth,
  signedInUserId,
  type MembershipContext,
} from "../lib/leaseLobbyAuth";

const router: IRouter = Router();

function getInvitationStatus(invitation: typeof invitations.$inferSelect): string {
  if (invitation.status === "pending" && invitation.expiresAt.getTime() <= Date.now()) {
    return "expired";
  }
  return invitation.status;
}

router.get("/session", requireAuth, async (req, res): Promise<void> => {
  const userId = signedInUserId(res);
  const [user, activeMemberships, anyProperty] = await Promise.all([
    getClerkIdentity(userId),
    getMembershipsForUser(userId),
    db.select({ id: properties.id }).from(properties).limit(1),
  ]);
  const response = GetSessionResponse.parse({
    user: {
      id: user.userId,
      email: user.email,
      displayName: user.displayName,
      emailVerified: user.emailVerified,
    },
    memberships: activeMemberships.map(publicMembership),
    setupAvailable:
      user.emailVerified && !!process.env.LEASE_LOBBY_SETUP_EMAIL &&
      user.email === process.env.LEASE_LOBBY_SETUP_EMAIL.trim().toLowerCase() &&
      anyProperty.length === 0,
  });
  res.json(response);
});

router.get("/portal", requireAuth, async (req, res): Promise<void> => {
  const parsed = GetPortalQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid property selection.", code: "INVALID_PROPERTY" });
    return;
  }

  const userId = signedInUserId(res);
  const [identity, activeMemberships] = await Promise.all([
    getClerkIdentity(userId),
    getMembershipsForUser(userId),
  ]);
  const propertyId = parsed.data.propertyId;
  const eligibleMemberships = propertyId
    ? activeMemberships.filter((membership) => membership.propertyId === propertyId)
    : activeMemberships;

  if (propertyId && eligibleMemberships.length === 0) {
    res.status(403).json({ error: "You do not have active access to this property.", code: "NO_PROPERTY_ACCESS" });
    return;
  }

  if (eligibleMemberships.length === 0) {
    const [propertyCount] = await db.select({ id: properties.id }).from(properties).limit(1);
    const response = GetPortalResponse.parse({
      mode: "setup",
      session: {
        user: {
          id: identity.userId,
          email: identity.email,
          displayName: identity.displayName,
          emailVerified: identity.emailVerified,
        },
        memberships: [],
        setupAvailable:
          !!process.env.LEASE_LOBBY_SETUP_EMAIL &&
          identity.email === process.env.LEASE_LOBBY_SETUP_EMAIL.trim().toLowerCase() &&
          !propertyCount,
      },
      property: null,
      membership: null,
      unit: null,
      rent: {},
      lease: {},
      documents: [],
      chargeQuestions: [],
      notices: [],
      events: [],
      listings: [],
      gallery: [],
      managerQueue: [],
      invitations: [],
      settings: {},
    });
    res.json(response);
    return;
  }

  const selectedMembership =
    eligibleMemberships.find((membership) => membership.role === "building_owner") ??
    eligibleMemberships.find((membership) => membership.role === "building_manager") ??
    eligibleMemberships[0];
  const propertyRows = await db
    .select()
    .from(properties)
    .where(eq(properties.id, selectedMembership.propertyId))
    .limit(1);
  const property = propertyRows[0];
  if (!property) {
    res.status(404).json({ error: "Property not found.", code: "PROPERTY_NOT_FOUND" });
    return;
  }

  // Every role, household and message used below must belong to the selected property.
  const propertyMemberships = eligibleMemberships.filter(
    (membership) => membership.propertyId === property.id,
  );
  const residentMembership = propertyMemberships.find(
    (membership) => membership.role === "resident" && membership.householdId,
  );
  const hasManagementRole = propertyMemberships.some(
    (membership) => membership.role === "building_owner" || membership.role === "building_manager",
  );
  const canManageInvitations = propertyMemberships.some(
    (membership) => membership.role === "building_manager",
  );
  const householdId = residentMembership?.householdId ?? null;
  const [
    unitRows,
    rentRows,
    leaseRows,
    documentRows,
    questionRows,
    noticeRows,
    eventRows,
    listingRows,
    photoRows,
    invitationRows,
  ] = await Promise.all([
    residentMembership?.unitId
      ? db.select().from(units).where(eq(units.id, residentMembership.unitId)).limit(1)
      : Promise.resolve([]),
    householdId
      ? db.select().from(rentAccounts).where(eq(rentAccounts.householdId, householdId)).limit(1)
      : Promise.resolve([]),
    householdId
      ? db.select().from(leases).where(eq(leases.householdId, householdId)).orderBy(desc(leases.createdAt)).limit(1)
      : Promise.resolve([]),
    householdId
      ? db.select().from(documents).where(eq(documents.householdId, householdId)).orderBy(desc(documents.createdAt))
      : Promise.resolve([]),
    householdId
      ? db.select().from(chargeQuestions).where(eq(chargeQuestions.householdId, householdId)).orderBy(desc(chargeQuestions.createdAt))
      : Promise.resolve([]),
    db.select().from(notices).where(and(eq(notices.propertyId, property.id), isNotNull(notices.publishedAt))).orderBy(desc(notices.publishedAt)),
    db.select().from(events).where(eq(events.propertyId, property.id)).orderBy(events.startsAt),
    db.select().from(listings).where(eq(listings.propertyId, property.id)).orderBy(desc(listings.createdAt)),
    db.select().from(propertyPhotos).where(
      hasManagementRole
        ? eq(propertyPhotos.propertyId, property.id)
        : and(eq(propertyPhotos.propertyId, property.id), eq(propertyPhotos.published, true)),
    ).orderBy(propertyPhotos.sortIndex),
    canManageInvitations
      ? db.select().from(invitations).where(eq(invitations.propertyId, property.id)).orderBy(desc(invitations.createdAt))
      : Promise.resolve([]),
  ]);

  const rentAccount = rentRows[0];
  const [paymentRows, statementRows, rsvpRows] = await Promise.all([
    rentAccount
      ? db.select().from(payments).where(eq(payments.rentAccountId, rentAccount.id)).orderBy(desc(payments.createdAt))
      : Promise.resolve([]),
    rentAccount
      ? db.select().from(rentStatements).where(eq(rentStatements.rentAccountId, rentAccount.id)).orderBy(desc(rentStatements.statementDate))
      : Promise.resolve([]),
    db.select().from(eventRsvps).where(
      residentMembership
        ? inArray(
            eventRsvps.eventId,
            eventRows.map((event) => event.id),
          )
        : inArray(eventRsvps.eventId, []),
    ),
  ]);
  const membershipIds = propertyMemberships.map((membership) => membership.id);
  const messageRows = membershipIds.length
    ? await db.select().from(listingMessages).where(
        or(
          inArray(listingMessages.senderMembershipId, membershipIds),
          inArray(listingMessages.recipientMembershipId, membershipIds),
        ),
      ).orderBy(desc(listingMessages.createdAt))
    : [];

  const managerQueue: Array<Record<string, unknown>> = [];
  if (hasManagementRole) {
    const [pendingDocuments, openQuestions, pendingEvents, openReports, pendingPayments] = await Promise.all([
      db.select().from(documents).where(and(eq(documents.propertyId, property.id), inArray(documents.status, ["received", "under_review"]))),
      db.select().from(chargeQuestions).where(and(eq(chargeQuestions.propertyId, property.id), eq(chargeQuestions.status, "open"))),
      db.select().from(events).where(and(eq(events.propertyId, property.id), eq(events.status, "pending"))),
      db.select().from(contentReports).where(and(eq(contentReports.propertyId, property.id), eq(contentReports.status, "open"))),
      db.select().from(rentAccounts).where(and(eq(rentAccounts.propertyId, property.id), eq(rentAccounts.status, "pending"))),
    ]);
    managerQueue.push(
      ...pendingDocuments.map((item) => ({ id: item.id, type: "document_review", status: item.status, task: item.title, objectPath: item.objectPath, nextAction: "Review document" })),
      ...openQuestions.map((item) => ({ id: item.id, type: "rent_question", status: item.status, task: item.chargeLabel, description: item.question, nextAction: "Reply to resident" })),
      ...pendingEvents.map((item) => ({ id: item.id, type: "event_approval", status: item.status, task: item.title, nextAction: "Approve event" })),
      ...openReports.map((item) => ({ id: item.id, type: "content_report", status: item.status, task: `${item.contentType} report`, nextAction: "Review report" })),
      ...pendingPayments.map((item) => ({ id: item.id, type: "payment_confirmation", status: item.status, task: "Demo rent payment", nextAction: "Confirm or fail payment" })),
    );
  }

  const staffUnits = canManageInvitations
    ? await db.select({ id: units.id, label: units.label }).from(units).where(eq(units.propertyId, property.id)).orderBy(units.label)
    : [];
  const roster = hasManagementRole
    ? await db.select({ id: memberships.id, email: memberships.email, role: memberships.role, displayName: memberships.displayName })
      .from(memberships).where(and(eq(memberships.propertyId, property.id), eq(memberships.active, true),
        inArray(memberships.role, canManageInvitations ? ["building_manager", "resident"] : ["building_manager"])))
    : [];

  const response = GetPortalResponse.parse({
    mode: selectedMembership.role,
    session: {
      user: {
        id: identity.userId,
        email: identity.email,
        displayName: identity.displayName,
        emailVerified: identity.emailVerified,
      },
      memberships: propertyMemberships.map(publicMembership),
      setupAvailable: false,
    },
    property: {
      id: property.id,
      name: property.name,
      address: property.address,
      city: property.city,
      region: property.region,
      postalCode: property.postalCode,
      description: property.description,
      coverPhotoPath: property.coverPhotoPath,
      published: property.published,
    },
    membership: publicMembership(selectedMembership),
    unit: unitRows[0] ? { id: unitRows[0].id, label: unitRows[0].label } : null,
    rent: rentAccount
      ? {
          ...rentAccount,
          payments: paymentRows,
          statements: statementRows,
        }
      : {},
    lease: leaseRows[0] ?? {},
    documents: documentRows,
    chargeQuestions: questionRows,
    notices: noticeRows.filter((notice) => notice.publishedAt !== null),
    events: (property.settings.eventsEnabled ? eventRows : [])
      .filter((event) => event.status === "approved" || event.hostMembershipId === selectedMembership.id)
      .map((event) => ({
        ...event,
        attendeeCount: rsvpRows.filter((rsvp) => rsvp.eventId === event.id && rsvp.status === "going").length,
        isGoing: rsvpRows.some(
          (rsvp) =>
            rsvp.eventId === event.id &&
            rsvp.membershipId === residentMembership?.id &&
            rsvp.status === "going",
        ),
      })),
    listings: (property.settings.marketplaceEnabled ? listingRows : [])
      .filter((listing) => listing.status !== "sold" || hasManagementRole || listing.ownerMembershipId === residentMembership?.id || messageRows.some((message) => message.listingId === listing.id))
      .map((listing) => ({
        ...listing,
        messages: messageRows.filter((message) => message.listingId === listing.id),
      })),
    gallery: photoRows,
    managerQueue,
    invitations: invitationRows.map((invitation) => ({
      id: invitation.id,
      email: invitation.email,
      unitId: invitation.unitId,
      unitLabel: propertyMemberships
        .find((membership) => membership.unitId === invitation.unitId)?.unitLabel ?? "",
      status: getInvitationStatus(invitation),
      expiresAt: invitation.expiresAt,
      createdAt: invitation.createdAt,
    })),
    settings: { ...property.settings, ...(hasManagementRole ? { units: staffUnits, roster } : {}) },
  });
  res.json(response);
});

router.get("/demo", (_req, res): void => {
  const demo = GetDemoResponse.parse({
    mode: "demo",
    session: {
      user: {
        id: "demo-maya",
        email: "maya@example.test",
        displayName: "Maya Chen",
        emailVerified: true,
      },
      memberships: [{
        id: "demo-resident",
        propertyId: "willow-court-demo",
        propertyName: "Willow Court",
        unitId: "demo-unit-3b",
        unitLabel: "Apartment 3B",
        householdId: "demo-household",
        role: "resident",
        active: true,
      }],
      setupAvailable: false,
    },
    property: {
      id: "willow-court-demo",
      name: "Willow Court",
      address: "48 Garden Street",
      city: "Portland",
      region: "OR",
      postalCode: "97205",
      description: "A friendly apartment community in the heart of Portland.",
      coverPhotoPath: null,
      published: true,
    },
    membership: {
      id: "demo-resident",
      propertyId: "willow-court-demo",
      propertyName: "Willow Court",
      unitId: "demo-unit-3b",
      unitLabel: "Apartment 3B",
      householdId: "demo-household",
      role: "resident",
      active: true,
    },
    unit: { id: "demo-unit-3b", label: "Apartment 3B" },
    rent: {
      balanceCents: 214500,
      dueDate: "2026-11-01",
      status: "due",
      lastMonthCents: 210000,
      charges: [
        { label: "November base rent", amountCents: 210000 },
        { label: "Utility charge", amountCents: 4500 },
      ],
    },
    lease: {
      startDate: "2026-12-01",
      endDate: "2027-11-30",
      monthlyRentCents: 214500,
      proposedRentCents: 214500,
      renewalDeadline: "2026-11-15",
      renewalStatus: "pending",
    },
    documents: [{
      id: "demo-insurance",
      title: "Proof of renters insurance",
      category: "insurance",
      status: "needs_replacement",
      reason: "The policy expiration date is missing.",
      expiresAt: null,
    }],
    notices: [
      { id: "demo-notice-urgent", title: "Water service interruption", summary: "Water will be briefly off in the east wing tomorrow, 10–11 AM, for scheduled maintenance.", urgent: true, publishedAt: new Date().toISOString(), sender: "From management" },
      { id: "demo-notice-routine", title: "Package room hours updated", summary: "The package room is now open until 8 PM on weekdays.", urgent: false, publishedAt: "2026-10-24T12:00:00.000Z", sender: "From management" },
    ],
    events: [{ id: "demo-game-night", title: "Game night", description: "Bring a favorite game or just come by.", startsAt: "2026-11-06T19:00:00.000Z", location: "Community room", status: "approved", attendeeCount: 4, isGoing: false }],
    listings: [{ id: "demo-oak-desk", title: "Oak desk", description: "Good condition · pickup in the lobby", priceCents: 3000, status: "available" }],
    gallery: [],
    managerQueue: [],
    invitations: [],
    settings: { eventsEnabled: true, marketplaceEnabled: true, residentPostingEnabled: true, eventApprovalRequired: false },
  });
  res.json(demo);
});

export default router;
