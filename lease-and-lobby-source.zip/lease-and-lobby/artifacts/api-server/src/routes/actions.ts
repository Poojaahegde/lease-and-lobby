import { clerkClient } from "@clerk/express";
import { Router, type IRouter } from "express";
import type { PgColumn } from "drizzle-orm/pg-core";
import { and, count, eq, gt, isNotNull, or, sql } from "drizzle-orm";
import { chargeQuestions, contentReports, db, documents, eventRsvps, events, invitations, listingMessages, listings, memberships, notices, portalUploads, properties, propertyPhotos, rentAccounts, units } from "@workspace/db";
import { z } from "zod";
import { findMembership, getClerkIdentity, requireAuth, signedInUserId } from "../lib/leaseLobbyAuth";

const router: IRouter = Router();
const uuid = z.string().uuid();
const actionInput = z.object({
  propertyId: uuid, action: z.string(), targetId: uuid.optional(),
  data: z.record(z.unknown()).default({}),
});
const label = z.string().trim().min(1).max(160);
const body = z.string().trim().min(1).max(2000);
const eventInput = z.object({
  title: label, description: body, startsAt: z.string().datetime(), location: label,
  capacity: z.preprocess((value) => value === "" || value == null ? null : Number(value), z.number().int().min(1).max(1000).nullable()),
});
const listingInput = z.object({
  title: label, description: body, condition: label.default("Good"),
  price: z.coerce.number().min(0).max(100000).default(0),
});
const listingStatus = z.enum(["available", "reserved", "sold"]);
const done = { success: true, message: "Your update was saved." };

router.post("/manager/actions", requireAuth, async (req, res) => {
  const parsed = actionInput.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Check the action details." }); return; }
  const { propertyId, action, targetId, data } = parsed.data;
  const userId = signedInUserId(res);
  const owner = await findMembership(userId, propertyId, ["building_owner"]);
  const manager = await findMembership(userId, propertyId, ["building_manager"]);
  if (!owner && !manager) { res.status(403).json({ error: "You do not manage this property." }); return; }
  const reject = (status: number, error: string) => res.status(status).json({ error });
  const ok = () => res.json(done);
  const scope = (table: { id: PgColumn; propertyId: PgColumn }, id: string) =>
    and(eq(table.id, id), eq(table.propertyId, propertyId));
  if (action === "assign_manager" && owner) {
    const email = z.string().trim().toLowerCase().email().safeParse(data.email);
    if (!email.success) { reject(400, "Enter a valid email."); return; }
    const matching = await clerkClient.users.getUserList({ emailAddress: [email.data], limit: 2 });
    if (matching.data.length !== 1) { reject(409, "Ask the manager to create and verify their staff account first."); return; }
    const identity = await getClerkIdentity(matching.data[0].id);
    if (!identity.emailVerified || identity.email !== email.data) { reject(409, "That account must verify this email as its primary address."); return; }
    await db.insert(memberships).values({
      userId: identity.userId, email: identity.email, displayName: identity.displayName, propertyId, role: "building_manager",
    }).onConflictDoUpdate({ target: [memberships.propertyId, memberships.userId, memberships.role], set: { active: true } });
    ok(); return;
  }
  if (action === "remove_membership" && targetId) {
    const roles = [...(owner ? ["building_manager" as const] : []), ...(manager ? ["resident" as const] : [])];
    const [target] = await db.select().from(memberships).where(scope(memberships, targetId));
    if (!target || target.role === "building_owner" || !roles.includes(target.role)) { reject(403, "Your role cannot revoke this membership."); return; }
    await db.update(memberships).set({ active: false }).where(scope(memberships, targetId));
    ok(); return;
  }
  if (action === "create_unit" && manager) {
    const input = label.safeParse(data.label);
    if (!input.success) { reject(400, "Enter a unit label."); return; }
    await db.insert(units).values({ propertyId, label: input.data }).onConflictDoNothing();
    ok(); return;
  }
  if (action === "revoke_invitation" && manager && targetId) {
    const [revoked] = await db.update(invitations).set({ status: "revoked" }).where(and(scope(invitations, targetId), eq(invitations.status, "pending"))).returning();
    if (!revoked) { reject(404, "There is no pending invitation to revoke."); return; }
    ok(); return;
  }
  if (action === "update_property") {
    const input = z.object({ name: label, address: label, city: label, region: label, postalCode: label, description: z.string().max(2000) }).safeParse(data);
    if (!input.success) { reject(400, "Enter the property details."); return; }
    await db.update(properties).set(input.data).where(eq(properties.id, propertyId));
    ok(); return;
  }
  if (action === "publish_property") {
    await db.update(properties).set({ published: true }).where(eq(properties.id, propertyId));
    ok(); return;
  }
  if (action === "update_features") {
    const timeZone = z.string().trim().max(80).refine((value) => {
      try { new Intl.DateTimeFormat("en", { timeZone: value }); return true; }
      catch { return false; }
    });
    const input = z.object({
      eventsEnabled: z.boolean(), marketplaceEnabled: z.boolean(),
      residentPostingEnabled: z.boolean(), eventApprovalRequired: z.boolean(),
      amenities: z.array(z.enum(["party_room", "pool_area", "bbq_area"])).max(3).optional(),
      amenityTimeZone: timeZone.optional(),
    }).safeParse(data);
    if (!input.success) { reject(400, "Check the building features and enter a valid time zone, such as America/Los_Angeles."); return; }
    await db.update(properties).set({
      settings: sql`${properties.settings} || ${JSON.stringify(input.data)}::jsonb`,
    }).where(eq(properties.id, propertyId));
    ok(); return;
  }
  if (action === "save_photo") {
    const input = z.object({
      objectPath: uuid, location: z.enum(["entrance", "leasing_desk", "noticeboard", "community_room", "courtyard", "swap_shelf", "gallery"]).default("gallery"),
      altText: label, caption: z.string().trim().max(250).default(""),
    }).safeParse(data);
    if (!input.success) { reject(400, "Choose a photo and enter descriptive alt text."); return; }
    const { objectPath, ...metadata } = input.data;
    const staff = owner ?? manager!;
    const saved = await db.transaction(async (tx) => {
      const [upload] = await tx.update(portalUploads).set({ attached: true }).where(and(
        eq(portalUploads.id, objectPath), eq(portalUploads.propertyId, propertyId),
        or(eq(portalUploads.membershipId, staff.id), eq(portalUploads.membershipId, manager?.id ?? staff.id)),
        eq(portalUploads.purpose, "property_photo"), eq(portalUploads.attached, false),
        gt(portalUploads.expiresAt, new Date()), isNotNull(portalUploads.data),
      )).returning({ id: portalUploads.id });
      if (!upload) return false;
      await tx.insert(propertyPhotos).values({ propertyId, objectPath, ...metadata, uploadedByMembershipId: staff.id });
      return true;
    });
    if (!saved) { reject(409, "Upload the image again before saving."); return; }
    ok(); return;
  }
  if (action === "publish_photos" && targetId) {
    const saved = await db.transaction(async (tx) => {
      const [photo] = await tx.update(propertyPhotos).set({ published: true }).where(scope(propertyPhotos, targetId)).returning();
      if (!photo) return false;
      if (data.cover === true) await tx.update(properties).set({ coverPhotoPath: photo.objectPath }).where(eq(properties.id, propertyId));
      return true;
    });
    if (!saved) { reject(404, "Photo not found."); return; }
    ok(); return;
  }
  if (action === "delete_photo" && targetId) {
    const removed = await db.transaction(async (tx) => {
      const [photo] = await tx.delete(propertyPhotos).where(scope(propertyPhotos, targetId)).returning();
      if (!photo) return false;
      await tx.update(properties).set({ coverPhotoPath: null }).where(and(eq(properties.id, propertyId), eq(properties.coverPhotoPath, photo.objectPath)));
      const id = uuid.safeParse(photo.objectPath);
      if (id.success) await tx.delete(portalUploads).where(and(eq(portalUploads.id, id.data), eq(portalUploads.propertyId, propertyId)));
      return true;
    });
    if (!removed) { reject(404, "Photo not found."); return; }
    ok(); return;
  }
  if (action === "create_notice" && manager) {
    const input = z.object({ title: label, body, importance: z.string().optional() }).safeParse(data);
    if (!input.success) { reject(400, "Enter a notice title and details."); return; }
    await db.insert(notices).values({ propertyId, createdByMembershipId: manager.id, title: input.data.title, summary: input.data.body, urgent: input.data.importance === "important", publishedAt: new Date() });
    ok(); return;
  }
  if (action === "approve_event" && manager && targetId) {
    const [updated] = await db.update(events).set({ status: "approved" }).where(and(scope(events, targetId), eq(events.status, "pending"))).returning();
    if (!updated) { reject(404, "There is no event awaiting approval."); return; }
    ok(); return;
  }
  if (action === "reply_charge_question" && manager && targetId) {
    const reply = body.safeParse(data.reply);
    if (!reply.success) { reject(400, "Enter a reply."); return; }
    const [updated] = await db.update(chargeQuestions).set({ reply: reply.data, repliedAt: new Date(), status: "answered" }).where(scope(chargeQuestions, targetId)).returning();
    if (!updated) { reject(404, "Charge question not found."); return; }
    ok(); return;
  }
  if (action === "review_report" && manager && targetId) {
    const [updated] = await db.update(contentReports).set({ status: "reviewed" }).where(scope(contentReports, targetId)).returning();
    if (!updated) { reject(404, "Report not found."); return; }
    ok(); return;
  }
  if (action === "review_document" && manager && targetId) {
    const input = z.object({ status: z.enum(["accepted", "under_review", "needs_replacement"]), reason: z.string().trim().max(2000).default("") }).safeParse(data);
    if (!input.success || (input.data.status === "needs_replacement" && !input.data.reason)) { reject(400, "Choose a status and give a reason for a replacement."); return; }
    const [updated] = await db.update(documents).set({ ...input.data, reviewedByMembershipId: manager.id }).where(scope(documents, targetId)).returning();
    if (!updated) { reject(404, "Document not found."); return; }
    ok(); return;
  }
  reject(403, "This action is unavailable for your role or configuration.");
});

router.post("/resident/actions", requireAuth, async (req, res) => {
  const parsed = actionInput.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Check the action details." }); return; }
  const { propertyId, action, targetId, data } = parsed.data;
  const userId = signedInUserId(res);
  const resident = await findMembership(userId, propertyId, ["resident"]);
  if (!resident?.householdId) { res.status(403).json({ error: "You need an active resident assignment in this property." }); return; }
  const [property] = await db.select().from(properties).where(eq(properties.id, propertyId));
  const reject = (status: number, error: string) => res.status(status).json({ error });
  const ok = () => res.json(done);
  const settings = property.settings;
  if (["create_event", "update_event", "cancel_event", "rsvp_event", "cancel_rsvp"].includes(action) && !settings.eventsEnabled ||
      ["create_listing", "update_listing", "send_listing_message"].includes(action) && !settings.marketplaceEnabled ||
      ["create_event", "create_listing"].includes(action) && !settings.residentPostingEnabled) {
    reject(403, "This feature is disabled for your building."); return;
  }
  if (action === "create_event" || action === "update_event") {
    const input = eventInput.safeParse(data);
    if (!input.success || new Date(input.data.startsAt) <= new Date()) { reject(400, "Enter a title, location and future date."); return; }
    const values = { ...input.data, startsAt: new Date(input.data.startsAt), status: settings.eventApprovalRequired ? "pending" as const : "approved" as const };
    if (action === "create_event") await db.insert(events).values({ ...values, propertyId, hostMembershipId: resident.id });
    else {
      if (!targetId) { reject(400, "Choose an event."); return; }
      const [updated] = await db.update(events).set(values).where(and(eq(events.id, targetId), eq(events.propertyId, propertyId), eq(events.hostMembershipId, resident.id))).returning();
      if (!updated) { reject(404, "Event not found."); return; }
    }
    ok(); return;
  }
  if (action === "cancel_event" && targetId) {
    const [updated] = await db.update(events).set({ status: "cancelled" }).where(and(eq(events.id, targetId), eq(events.propertyId, propertyId), eq(events.hostMembershipId, resident.id))).returning();
    if (!updated) { reject(404, "Event not found."); return; }
    ok(); return;
  }
  if ((action === "rsvp_event" || action === "cancel_rsvp") && targetId) {
    const going = action === "rsvp_event";
    const problem = await db.transaction(async (tx) => {
      const [event] = await tx.select().from(events).where(and(eq(events.id, targetId), eq(events.propertyId, propertyId))).for("update");
      if (!event || event.status !== "approved" || (going && event.startsAt <= new Date())) return "This event is unavailable.";
      const [existing] = await tx.select().from(eventRsvps).where(and(eq(eventRsvps.eventId, targetId), eq(eventRsvps.membershipId, resident.id)));
      if (going && existing?.status !== "going" && event.capacity !== null) {
        const [total] = await tx.select({ count: count() }).from(eventRsvps).where(and(eq(eventRsvps.eventId, targetId), eq(eventRsvps.status, "going")));
        if (total.count >= event.capacity) return "This event is full.";
      }
      const status = going ? "going" : "cancelled";
      await tx.insert(eventRsvps).values({ eventId: targetId, membershipId: resident.id, status }).onConflictDoUpdate({ target: [eventRsvps.eventId, eventRsvps.membershipId], set: { status } });
      return null;
    });
    if (problem) { reject(409, problem); return; }
    ok(); return;
  }
  if (action === "create_listing") {
    const input = listingInput.safeParse(data);
    if (!input.success) { reject(400, "Enter listing details and a valid price."); return; }
    const { price, ...details } = input.data;
    await db.insert(listings).values({ ...details, propertyId, ownerMembershipId: resident.id, priceCents: Math.round(price * 100) });
    ok(); return;
  }
  if (action === "update_listing" && targetId) {
    const input = listingStatus.safeParse(data.status);
    const details = listingInput.safeParse(data);
    if (!input.success && !details.success) { reject(400, "Check listing details or status."); return; }
    const fields = details.success ? {
      title: details.data.title, description: details.data.description, condition: details.data.condition,
      priceCents: Math.round(details.data.price * 100),
    } : { status: input.data };
    const [updated] = await db.update(listings).set({ ...fields, updatedAt: new Date() }).where(and(eq(listings.id, targetId), eq(listings.propertyId, propertyId), eq(listings.ownerMembershipId, resident.id))).returning();
    if (!updated) { reject(404, "Listing not found."); return; }
    ok(); return;
  }
  if (action === "send_listing_message" && targetId) {
    const message = body.safeParse(data.body);
    if (!message.success) { reject(400, "Enter a message."); return; }
    const [listing] = await db.select().from(listings).where(and(eq(listings.id, targetId), eq(listings.propertyId, propertyId)));
    if (!listing) { reject(404, "Listing not found."); return; }
    let recipient = listing.ownerMembershipId;
    if (recipient === resident.id) {
      const replyTo = uuid.safeParse(data.replyTo);
      if (!replyTo.success) { reject(400, "Choose a conversation to reply to."); return; }
      const [prior] = await db.select().from(listingMessages).where(and(eq(listingMessages.id, replyTo.data), eq(listingMessages.listingId, targetId), eq(listingMessages.recipientMembershipId, resident.id)));
      if (!prior) { reject(404, "Conversation not found."); return; }
      recipient = prior.senderMembershipId;
    }
    const [active] = await db.select().from(memberships).where(and(eq(memberships.id, recipient), eq(memberships.propertyId, propertyId), eq(memberships.active, true)));
    if (!active) { reject(409, "That neighbor’s account is no longer available."); return; }
    await db.insert(listingMessages).values({ listingId: targetId, senderMembershipId: resident.id, recipientMembershipId: recipient, body: message.data });
    ok(); return;
  }
  if (action === "report_content" && targetId) {
    const input = z.object({ contentType: z.enum(["event", "listing"]), reason: body }).safeParse(data);
    if (!input.success) { reject(400, "Enter a reason for the report."); return; }
    const type = input.data.contentType;
    if (!(type === "event" ? settings.eventsEnabled : settings.marketplaceEnabled)) { reject(403, "This feature is disabled."); return; }
    const visible = type === "event"
      ? await db.select({ id: events.id }).from(events).where(and(eq(events.id, targetId), eq(events.propertyId, propertyId), or(eq(events.status, "approved"), eq(events.hostMembershipId, resident.id))))
      : await db.select({ id: listings.id }).from(listings).where(and(eq(listings.id, targetId), eq(listings.propertyId, propertyId)));
    if (!visible.length) { reject(404, "Content not found."); return; }
    await db.insert(contentReports).values({ propertyId, contentId: targetId, reporterMembershipId: resident.id, ...input.data });
    ok(); return;
  }
  if (action === "submit_document" && targetId) {
    const input = uuid.safeParse(data.objectPath);
    if (!input.success) { reject(400, "Upload a valid document first."); return; }
    const householdId = resident.householdId;
    const saved = await db.transaction(async (tx) => {
      const [document] = await tx.select().from(documents).where(and(eq(documents.id, targetId), eq(documents.propertyId, propertyId), eq(documents.householdId, householdId))).for("update");
      if (!document || !["requested", "needs_replacement"].includes(document.status)) return false;
      const [upload] = await tx.update(portalUploads).set({ attached: true }).where(and(
        eq(portalUploads.id, input.data), eq(portalUploads.propertyId, propertyId),
        eq(portalUploads.membershipId, resident.id), eq(portalUploads.purpose, "resident_document"),
        eq(portalUploads.attached, false), gt(portalUploads.expiresAt, new Date()), isNotNull(portalUploads.data),
      )).returning({ id: portalUploads.id });
      if (!upload) return false;
      await tx.update(documents).set({ objectPath: input.data, status: "received", submittedAt: new Date() }).where(eq(documents.id, targetId));
      return true;
    });
    if (!saved) { reject(409, "This request or upload is no longer available. Refresh and try again."); return; }
    ok(); return;
  }
  if (action === "ask_charge_question") {
    const input = z.object({ subject: label, message: body }).safeParse(data);
    if (!input.success) { reject(400, "Enter a subject and a question."); return; }
    const [account] = await db.select().from(rentAccounts).where(and(eq(rentAccounts.propertyId, propertyId), eq(rentAccounts.householdId, resident.householdId)));
    if (!account) { reject(409, "Your household does not have a rent account yet."); return; }
    await db.insert(chargeQuestions).values({ propertyId, rentAccountId: account.id, householdId: resident.householdId, askedByUserId: userId, chargeLabel: input.data.subject, question: input.data.message });
    ok(); return;
  }
  reject(403, "This action is unavailable for your role or configuration.");
});

export default router;
