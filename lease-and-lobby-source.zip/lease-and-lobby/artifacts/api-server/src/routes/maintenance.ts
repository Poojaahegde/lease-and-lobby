import { Router, type IRouter, type Request } from "express";
import { and, desc, eq, gt, isNotNull } from "drizzle-orm";
import { db, maintenanceRequests, portalUploads, units } from "@workspace/db";
import { z } from "zod";
import { findMembership, requireAuth, signedInUserId } from "../lib/leaseLobbyAuth";

const router: IRouter = Router();
const uuid = z.string().uuid();
const staffRoles = ["building_manager", "building_owner"] as const;
const statuses = ["submitted", "in_progress", "completed"] as const;
const categories: Record<string, readonly string[]> = {
  Plumbing: ["Leak", "Drain or toilet", "No hot water"],
  Electrical: ["Outlet or switch", "Lighting", "Power issue"],
  "Heating & cooling": ["No heat", "No cooling", "Thermostat"],
  Appliances: ["Refrigerator", "Oven or stove", "Dishwasher", "Washer or dryer"],
  "Doors & windows": ["Lock or handle", "Door", "Window"],
  "Pest control": ["Insects", "Rodents", "Other pests"],
  "General repairs": ["Walls or ceiling", "Flooring", "Other"],
};
const complaintCategories = ["Noise", "Pet waste", "Smoking or vaping", "Shared spaces", "Parking", "Other"];
const documentCategories = ["Signed lease", "Lease addendum", "Rent statement", "Payment receipt", "Proof of residency", "Other"];
function requestKind(req: Request) {
  if (req.path.startsWith("/document-requests/")) return "document";
  return req.path.startsWith("/complaints/") ? "complaint" : "maintenance";
}
const collectionPaths = ["/maintenance/:propertyId", "/complaints/:propertyId", "/document-requests/:propertyId"];
const inputSchema = z.object({
  id: uuid,
  category: z.string().max(80),
  issue: z.string().max(80),
  location: z.string().trim().max(120),
  description: z.string().trim().min(10).max(1500),
  priority: z.enum(["routine", "low", "medium", "high", "urgent"]),
  entryAllowed: z.boolean(),
  accessInstructions: z.string().trim().max(500),
  photoId: uuid.optional(),
});

router.get(collectionPaths, requireAuth, async (req, res) => {
  const id = uuid.safeParse(req.params.propertyId);
  if (!id.success) { res.sendStatus(400); return; }
  const userId = signedInUserId(res);
  const staffView = req.query.view === "staff";
  const member = await findMembership(userId, id.data, staffView ? [...staffRoles] : ["resident"]);
  if (!member || (!staffView && !member.householdId)) { res.sendStatus(403); return; }
  const kind = requestKind(req);
  const scope = and(eq(maintenanceRequests.propertyId, id.data), eq(maintenanceRequests.kind, kind));
  const residentScope = kind !== "maintenance"
    ? eq(maintenanceRequests.submittedBy, member.id)
    : eq(maintenanceRequests.householdId, member.householdId!);
  const rows = await db.select({
    id: maintenanceRequests.id, category: maintenanceRequests.category, issue: maintenanceRequests.issue,
    location: maintenanceRequests.location, description: maintenanceRequests.description,
    priority: maintenanceRequests.priority, entryAllowed: maintenanceRequests.entryAllowed,
    accessInstructions: maintenanceRequests.accessInstructions, photoId: maintenanceRequests.photoId,
    documentId: maintenanceRequests.documentId, managementResponse: maintenanceRequests.managementResponse,
    status: maintenanceRequests.status, createdAt: maintenanceRequests.createdAt,
    updatedAt: maintenanceRequests.updatedAt, unitLabel: units.label,
  }).from(maintenanceRequests).innerJoin(units, eq(units.id, maintenanceRequests.unitId))
    .where(staffView ? scope : and(scope, residentScope))
    .orderBy(desc(maintenanceRequests.createdAt));
  const types = kind === "document" ? documentCategories : complaintCategories;
  res.json({ requests: rows, categories: kind === "maintenance" ? categories : Object.fromEntries(types.map((name) => [name, []])) });
});

router.post(collectionPaths, requireAuth, async (req, res) => {
  const id = uuid.safeParse(req.params.propertyId);
  const parsed = inputSchema.safeParse(req.body);
  if (!id.success || !parsed.success) { res.status(400).json({ error: "Check the request details." }); return; }
  const kind = requestKind(req);
  const { category, issue } = parsed.data;
  const valid = kind === "maintenance"
    ? Object.hasOwn(categories, category) && categories[category].includes(issue)
    : (kind === "document" ? documentCategories : complaintCategories).includes(category) && issue.trim().length > 0 && !parsed.data.photoId;
  if (!valid) { res.status(400).json({ error: "Check the category and issue details." }); return; }
  const member = await findMembership(signedInUserId(res), id.data, ["resident"]);
  if (!member?.householdId || !member.unitId) { res.sendStatus(403); return; }
  const { photoId, ...input } = parsed.data;
  const saved = await db.transaction(async (tx) => {
    const [created] = await tx.insert(maintenanceRequests).values({
      ...input, kind, issue: issue.trim(),
      priority: kind !== "maintenance" || input.priority === "routine" ? "medium" : input.priority,
      entryAllowed: kind !== "maintenance" ? false : input.entryAllowed,
      accessInstructions: kind !== "maintenance" ? "" : input.accessInstructions,
      propertyId: id.data, householdId: member.householdId!, unitId: member.unitId!, submittedBy: member.id,
    }).onConflictDoNothing().returning({ id: maintenanceRequests.id });
    if (!created) {
      const [existing] = await tx.select({ id: maintenanceRequests.id }).from(maintenanceRequests).where(and(
        eq(maintenanceRequests.id, input.id), eq(maintenanceRequests.kind, kind), eq(maintenanceRequests.propertyId, id.data), eq(maintenanceRequests.submittedBy, member.id),
      ));
      return Boolean(existing);
    }
    if (!photoId) return true;
    const [photo] = await tx.update(portalUploads).set({ attached: true }).where(and(
      eq(portalUploads.id, photoId), eq(portalUploads.propertyId, id.data), eq(portalUploads.membershipId, member.id),
      eq(portalUploads.purpose, "maintenance_photo"), eq(portalUploads.attached, false),
      gt(portalUploads.expiresAt, new Date()), isNotNull(portalUploads.data),
    )).returning({ id: portalUploads.id });
    if (!photo) {
      await tx.delete(maintenanceRequests).where(eq(maintenanceRequests.id, created.id));
      return false;
    }
    await tx.update(maintenanceRequests).set({ photoId }).where(eq(maintenanceRequests.id, created.id));
    return true;
  });
  if (!saved) { res.status(409).json({ error: "The request could not be saved. Check the photo and try again." }); return; }
  res.status(201).json({ id: input.id });
});

router.patch(collectionPaths.map((path) => path + "/:requestId"), requireAuth, async (req, res) => {
  const id = uuid.safeParse(req.params.propertyId);
  const requestId = uuid.safeParse(req.params.requestId);
  const input = z.object({
    status: z.enum(statuses),
    documentId: uuid.optional(),
    managementResponse: z.string().trim().min(1).max(1500).optional(),
  }).safeParse(req.body);
  if (!id.success || !requestId.success || !input.success) { res.sendStatus(400); return; }
  const member = await findMembership(signedInUserId(res), id.data, [...staffRoles]);
  if (!member) { res.sendStatus(403); return; }
  const kind = requestKind(req);
  const { status, documentId, managementResponse } = input.data;
  if (managementResponse !== undefined && kind !== "complaint") {
    res.status(400).json({ error: "Management responses are available on complaints." }); return;
  }
  const delivering = kind === "document" && status === "completed";
  if (delivering !== Boolean(documentId)) {
    res.status(400).json({ error: "Attach a PDF to complete a document request." }); return;
  }
  const scope = and(eq(maintenanceRequests.propertyId, id.data), eq(maintenanceRequests.kind, kind), eq(maintenanceRequests.id, requestId.data));
  const result = await db.transaction(async (tx) => {
    const [item] = await tx.select({ documentId: maintenanceRequests.documentId }).from(maintenanceRequests).where(scope).for("update");
    if (!item) return 404;
    if (item.documentId) return documentId === item.documentId ? 204 : 409;
    if (documentId) {
      const [file] = await tx.update(portalUploads).set({ attached: true }).where(and(
        eq(portalUploads.id, documentId), eq(portalUploads.propertyId, id.data), eq(portalUploads.membershipId, member.id),
        eq(portalUploads.purpose, "requested_document"), eq(portalUploads.attached, false),
        gt(portalUploads.expiresAt, new Date()), isNotNull(portalUploads.data),
      )).returning({ id: portalUploads.id });
      if (!file) return 409;
    }
    await tx.update(maintenanceRequests).set({
      status, documentId, managementResponse, updatedAt: new Date(),
    }).where(scope);
    return 204;
  });
  if (result === 409) { res.status(409).json({ error: "Refresh the request and check whether a document has already been shared." }); return; }
  if (result === 404) { res.sendStatus(404); return; }
  res.sendStatus(204);
});

export default router;
