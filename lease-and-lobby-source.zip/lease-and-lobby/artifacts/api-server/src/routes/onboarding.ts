import { getAuth } from "@clerk/express";
import { createHash, randomBytes } from "node:crypto";
import { Router, type IRouter } from "express";
import { and, eq, sql } from "drizzle-orm";
import { db, households, invitations, memberships, properties, units } from "@workspace/db";
import { getClerkIdentity, findMembership, requireAuth, signedInUserId } from "../lib/leaseLobbyAuth";
import { z } from "zod";

const router: IRouter = Router();
const hash = (token: string) => createHash("sha256").update(token).digest("hex");
const uuid = z.string().uuid();
const email = z.string().trim().toLowerCase().email().max(254);
const label = z.string().trim().min(1).max(160);
const lookup = z.string().regex(/^[a-f0-9]{64}$/);
const publicInvite = (invite: typeof invitations.$inferSelect, unitLabel: string) => ({
  id: invite.id, email: invite.email, unitId: invite.unitId, unitLabel,
  status: invite.status === "pending" && invite.expiresAt <= new Date() ? "expired" : invite.status,
  expiresAt: invite.expiresAt, createdAt: invite.createdAt,
});

router.post("/setup/property", requireAuth, async (req, res) => {
  const identity = await getClerkIdentity(signedInUserId(res));
  if (!identity.emailVerified || identity.email !== process.env.LEASE_LOBBY_SETUP_EMAIL?.trim().toLowerCase()) {
    res.status(403).json({ error: "Property setup requires the authorized, verified administrator." });
    return;
  }
  const input = z.object({
    name: label, address: label, city: label, region: label, postalCode: label,
    description: z.string().trim().max(2000), unitLabels: z.array(label).min(1).max(500),
  }).safeParse(req.body);
  if (!input.success) { res.status(400).json({ error: "Check the property details and unit labels." }); return; }
  const { unitLabels, ...details } = input.data;
  const property = await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(71311201)`);
    if ((await tx.select({ id: properties.id }).from(properties).limit(1)).length) return null;
    const [created] = await tx.insert(properties).values(details).returning();
    await tx.insert(units).values([...new Set(unitLabels)].map((label) => ({ propertyId: created.id, label })));
    await tx.insert(memberships).values({
      userId: identity.userId, email: identity.email, displayName: identity.displayName,
      propertyId: created.id, role: "building_owner",
    });
    return created;
  });
  if (!property) { res.status(409).json({ error: "Initial property setup has already been completed." }); return; }
  res.status(201).json({ success: true, message: "Your property is ready." });
});

router.get("/manager/invitations", requireAuth, async (req, res) => {
  const propertyId = uuid.safeParse(req.query.propertyId);
  if (!propertyId.success) { res.status(400).json({ error: "Choose a property." }); return; }
  if (!await findMembership(signedInUserId(res), propertyId.data, ["building_manager"])) {
    res.status(403).json({ error: "Only the assigned building manager can view resident invitations." }); return;
  }
  const records = await db.select({ invite: invitations, unit: units.label }).from(invitations)
    .innerJoin(units, eq(units.id, invitations.unitId)).where(eq(invitations.propertyId, propertyId.data));
  res.json(records.map(({ invite, unit }) => publicInvite(invite, unit)));
});

router.post("/manager/invitations", requireAuth, async (req, res) => {
  const input = z.object({ propertyId: uuid, unitId: uuid, email }).safeParse(req.body);
  if (!input.success) { res.status(400).json({ error: "Choose a unit and enter a valid email." }); return; }
  const { propertyId, unitId, email: invitedEmail } = input.data;
  const manager = await findMembership(signedInUserId(res), propertyId, ["building_manager"]);
  if (!manager) { res.status(403).json({ error: "Only the assigned building manager can invite residents." }); return; }
  const origin = process.env.LEASE_LOBBY_ORIGIN;
  if (!origin) { res.status(503).json({ error: "Set LEASE_LOBBY_ORIGIN before creating invitation links." }); return; }
  const token = randomBytes(32).toString("hex");
  const inviteUrl = new URL("/activate", origin);
  inviteUrl.searchParams.set("token", token);
  const result = await db.transaction(async (tx) => {
    // Lock the unit so replacement and household creation serialize.
    const [unit] = await tx.select().from(units).where(and(eq(units.id, unitId), eq(units.propertyId, propertyId))).for("update");
    if (!unit) return null;
    await tx.insert(households).values({ propertyId, unitId }).onConflictDoNothing({ target: households.unitId });
    const [household] = await tx.select().from(households).where(eq(households.unitId, unitId));
    await tx.update(invitations).set({ status: "revoked" }).where(and(
      eq(invitations.propertyId, propertyId), eq(invitations.unitId, unitId),
      eq(invitations.email, invitedEmail), eq(invitations.status, "pending"),
    ));
    const [invite] = await tx.insert(invitations).values({
      tokenHash: hash(token), propertyId, unitId, householdId: household.id,
      email: invitedEmail, invitedBy: manager.id, expiresAt: new Date(Date.now() + 7 * 86400000),
    }).returning();
    return publicInvite(invite, unit.label);
  });
  if (!result) { res.status(404).json({ error: "That unit does not belong to this property." }); return; }
  res.status(201).json({ invitation: result, inviteUrl, emailStatus: "not_configured", message: "Invitation created. Copy the private link." });
});

const unavailable = {
  pending: "Sign in with the invited email to join your building.",
  expired: "This invitation has expired. Ask your leasing office for a new link.",
  revoked: "This link is no longer active. Ask your leasing office for the latest invitation.",
  accepted: "This invitation has been used. Sign in with the account you joined with.",
} as const;

router.get("/invitations/:token", async (req, res) => {
  res.set("Cache-Control", "no-store");
  const token = lookup.safeParse(req.params.token);
  const [record] = token.success ? await db.select({ invite: invitations, property: properties })
    .from(invitations).innerJoin(properties, eq(properties.id, invitations.propertyId))
    .where(eq(invitations.tokenHash, hash(token.data))) : [];
  const status = record ? publicInvite(record.invite, "").status : "revoked";
  const userId = getAuth(req).userId;
  let unitLabel: string | null = null;
  if (record && status === "pending" && userId) {
    const identity = await getClerkIdentity(userId);
    if (!identity.emailVerified || identity.email !== record.invite.email) {
      res.json({ valid: false, status: "email_mismatch", message: "Sign out and use the verified email your leasing office invited." });
      return;
    }
    const [unit] = await db.select({ label: units.label }).from(units).where(eq(units.id, record.invite.unitId));
    unitLabel = unit?.label ?? null;
  }
  const property = record?.property;
  res.json({
    valid: status === "pending", status, unitLabel, message: unavailable[status],
    property: status === "pending" && property ? {
      id: property.id, name: property.name, address: property.address, city: property.city,
      region: property.region, postalCode: property.postalCode, description: property.description,
      published: property.published,
    } : null,
    expiresAt: status === "pending" ? record?.invite.expiresAt : null,
  });
});

router.post("/invitations/:token/accept", requireAuth, async (req, res) => {
  const token = lookup.safeParse(req.params.token);
  if (!token.success) { res.status(409).json({ error: unavailable.revoked }); return; }
  const identity = await getClerkIdentity(signedInUserId(res));
  const result = await db.transaction(async (tx) => {
    const [invite] = await tx.select().from(invitations).where(eq(invitations.tokenHash, hash(token.data))).for("update");
    if (!invite) return unavailable.revoked;
    const status = publicInvite(invite, "").status;
    if (status !== "pending") return unavailable[status];
    if (!identity.emailVerified || identity.email !== invite.email) return "Verify and sign in with the email your manager invited.";
    const [membership] = await tx.insert(memberships).values({
      userId: identity.userId, email: identity.email, displayName: identity.displayName,
      propertyId: invite.propertyId, unitId: invite.unitId, householdId: invite.householdId, role: "resident",
    }).onConflictDoUpdate({
      target: [memberships.propertyId, memberships.userId, memberships.role],
      set: { active: true, email: identity.email, displayName: identity.displayName },
      setWhere: and(eq(memberships.active, false), eq(memberships.householdId, invite.householdId)),
    }).returning({ id: memberships.id });
    if (!membership) return "You already have an assignment here. Ask your leasing office to review your access.";
    await tx.update(invitations).set({ status: "accepted", acceptedAt: new Date() }).where(eq(invitations.id, invite.id));
    return null;
  });
  if (result) { res.status(409).json({ error: result }); return; }
  res.json({ success: true, message: "Welcome to your building." });
});

export default router;
