import { Router, type IRouter } from "express";
import { and, eq, gte, lt } from "drizzle-orm";
import { amenityBookings, db, properties } from "@workspace/db";
import { z } from "zod";
import { findMembership, requireAuth, signedInUserId } from "../lib/leaseLobbyAuth";

const router: IRouter = Router();
const uuid = z.string().uuid();
const amenity = z.enum(["party_room", "pool_area", "bbq_area"]);
const path = "/amenities/:propertyId";
const date = z.string().regex(/^20\d{2}-\d{2}-\d{2}$/).refine((value) => {
  const parsed = new Date(value);
  return Number.isFinite(parsed.valueOf()) && parsed.toISOString().slice(0, 10) === value;
});

function buildingClock(timeZone: string) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", hourCycle: "h23",
  }).formatToParts(new Date());
  const part = (type: string) => parts.find((item) => item.type === type)?.value;
  return { today: `${part("year")}-${part("month")}-${part("day")}`, hour: Number(part("hour")), timeZone };
}

router.get(path, requireAuth, async (req, res) => {
  const id = uuid.safeParse(req.params.propertyId);
  const month = z.string().regex(/^20\d{2}-(0[1-9]|1[0-2])$/).safeParse(req.query.month);
  if (!id.success || !month.success) { res.sendStatus(400); return; }
  const member = await findMembership(signedInUserId(res), id.data, ["resident"]);
  if (!member) { res.sendStatus(403); return; }
  const [property] = await db.select({ settings: properties.settings }).from(properties).where(eq(properties.id, id.data));
  if (!property) { res.sendStatus(404); return; }
  const enabled = property.settings.amenities ?? [];
  const first = `${month.data}-01`;
  const next = new Date(first);
  next.setUTCMonth(next.getUTCMonth() + 1);
  const bookings = await db.select().from(amenityBookings).where(and(
    eq(amenityBookings.propertyId, id.data), gte(amenityBookings.day, first), lt(amenityBookings.day, next.toISOString().slice(0, 10)),
  ));
  res.json({
    amenities: enabled, ...buildingClock(property.settings.amenityTimeZone || "UTC"),
    bookings: bookings.filter((item) => enabled.includes(item.amenity) || item.membershipId === member.id).map((item) => ({
      amenity: item.amenity, day: item.day, slot: item.slot,
      ...(item.membershipId === member.id ? { id: item.id } : {}),
    })),
  });
});

router.post(path, requireAuth, async (req, res) => {
  const id = uuid.safeParse(req.params.propertyId);
  const input = z.object({ amenity, day: date, slot: z.number().int().min(0).max(3) }).safeParse(req.body);
  if (!id.success || !input.success) { res.status(400).json({ error: "Choose a valid space, date, and time." }); return; }
  const member = await findMembership(signedInUserId(res), id.data, ["resident"]);
  if (!member) { res.sendStatus(403); return; }
  const [property] = await db.select({ settings: properties.settings }).from(properties).where(eq(properties.id, id.data));
  if (!property?.settings.amenities?.includes(input.data.amenity)) {
    res.status(403).json({ error: "This amenity is not open for reservations." }); return;
  }
  const { today, hour } = buildingClock(property.settings.amenityTimeZone || "UTC");
  const max = new Date(today);
  max.setUTCDate(max.getUTCDate() + 90);
  const { day, slot } = input.data;
  if (day < today || day > max.toISOString().slice(0, 10) || (day === today && 9 + slot * 3 <= hour)) {
    res.status(400).json({ error: "Choose a future time within the next 90 days." }); return;
  }
  const [booking] = await db.insert(amenityBookings).values({
    propertyId: id.data, membershipId: member.id, ...input.data,
  }).onConflictDoNothing().returning({ id: amenityBookings.id });
  if (!booking) { res.status(409).json({ error: "That time is already booked. Choose another time." }); return; }
  res.status(201).json(booking);
});

router.delete(path + "/:bookingId", requireAuth, async (req, res) => {
  const id = uuid.safeParse(req.params.propertyId);
  const bookingId = uuid.safeParse(req.params.bookingId);
  if (!id.success || !bookingId.success) { res.sendStatus(400); return; }
  const member = await findMembership(signedInUserId(res), id.data, ["resident"]);
  if (!member) { res.sendStatus(403); return; }
  const [removed] = await db.delete(amenityBookings).where(and(
    eq(amenityBookings.id, bookingId.data), eq(amenityBookings.propertyId, id.data), eq(amenityBookings.membershipId, member.id),
  )).returning({ id: amenityBookings.id });
  if (!removed) { res.sendStatus(404); return; }
  res.sendStatus(204);
});

export default router;
