import { Router, raw, type IRouter } from "express";
import { and, eq, gt, isNull } from "drizzle-orm";
import { db, documents, maintenanceRequests, portalUploads, properties, propertyPhotos } from "@workspace/db";
import { z } from "zod";
import { findMembership, getMembershipsForUser, requireAuth, signedInUserId } from "../lib/leaseLobbyAuth";

const router: IRouter = Router();
const uuid = z.string().uuid();
const maxBytes = 10 * 1024 * 1024;
const photoTypes = ["image/jpeg", "image/png", "image/webp"];
const roles = {
  property_photo: ["building_owner", "building_manager"],
  resident_document: ["resident"],
  maintenance_photo: ["resident"],
  requested_document: ["building_owner", "building_manager"],
} as const;

function hasMagic(bytes: Buffer, mime: string): boolean {
  if (mime === "image/jpeg") return bytes.subarray(0, 3).equals(Buffer.from([255, 216, 255]));
  if (mime === "image/png") return bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
  if (mime === "image/webp") return bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP";
  return mime === "application/pdf" && bytes.toString("ascii", 0, 5) === "%PDF-";
}

router.post("/storage/upload-url", requireAuth, async (req, res) => {
  const input = z.object({
    propertyId: uuid, purpose: z.enum(["property_photo", "resident_document", "maintenance_photo", "requested_document"]),
    contentType: z.string(), size: z.number().int().min(1).max(maxBytes),
  }).safeParse(req.body);
  if (!input.success) { res.status(400).json({ error: "Choose a supported file under 10 MB." }); return; }
  const { propertyId, purpose, contentType, size } = input.data;
  const supported = purpose === "requested_document"
    ? contentType === "application/pdf"
    : photoTypes.includes(contentType) || (purpose === "resident_document" && contentType === "application/pdf");
  if (!supported) {
    res.status(400).json({ error: "This file format is unsupported." }); return;
  }
  const member = await findMembership(signedInUserId(res), propertyId, [...roles[purpose]]);
  if (!member) { res.status(403).json({ error: "You do not have permission to upload this file." }); return; }
  const origin = process.env.LEASE_LOBBY_ORIGIN;
  if (!origin) { res.status(503).json({ error: "Uploads require LEASE_LOBBY_ORIGIN." }); return; }
  const expiresInSeconds = 600;
  const [object] = await db.insert(portalUploads).values({
    propertyId, purpose, contentType, size, membershipId: member.id,
    expiresAt: new Date(Date.now() + expiresInSeconds * 1000),
  }).returning({ id: portalUploads.id });
  res.json({ objectPath: object.id, uploadURL: new URL(`/api/storage/upload/${object.id}`, origin).toString(), expiresInSeconds });
});

router.put("/storage/upload/:id", requireAuth, raw({ type: [...photoTypes, "application/pdf"], limit: maxBytes }), async (req, res) => {
  const id = uuid.safeParse(req.params.id);
  if (!id.success) { res.sendStatus(404); return; }
  const [object] = await db.select({ propertyId: portalUploads.propertyId, membershipId: portalUploads.membershipId,
    purpose: portalUploads.purpose, contentType: portalUploads.contentType, size: portalUploads.size })
    .from(portalUploads).where(and(eq(portalUploads.id, id.data), isNull(portalUploads.data), gt(portalUploads.expiresAt, new Date())));
  if (!object) { res.sendStatus(404); return; }
  const allowed = (await getMembershipsForUser(signedInUserId(res))).some((member) => member.id === object.membershipId && member.propertyId === object.propertyId);
  if (!allowed) { res.sendStatus(403); return; }
  if (!Buffer.isBuffer(req.body) || req.body.length !== object.size || !hasMagic(req.body, object.contentType)) {
    res.status(400).json({ error: "File bytes do not match the expected image or document." }); return;
  }
  const [saved] = await db.update(portalUploads).set({ data: req.body }).where(and(eq(portalUploads.id, id.data), isNull(portalUploads.data), gt(portalUploads.expiresAt, new Date()))).returning({ id: portalUploads.id });
  res.sendStatus(saved ? 204 : 409);
});

router.get("/storage/object", requireAuth, async (req, res) => {
  const id = uuid.safeParse(req.query.objectPath);
  if (!id.success) { res.sendStatus(404); return; }
  const [object] = await db.select({ propertyId: portalUploads.propertyId, purpose: portalUploads.purpose }).from(portalUploads)
    .where(and(eq(portalUploads.id, id.data), eq(portalUploads.attached, true)));
  if (!object) { res.sendStatus(404); return; }
  const members = (await getMembershipsForUser(signedInUserId(res))).filter((member) => member.propertyId === object.propertyId);
  const staff = members.some((member) => member.role !== "resident");
  if (!members.length) { res.sendStatus(403); return; }
  let allowed = false;
  if (object.purpose === "property_photo") {
    const [photo] = await db.select().from(propertyPhotos).where(and(eq(propertyPhotos.objectPath, id.data), eq(propertyPhotos.propertyId, object.propertyId)));
    const [property] = await db.select({ cover: properties.coverPhotoPath }).from(properties).where(eq(properties.id, object.propertyId));
    allowed = !!photo && (staff || photo.published || property?.cover === id.data);
  } else if (object.purpose === "requested_document") {
    const [request] = await db.select({ submittedBy: maintenanceRequests.submittedBy }).from(maintenanceRequests)
      .where(and(eq(maintenanceRequests.documentId, id.data), eq(maintenanceRequests.propertyId, object.propertyId), eq(maintenanceRequests.kind, "document")));
    allowed = !!request && (staff || members.some((member) => member.role === "resident" && member.id === request.submittedBy));
  } else if (object.purpose === "maintenance_photo") {
    const [request] = await db.select({ householdId: maintenanceRequests.householdId }).from(maintenanceRequests)
      .where(and(eq(maintenanceRequests.photoId, id.data), eq(maintenanceRequests.propertyId, object.propertyId)));
    allowed = !!request && (staff || members.some((member) => member.role === "resident" && member.householdId === request.householdId));
  } else {
    const [document] = await db.select().from(documents).where(and(eq(documents.objectPath, id.data), eq(documents.propertyId, object.propertyId)));
    allowed = !!document && (staff || members.some((member) => member.role === "resident" && member.householdId === document.householdId));
  }
  if (!allowed) { res.sendStatus(403); return; }
  const [file] = await db.select({ bytes: portalUploads.data, mime: portalUploads.contentType }).from(portalUploads).where(eq(portalUploads.id, id.data));
  if (!file?.bytes) { res.sendStatus(404); return; }
  res.set("Cache-Control", "private, no-store").set("X-Content-Type-Options", "nosniff").type(file.mime);
  if (file.mime === "application/pdf") res.attachment("resident-document.pdf").type(file.mime);
  res.send(file.bytes);
});

export default router;
