import { getAuth, clerkClient } from "@clerk/express";
import type { Request, RequestHandler, Response } from "express";
import { and, eq } from "drizzle-orm";
import { db, memberships, properties, units } from "@workspace/db";

export type ClerkIdentity = {
  userId: string;
  email: string;
  displayName: string;
  emailVerified: boolean;
};

export type MembershipContext = {
  id: string;
  userId: string;
  email: string;
  displayName: string;
  propertyId: string;
  unitId: string | null;
  householdId: string | null;
  role: "building_owner" | "building_manager" | "resident";
  active: boolean;
  propertyName: string;
  unitLabel: string | null;
};

export const requireAuth: RequestHandler = (req, res, next) => {
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Sign in to continue.", code: "UNAUTHORIZED" });
    return;
  }
  res.locals.userId = userId;
  next();
};

export function signedInUserId(res: Response): string {
  const userId = res.locals.userId;
  if (typeof userId !== "string") {
    throw new Error("Authenticated user ID is missing.");
  }
  return userId;
}

export async function getClerkIdentity(userId: string): Promise<ClerkIdentity> {
  const user = await clerkClient.users.getUser(userId);
  const primary = user.emailAddresses.find(
    (address) => address.id === user.primaryEmailAddressId,
  );
  const email = primary?.emailAddress.trim().toLowerCase() ?? "";
  return {
    userId,
    email,
    displayName:
      [user.firstName, user.lastName].filter(Boolean).join(" ").trim() ||
      user.username ||
      email,
    emailVerified: primary?.verification?.status === "verified",
  };
}

export async function getMembershipsForUser(
  userId: string,
): Promise<MembershipContext[]> {
  const rows = await db
    .select({
      id: memberships.id,
      userId: memberships.userId,
      email: memberships.email,
      displayName: memberships.displayName,
      propertyId: memberships.propertyId,
      unitId: memberships.unitId,
      householdId: memberships.householdId,
      role: memberships.role,
      active: memberships.active,
      propertyName: properties.name,
      unitLabel: units.label,
    })
    .from(memberships)
    .innerJoin(properties, eq(memberships.propertyId, properties.id))
    .leftJoin(units, eq(memberships.unitId, units.id))
    .where(and(eq(memberships.userId, userId), eq(memberships.active, true)));
  return rows as MembershipContext[];
}

export function publicMembership(
  membership: MembershipContext,
): {
  id: string;
  propertyId: string;
  propertyName: string;
  unitId: string | null;
  unitLabel: string | null;
  householdId: string | null;
  role: MembershipContext["role"];
  active: boolean;
} {
  return {
    id: membership.id,
    propertyId: membership.propertyId,
    propertyName: membership.propertyName,
    unitId: membership.unitId,
    unitLabel: membership.unitLabel,
    householdId: membership.householdId,
    role: membership.role,
    active: membership.active,
  };
}

export async function findMembership(
  userId: string,
  propertyId: string,
  roles?: MembershipContext["role"][],
): Promise<MembershipContext | undefined> {
  const rows = await getMembershipsForUser(userId);
  return rows.find(
    (membership) =>
      membership.propertyId === propertyId &&
      (!roles || roles.includes(membership.role)),
  );
}

export async function findPropertyMemberships(
  userId: string,
  propertyId: string,
): Promise<MembershipContext[]> {
  const rows = await getMembershipsForUser(userId);
  return rows.filter((membership) => membership.propertyId === propertyId);
}
