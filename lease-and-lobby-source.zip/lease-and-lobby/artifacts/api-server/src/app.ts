import express, { type Express, type ErrorRequestHandler } from "express";
import pinoHttp from "pino-http";
import { clerkMiddleware } from "@clerk/express";
import { publishableKeyFromHost } from "@clerk/shared/keys";
import router from "./routes";
import { logger } from "./lib/logger";
import {
  CLERK_PROXY_PATH,
  clerkProxyMiddleware,
} from "./middlewares/clerkProxyMiddleware";

const app: Express = express();
const configuredOrigin = process.env.LEASE_LOBBY_ORIGIN?.trim();
if (!configuredOrigin && process.env.NODE_ENV === "production") {
  throw new Error("LEASE_LOBBY_ORIGIN is required in production.");
}
const portalUrl = new URL(configuredOrigin || "http://127.0.0.1:4173");
const localHost = ["127.0.0.1", "localhost", "[::1]"].includes(portalUrl.hostname);
if (
  (portalUrl.protocol !== "https:" && !(portalUrl.protocol === "http:" && localHost && process.env.NODE_ENV !== "production")) ||
  portalUrl.href !== portalUrl.origin + "/"
) {
  throw new Error("LEASE_LOBBY_ORIGIN must be the public HTTPS origin or a local development origin.");
}

app.disable("x-powered-by");

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0].replace(/(\/invitations\/)[^/]+/gi, "$1[redacted]"),
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use("/api", (req, res, next) => {
  res.set({
    "Cache-Control": "no-store",
    "Referrer-Policy": "no-referrer",
    "X-Content-Type-Options": "nosniff",
  });
  const origin = req.get("Origin");
  if (origin && origin !== portalUrl.origin) {
    res.status(403).json({ error: "Origin is not allowed.", code: "ORIGIN_NOT_ALLOWED" });
    return;
  }
  next();
});

app.use(CLERK_PROXY_PATH, clerkProxyMiddleware(portalUrl.origin));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(
  clerkMiddleware({
    publishableKey: process.env.CLERK_PUBLISHABLE_KEY || publishableKeyFromHost(portalUrl.hostname),
    authorizedParties: [portalUrl.origin],
  }),
);

app.use("/api", router);

const handleError: ErrorRequestHandler = (error, _req, res, next) => {
  if (res.headersSent) {
    next(error);
    return;
  }
  const status = error?.status === 413 ? 413 : error?.status === 400 ? 400 : 500;
  if (status === 500) logger.error({ requestId: res.req.id }, "API request failed");
  res.status(status).json({
    error: status === 413 ? "Request is too large." : status === 400 ? "Invalid request body." : "The server could not complete this request.",
  });
};
app.use(handleError);

export default app;
