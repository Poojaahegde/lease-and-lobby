import Amenities, { amenityOptions, demoBookings, localDay, type Booking } from './components/amenities';
import Maintenance, { type MaintenanceRequest } from './components/maintenance';
import { demoSnapshot } from './lib/demo';
import { useEffect, useRef, useState, type CSSProperties, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ClerkProvider, SignIn, SignUp, useAuth, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import {
  useAcceptInvitation, useCreateInitialProperty, useCreateInvitation,
  useGetInvitation, useGetPortal, useGetPrivateObject, useGetSession,
  useListInvitations, useRequestUploadUrl, useRunManagerAction, useRunResidentAction,
} from '@workspace/api-client-react';
import {
  getGetInvitationQueryKey, getGetPortalQueryKey,
  getGetSessionQueryKey, getListInvitationsQueryKey,
} from '@workspace/api-client-react';
import {
  ArrowRight, Bell, Building2, CalendarDays, Check, CheckCircle2,
  ChevronDown, ChevronLeft, ChevronRight, CircleHelp, CreditCard, FileText, Home, Image, KeyRound, LogOut,
  Menu, MessageCircle, Plus, RotateCcw, ShieldCheck, ShoppingBag, Users, Wallet,
  Wrench, X,
} from 'lucide-react';
import { Link, Redirect, Route, Router as WouterRouter, Switch, useLocation, useSearch } from 'wouter';
import type { ActionInputAction, Invitation, Membership, PortalSnapshot, Property, SessionResponse } from '@workspace/api-client-react';

const dollars = (cents: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 2 }).format(cents / 100);
const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const hostname = window.location.hostname;
const isLoopback = ['localhost', '127.0.0.1', '[::1]'].includes(hostname);
const configuredClerkKey = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY?.trim();
const portfolioDemo = import.meta.env.VITE_PORTFOLIO_DEMO === 'true';
const clerkPubKey = portfolioDemo ? undefined : isLoopback ? configuredClerkKey : publishableKeyFromHost(hostname, configuredClerkKey);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#592a49',
    colorForeground: '#29202a',
    colorMutedForeground: '#727b73',
    colorDanger: '#9f5d45',
    colorBackground: '#fffdfb',
    colorInput: '#fffdf7',
    colorInputForeground: '#29202a',
    colorNeutral: '#29202a',
    fontFamily: 'DM Sans',
    borderRadius: '0.75rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#fffdfb] rounded-2xl w-[440px] max-w-full overflow-hidden',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#29372f] font-semibold',
    headerSubtitle: 'text-[#727b73]',
    socialButtonsBlockButtonText: 'text-[#29372f] font-medium',
    formFieldLabel: 'text-[#46564a] font-medium',
    footerActionLink: 'text-[#592a49] font-semibold',
    footerActionText: 'text-[#727b73]',
    dividerText: 'text-[#727b73]',
    identityPreviewEditButton: 'text-[#592a49]',
    formFieldSuccessText: 'text-[#315b43]',
    alertText: 'text-[#814d3a]',
    logoBox: 'rounded-xl',
    logoImage: 'max-h-10',
    socialButtonsBlockButton: 'border-[#ded8cc] bg-[#fffdf7]',
    formButtonPrimary: 'bg-[#592a49] hover:bg-[#442038]',
    formFieldInput: 'bg-[#fffdf7] border-[#ddd8cd] text-[#29372f]',
    footerAction: 'bg-transparent',
    dividerLine: 'bg-[#e7e1d6]',
    alert: 'bg-[#f5e5dc] border-[#edd4c7]',
    otpCodeFieldInput: 'border-[#d8d3c8] text-[#29372f]',
    formFieldRow: 'text-[#46564a]',
    main: 'bg-transparent',
  },
};

type Dict = Record<string, unknown>;
const asRecord = (value: unknown): Dict => value && typeof value === 'object' ? value as Dict : {};
const rows = (value: unknown): Dict[] => Array.isArray(value) ? value.map(asRecord) : [];
const valueOf = (obj: Dict, keys: string[], fallback = ''): string => {
  for (const key of keys) {
    const value = obj[key];
    if (typeof value === 'string' && value.trim()) return value;
    if (typeof value === 'number') return String(value);
  }
  return fallback;
};
const fmtDate = (value: string) => {
  const date = new Date(/^\d{4}-\d{2}-\d{2}$/.test(value) ? value + 'T12:00:00' : value);
  return Number.isNaN(date.valueOf()) ? value : new Intl.DateTimeFormat(undefined, { dateStyle: 'medium' }).format(date);
};
const localDateTime = (value: unknown) => {
  const date = new Date(String(value));
  if (Number.isNaN(date.getTime())) return '';
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
};
const roleHome = (membership: Membership) => membership.role === 'building_owner' ? '/owner' : membership.role === 'building_manager' ? '/manager' : '/resident';
const homeLinks = [
  { label: 'Home', path: '/resident', icon: Home },
  { label: 'Rent', path: '/rent', icon: Wallet },
  { label: 'Documents', path: '/documents', icon: FileText },
  { label: 'Lobby', path: '/lobby', icon: Building2 },
  { label: 'Maintenance', path: '/maintenance', icon: Wrench },
  { label: 'Complaints', path: '/complaints', icon: MessageCircle },
  { label: 'Profile', path: '/profile', icon: Users },
];
const primaryHomeLinks = homeLinks.filter(({ path }) => path !== '/maintenance' && path !== '/complaints');

function Brand() {
  return <Link className="ll-brand" href="/" aria-label="Lease and Lobby home">
    <img width={40} height={40} src={`${basePath}/logo.svg`} alt="" />
    <strong>Lease & Lobby</strong>
  </Link>;
}
function PageHead({ kicker, title, children }: { kicker: string; title: string; children?: ReactNode }) {
  return <header className="ll-page-head"><p className="ll-kicker">{kicker}</p><h1 className="ll-title">{title}</h1>{children && <p className="ll-subtitle">{children}</p>}</header>;
}
function Button({ children, onClick, variant = '', type = 'button', disabled = false }: { children: ReactNode; onClick?: () => void; variant?: string; type?: 'button' | 'submit'; disabled?: boolean }) {
  return <button data-testid="button-action" className={`ll-btn ${variant}`} type={type} onClick={onClick} disabled={disabled}>{children}</button>;
}
function Card({ children, className = '', style }: { children: ReactNode; className?: string; style?: CSSProperties }) {
  return <section className={`ll-card ${className}`} style={style}>{children}</section>;
}
function Skeleton() {
  return <div className="ll-loading" aria-label="Loading portal"><div className="ll-skeleton" /><div className="ll-skeleton tall" /><div className="ll-skeleton" /></div>;
}
function ErrorNotice({ message, retry }: { message: string; retry?: () => void }) {
  return <div className="ll-error" role="alert">{message}{retry && <button className="ll-link" onClick={retry}>Try again</button>}</div>;
}
function PrivateImage({ objectPath, alt, className }: { objectPath: string; alt: string; className?: string }) {
  const query = useGetPrivateObject({ objectPath }, { query: { enabled: !!objectPath, queryKey: ['/api/storage/object', { objectPath }] } });
  const [url, setUrl] = useState('');
  useEffect(() => {
    if (!query.data) { setUrl(''); return; }
    const next = URL.createObjectURL(query.data as Blob);
    setUrl(next);
    return () => URL.revokeObjectURL(next);
  }, [query.data]);
  return !query.isError && url ? <img className={className} src={url} alt={alt} /> : null;
}
function ErrorBoundaryBlock({ children, error }: { children: ReactNode; error: unknown }) {
  if (!error) return <>{children}</>;
  const message = valueOf(asRecord(error), ['message'], 'Something went wrong while loading your property.');
  return <ErrorNotice message={message} />;
}
function Toast({ message, close }: { message: string; close: () => void }) {
  useEffect(() => {
    if (!message) return;
    const timer = window.setTimeout(close, 4200);
    return () => window.clearTimeout(timer);
  }, [message, close]);
  return message ? <div className="ll-toast" role="status">{message}<button aria-label="Dismiss message" onClick={close} style={{ marginLeft: 12, border: 0, color: 'inherit', background: 'transparent', cursor: 'pointer' }}>×</button></div> : null;
}

function InvitationFlow({ signup = false }: { signup?: boolean }) {
  const search = useSearch();
  const token = new URLSearchParams(search).get('token') || '';
  const [, setLocation] = useLocation();
  const auth = useAuth();
  const query = useGetInvitation(token, { query: { enabled: !!token && auth.isLoaded, queryKey: [...getGetInvitationQueryKey(token), auth.userId ?? 'guest'] } });
  const accept = useAcceptInvitation();
  const invite = query.data;
  if (!token) return <InviteGuard title="A private invitation is needed" detail="Ask your leasing office for an invitation." />;
  if (!auth.isLoaded || query.isLoading) return <div className="ll-welcome"><Skeleton /></div>;
  if (query.isError || !invite?.valid) return <InviteGuard title="This invite isn’t available" detail={invite?.message || 'The invitation may have expired or already been used. Contact your building team for help.'} />;
  if (signup) return <div className="ll-welcome"><div className="ll-welcome-top"><Brand /><Link className="ll-link" href="/">Back to welcome</Link></div><div style={{ maxWidth: 520, margin: '45px auto' }}><p className="ll-kicker">YOUR INVITATION IS VERIFIED</p><h1 className="ll-title" style={{ marginBottom: 22 }}>Create your resident account</h1><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} forceRedirectUrl={`${basePath}/activate?token=${encodeURIComponent(token)}`} /></div></div>;
  const property = invite.property;
  const acceptInvite = () => accept.mutate({ token }, { onSuccess: async () => {
    await queryClient.invalidateQueries({ queryKey: getGetSessionQueryKey() });
    await queryClient.invalidateQueries({ queryKey: getGetPortalQueryKey() });
    setLocation('/resident');
  } });
  return <div className="ll-welcome"><div className="ll-welcome-top"><Brand /><Link className="ll-link" href="/">Back to welcome</Link></div><div className="ll-content" style={{ maxWidth: 680, margin: '75px auto' }}><p className="ll-kicker">RESIDENT INVITATION</p><h1 className="ll-title">Welcome home.</h1><p className="ll-subtitle">You’ve been invited to {property?.name || 'your building'}{invite.unitLabel ? `, apartment ${invite.unitLabel}` : ''}. This private invitation is for {invite.invitedEmail || 'your email address'}.</p><Card style={{ marginTop: 24 } as never}><div className="ll-row"><span className="ll-icon-tile"><Building2 size={19} /></span><div><strong>{property?.name || 'Your building'}</strong><div className="ll-copy">{property ? `${property.address}, ${property.city}, ${property.region}` : ''}</div></div></div><div className="ll-divider" /><p className="ll-copy">Invitation expires {invite.expiresAt ? fmtDate(invite.expiresAt) : 'soon'}. Your account will only have access to the home and property information assigned to you.</p>{auth.isSignedIn && invite.unitLabel ? <div className="ll-action-row"><Button onClick={acceptInvite} disabled={accept.isPending}>{accept.isPending ? 'Activating…' : 'Join community'} <ArrowRight size={16} /></Button></div> : <div className="ll-action-row"><Link className="ll-btn" href={`/sign-up?token=${encodeURIComponent(token)}`}>Create account <ArrowRight size={16} /></Link><Link className="ll-btn secondary" href={`/sign-in?token=${encodeURIComponent(token)}`}>Already have an account? Sign in</Link></div>}{accept.isError && <ErrorNotice message={valueOf(asRecord(asRecord(accept.error).data), ['error'], 'We couldn’t activate this invitation. Ask your leasing office for help.')} />}</Card></div></div>;
}
function InviteGuard({ title, detail }: { title: string; detail: string }) {
  return <div className="ll-welcome"><div className="ll-welcome-top"><Brand /><Link className="ll-link" href="/">Back to welcome</Link></div><div className="ll-content" style={{ maxWidth: 620, margin: '100px auto' }}><div className="ll-icon-tile"><ShieldCheck size={21} /></div><h1 className="ll-title" style={{ marginTop: 16 }}>{title}</h1><p className="ll-subtitle">{detail}</p><div className="ll-action-row"><Link className="ll-btn" href="/">Return home</Link></div></div></div>;
}
function SignInLayout({ children }: { children: ReactNode }) {
  return <div className="ll-auth">
    <header className="ll-landing-header"><Brand /><Link className="ll-landing-signin" href="/">Back to home</Link></header>
    <main className="ll-auth-main">
      <section className="ll-auth-card" aria-labelledby="sign-in-title">
        <header><h1 id="sign-in-title">Sign in</h1><p>Access your resident account.</p></header>
        <div className="ll-auth-content">{children}</div>
        <footer><Link href="/activate">Activate your account</Link>{clerkPubKey && <Link href="/demo">Try the demo <ArrowRight size={15} /></Link>}</footer>
      </section>
    </main>
  </div>;
}
function SignInPage() {
  const search = useSearch();
  const token = new URLSearchParams(search).get('token');
  const next = token ? `${basePath}/activate?token=${encodeURIComponent(token)}` : `${basePath}/resident`;
  return <SignInLayout><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/activate`} forceRedirectUrl={next} /></SignInLayout>;
}

function PublicHome({ authenticated, session }: { authenticated: boolean; session?: SessionResponse }) {
  const [, setLocation] = useLocation();
  useEffect(() => {
    if (!authenticated || !session) return;
    const membership = session.memberships.find((item) => item.active);
    if (membership) setLocation(roleHome(membership));
    else if (session.setupAvailable) setLocation('/setup');
  }, [authenticated, session, setLocation]);
  if (authenticated && session && !session.setupAvailable && !session.memberships.some((item) => item.active)) return <NoMembership email={session.user.email} />;
  if (authenticated && session) return <div className="ll-welcome"><Skeleton /><p className="ll-copy">Opening your private portal…</p></div>;
  return <WelcomePreview />;
}

const welcomeScenes = [
  { label: 'The building', icon: Building2, photo: 'willow-court-editorial.jpg', tag: '01 / WILLOW COURT', title: 'Take a look around', description: 'Explore the lobby and see how residents can browse photos of their building.', action: 'View lobby photos', route: '/demo?preview=building' },
  { label: 'Events', icon: CalendarDays, photo: 'game-night.jpg', tag: '02 / COMMUNITY ROOM', title: 'Game night at Willow Court', description: 'See what neighbors are planning and RSVP to an upcoming event.', action: 'Preview the event', route: '/demo?preview=events' },
  { label: 'Swap shelf', icon: ShoppingBag, photo: 'oak-desk.jpg', tag: '03 / NEIGHBOR MARKETPLACE', title: 'An oak desk, looking for a home', description: 'Browse things your neighbors are selling, swapping, or giving away.', action: 'Preview the swap shelf', route: '/demo?preview=marketplace' },
];

function WelcomePreview() {
  const [selected, setSelected] = useState(0);
  const scene = welcomeScenes[selected];
  return <div className="ll-landing">
    <header className="ll-landing-header"><Brand /><nav aria-label="Account"><Link className="ll-landing-signin" href="/sign-in">Sign in</Link><Link className="ll-btn" href="/activate">Activate your account</Link></nav></header>
    <main className="ll-landing-main">
      <section className="ll-frontdoor" aria-label="Explore Lease and Lobby">
        <div className="ll-frontdoor-intro">
          <p className="ll-landing-kicker">LEASE &amp; LOBBY / RESIDENT PORTAL</p>
          <h1>Life on your <em>side of the door.</em></h1>
          <p>Keep track of rent and lease details, find building updates, and get to know your neighbors.</p>
          <Link className="ll-btn" href="/demo">Try the resident demo <ArrowRight size={18} /></Link>
        </div>
        <div className="ll-frontdoor-stage">
          <img key={scene.photo} src={`${basePath}/${scene.photo}`} alt={scene.label} fetchPriority={selected === 0 ? 'high' : 'auto'} />
          <span className="ll-frontdoor-badge">WILLOW COURT <span>·</span> SAMPLE BUILDING</span>
          <div className="ll-frontdoor-caption" aria-live="polite">
            <div><p className="ll-landing-kicker">{scene.tag}</p><h2>{scene.title}</h2><p>{scene.description}</p></div>
            <Link href={scene.route}>{scene.action}<ArrowRight size={17} /></Link>
          </div>
        </div>
        <div className="ll-frontdoor-selector" role="group" aria-label="Choose a preview">
          {welcomeScenes.map(({ label, icon: Icon }, index) => <button key={label} type="button" aria-pressed={selected === index} onClick={() => setSelected(index)}><Icon size={19} /><span>{label}</span><span className="ll-frontdoor-index">0{index + 1}</span></button>)}
        </div>
      </section>
      <div className="ll-landing-footer"><ShieldCheck size={17} /><span>Resident accounts are private and linked to your building.</span></div>
    </main>
  </div>;
}

function SetupPage({ userEmail }: { userEmail: string }) {
  const createProperty = useCreateInitialProperty();
  const [, setLocation] = useLocation();
  const [error, setError] = useState('');
  const onSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const unitLabels = String(data.get('units') || '').split(',').map((item) => item.trim()).filter(Boolean);
    createProperty.mutate({ data: {
      name: String(data.get('name') || ''), address: String(data.get('address') || ''),
      city: String(data.get('city') || ''), region: String(data.get('region') || ''),
      postalCode: String(data.get('postalCode') || ''), description: String(data.get('description') || ''),
      unitLabels,
    } }, { onSuccess: async (result) => {
      if (!result.success) { setError(result.message); return; }
      await queryClient.invalidateQueries({ queryKey: getGetSessionQueryKey() });
      await queryClient.invalidateQueries({ queryKey: getGetPortalQueryKey() });
      setLocation('/owner');
    }, onError: () => setError('We couldn’t create the property. Please review the details and try again.') });
  };
  return <div className="ll-welcome"><div className="ll-welcome-top"><Brand /><span className="ll-header-user">{userEmail}</span></div><div className="ll-content" style={{ maxWidth: 750, margin: '55px auto' }}><p className="ll-kicker">INITIAL PROPERTY SETUP</p><h1 className="ll-title">Start with the place.</h1><p className="ll-subtitle">Create your first property and owner workspace. This controlled setup is only available when the server confirms it is open.</p><Card><form className="ll-form" onSubmit={onSubmit}><div className="ll-grid"><label className="ll-field">Property name<input name="name" required minLength={2} placeholder="Juniper House" /></label><label className="ll-field">Street address<input name="address" required minLength={2} placeholder="47 Alder Street" /></label><label className="ll-field">City<input name="city" required placeholder="Portland" /></label><label className="ll-field">State or region<input name="region" required placeholder="Oregon" /></label><label className="ll-field">Postal code<input name="postalCode" required placeholder="97205" /></label><label className="ll-field">Unit labels, comma separated<input name="units" required placeholder="1A, 1B, 2A, 2B" /></label></div><label className="ll-field">A short description<textarea name="description" placeholder="A few words about the building and the neighborhood." /></label>{error && <ErrorNotice message={error} />}<Button type="submit" disabled={createProperty.isPending}>{createProperty.isPending ? 'Creating property…' : 'Create property'} <ArrowRight size={16} /></Button></form></Card></div></div>;
}

function PortalRouter({ session, sessionLoading, sessionError, refetchSession }: {
  session?: SessionResponse; sessionLoading: boolean; sessionError: unknown; refetchSession: () => void;
}) {
  const [, setLocation] = useLocation();
  const auth = useAuth();
  const [path] = useLocation();
  const requestedRole = path.startsWith('/owner') ? 'building_owner' : path.startsWith('/manager') ? 'building_manager' : 'resident';
  const membership = session?.memberships.find((item) => item.active && item.role === requestedRole) ?? session?.memberships.find((item) => item.active);
  const propertyId = membership?.propertyId;
  const portalQuery = useGetPortal(propertyId ? { propertyId } : undefined, {
    query: { enabled: !!propertyId && auth.isSignedIn === true, queryKey: getGetPortalQueryKey(propertyId ? { propertyId } : undefined) },
  });
  if (!auth.isLoaded || sessionLoading) return <div className="ll-welcome"><Skeleton /></div>;
  if (!auth.isSignedIn) return <Redirect to="/" />;
  if (sessionError) return <div className="ll-welcome"><div className="ll-content" style={{ maxWidth: 600, margin: '100px auto' }}><ErrorNotice message="We couldn’t verify your Lease & Lobby membership." retry={refetchSession} /><Link className="ll-btn" href="/sign-in">Sign in again</Link></div></div>;
  if (!session) return <div className="ll-welcome"><Skeleton /></div>;
  if (!membership) {
    if (session.setupAvailable && path === '/setup') return <SetupPage userEmail={session.user.email} />;
    if (session.setupAvailable && path !== '/setup') return <Redirect to="/setup" />;
    return <NoMembership email={session.user.email} />;
  }
  if (path === '/setup') return <Redirect to={roleHome(membership)} />;
  const allowed = membership.role === 'resident'
    ? ['/resident', '/lobby', '/rent', '/documents', '/renewals', '/maintenance', '/complaints', '/document-requests', '/amenities', '/profile']
    : membership.role === 'building_manager' ? ['/manager', '/manager/maintenance', '/manager/complaints', '/manager/document-requests'] : ['/owner', '/owner/maintenance', '/owner/complaints', '/owner/document-requests'];
  if (!allowed.includes(path)) return <Redirect to={roleHome(membership)} />;
  if (portalQuery.isLoading) return <div className="ll-welcome"><Skeleton /></div>;
  if (portalQuery.isError || !portalQuery.data) return <div className="ll-welcome"><div className="ll-content" style={{ maxWidth: 620, margin: '90px auto' }}><ErrorNotice message="We couldn’t load your assigned property. No building information is shown until access is confirmed." retry={() => portalQuery.refetch()} /></div></div>;
  return <PortalShell membership={membership} session={session} snapshot={portalQuery.data} path={path} refresh={async () => {
    await queryClient.invalidateQueries({ queryKey: getGetPortalQueryKey({ propertyId }) });
    await queryClient.invalidateQueries({ queryKey: getListInvitationsQueryKey({ propertyId }) });
  }} />;
}
function NoMembership({ email }: { email: string }) {
  const clerk = useClerk();
  return <div className="ll-welcome"><div className="ll-welcome-top"><Brand /><button className="ll-icon-btn" onClick={() => clerk.signOut({ redirectUrl: basePath || '/' })} aria-label="Sign out"><LogOut size={17} /></button></div><div className="ll-content" style={{ maxWidth: 620, margin: '100px auto' }}><span className="ll-icon-tile"><ShieldCheck size={22} /></span><h1 className="ll-title" style={{ marginTop: 15 }}>No property access yet.</h1><p className="ll-subtitle">You’re signed in as {email}, but there isn’t an active property membership on this account. Ask your building team to send an invitation. Lease & Lobby never shows another property’s information.</p><Link className="ll-btn secondary" href="/">Return to welcome</Link></div></div>;
}

function PortalShell({ membership, session, snapshot, path, refresh }: {
  membership: Membership; session: SessionResponse;
  snapshot: PortalSnapshot; path: string; refresh: () => Promise<void>;
}) {
  const [toast, setToast] = useState('');
  const [mobileOpen, setMobileOpen] = useState(false);
  const clerk = useClerk();
  const property = snapshot.property || null;
  const role = membership.role;
  const nav = role === 'resident' ? homeLinks : role === 'building_manager'
    ? [{ label: 'Work queue', path: '/manager', icon: CheckCircle2 }, { label: 'Maintenance', path: '/manager/maintenance', icon: Wrench }, { label: 'Complaints', path: '/manager/complaints', icon: MessageCircle }, { label: 'Document requests', path: '/manager/document-requests', icon: FileText }, { label: 'Invitations', path: '/manager', icon: Users }, { label: 'Building photos', path: '/manager', icon: Image }]
    : [{ label: 'Property', path: '/owner', icon: Building2 }, { label: 'Maintenance', path: '/owner/maintenance', icon: Wrench }, { label: 'Complaints', path: '/owner/complaints', icon: MessageCircle }, { label: 'Document requests', path: '/owner/document-requests', icon: FileText }, { label: 'Managers', path: '/owner', icon: Users }, { label: 'Features', path: '/owner', icon: Bell }];
  return <div className="ll-app">
    <header className="ll-header"><Brand /><div className="ll-header-property"><strong>{property?.name || membership.propertyName}</strong>{membership.unitLabel ? `Apartment ${membership.unitLabel}` : `${property?.city || ''}${property?.region ? `, ${property.region}` : ''}`}</div><div className="ll-header-actions"><span className="ll-header-user">{session.user.displayName || session.user.email}</span><button className="ll-icon-btn" aria-label="Sign out" onClick={() => clerk.signOut({ redirectUrl: basePath || '/' })}><LogOut size={17} /></button><button className="ll-icon-btn ll-menu-btn" aria-label="Toggle navigation" onClick={() => setMobileOpen(!mobileOpen)}><Menu size={18} /></button></div></header>
    <div className="ll-frame"><aside className={`ll-sidebar ${mobileOpen ? 'is-open' : ''}`}><p className="ll-nav-label">{role === 'resident' ? 'YOUR HOME' : role === 'building_manager' ? 'ASSIGNED PROPERTY' : 'OWNER WORKSPACE'}</p><nav className="ll-nav" aria-label="Portal navigation">{nav.map(({ label, path: href, icon: Icon }, index) => <Link key={`${label}-${index}`} href={href} className={path === href || (role === 'resident' && label === 'Home' && path === '/resident') ? 'active' : ''} onClick={() => setMobileOpen(false)}><Icon size={17} strokeWidth={1.8} />{label}{label === 'Documents' && rows(snapshot.documents).some((doc) => valueOf(doc, ['status', 'state']) === 'requested') && <span className="nav-bullet" />}</Link>)}</nav><div className="ll-side-note"><CircleHelp size={17} /><strong>Your property, your privacy.</strong><p>Your access is limited to the property assigned to your account.</p></div></aside><main className="ll-main"><div className="ll-content"><ErrorBoundaryBlock error={null}><PortalPage path={path} role={role} membership={membership} session={session} snapshot={snapshot} property={property} toast={setToast} refresh={refresh} /></ErrorBoundaryBlock></div></main></div>
    {role === 'resident' && <nav className="ll-bottom-nav" aria-label="Quick navigation">{primaryHomeLinks.map(({ path: href, label, icon: Icon }) => <Link key={href} href={href} aria-current={path === href ? 'page' : undefined} className={path === href ? 'active' : ''}><Icon />{label}</Link>)}</nav>}
    <Toast message={toast} close={() => setToast('')} />
  </div>;
}

function PortalPage({ path, role, membership, session, snapshot, property, toast, refresh }: {
  path: string; role: Membership['role']; membership: Membership; session: SessionResponse;
  snapshot: PortalSnapshot; property: Property | null; toast: (text: string) => void; refresh: () => Promise<void>;
}) {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const managerAction = useRunManagerAction();
  const residentAction = useRunResidentAction();
  const requestUpload = useRequestUploadUrl();
  const invitationList = useListInvitations({ propertyId: membership.propertyId }, { query: { enabled: session.memberships.some((item) => item.propertyId === membership.propertyId && item.role === 'building_manager'), queryKey: getListInvitationsQueryKey({ propertyId: membership.propertyId }) } });
  const createInvite = useCreateInvitation();
  const [modal, setModal] = useState<'event' | 'listing' | 'photo' | 'notice' | 'invite' | 'question' | null>(null);
  const [busy, setBusy] = useState(false);
  const [inviteLink, setInviteLink] = useState('');
  const [copied, setCopied] = useState(false);
  const notices = rows(snapshot.notices);
  const docs = rows(snapshot.documents);
  const queue = rows(snapshot.managerQueue);
  const staffUnits = rows(asRecord(snapshot.settings).units);
  const roster = rows(asRecord(snapshot.settings).roster);
  const rent = asRecord(snapshot.rent);
  const lease = asRecord(snapshot.lease);
  const currentPath = path;
  const search = useSearch();
  useEffect(() => {
    if (path === '/documents' && window.location.hash.startsWith('#document-')) {
      document.getElementById(window.location.hash.slice(1))?.scrollIntoView({ block: 'start' });
    }
  }, [path]);
  const action = async (kind: ActionInputAction, targetId?: string, data?: Dict, manager = role !== 'resident') => {
    setBusy(true);
    const variables = { data: { action: kind, propertyId: membership.propertyId, ...(targetId ? { targetId } : {}), ...(data ? { data } : {}) } };
    try {
      const result = manager ? await managerAction.mutateAsync(variables) : await residentAction.mutateAsync(variables);
      if (!result.success) throw new Error(result.message || 'The action could not be completed.');
      toast(result.message || 'Your update was saved.');
      await refresh();
      return result;
    } catch (error) {
      toast(valueOf(asRecord(error), ['message'], 'We couldn’t save that update. Please try again.'));
      return null;
    } finally { setBusy(false); }
  };
  const uploadThenSave = async (file: File, purpose: 'property_photo' | 'resident_document', targetId?: string, metadata: Dict = {}) => {
    if (file.size > 10 * 1024 * 1024) { toast('Please choose a file smaller than 10 MB.'); return false; }
    setBusy(true);
    try {
      const signed = await requestUpload.mutateAsync({ data: { propertyId: membership.propertyId, purpose, fileName: file.name, contentType: file.type || 'application/octet-stream', size: file.size } });
      const uploaded = await fetch(signed.uploadURL, { method: 'PUT', headers: { 'Content-Type': file.type || 'application/octet-stream' }, body: file });
      if (!uploaded.ok) throw new Error('The file upload did not complete.');
      const actionName: ActionInputAction = purpose === 'property_photo' ? 'save_photo' : 'submit_document';
      const result = await (role === 'resident'
        ? residentAction.mutateAsync({ data: { action: actionName, propertyId: membership.propertyId, ...(targetId ? { targetId } : {}), data: { ...metadata, objectPath: signed.objectPath, fileName: file.name, contentType: file.type, size: file.size } } })
        : managerAction.mutateAsync({ data: { action: actionName, propertyId: membership.propertyId, ...(targetId ? { targetId } : {}), data: { ...metadata, objectPath: signed.objectPath, fileName: file.name, contentType: file.type, size: file.size } } }));
      if (!result.success) throw new Error(result.message);
      toast(result.message || 'Your file was saved securely.');
      await refresh();
      return true;
    } catch (error) { toast(valueOf(asRecord(error), ['message'], 'We couldn’t upload this file. Please try again.')); return false; }
    finally { setBusy(false); }
  };
  const submitCreate = async (event: FormEvent<HTMLFormElement>, type: 'event' | 'listing' | 'photo' | 'notice' | 'invite' | 'question') => {
    event.preventDefault();
    const form = event.currentTarget;
    const fields = new FormData(form);
    const text = (key: string) => String(fields.get(key) || '').trim();
    if (type === 'photo') {
      const file = (fields.get('file') as File | null);
      if (file && file.size && await uploadThenSave(file, 'property_photo', undefined, { location: text('location'), altText: text('altText'), caption: text('caption') })) setModal(null);
      return;
    }
    if (type === 'invite') {
      createInvite.mutate({ data: { propertyId: membership.propertyId, unitId: text('unitId'), email: text('email') } }, { onSuccess: async (created) => {
        setInviteLink(created.inviteUrl);
        await queryClient.invalidateQueries({ queryKey: getListInvitationsQueryKey({ propertyId: membership.propertyId }) });
        setModal(null);
        if (created.emailStatus !== 'sent') toast('Invitation created. Email is not configured; copy the invite link to share it.');
        else toast(created.message || 'Invitation created.');
      }, onError: () => toast('We couldn’t create that invitation. Check the unit and email address.') });
      return;
    }
    const kind: ActionInputAction = type === 'event' ? 'create_event' : type === 'listing' ? 'create_listing' : type === 'notice' ? 'create_notice' : 'ask_charge_question';
    const data: Dict = type === 'event' ? { title: text('title'), description: text('description'), startsAt: text('date'), location: text('location') }
      : type === 'listing' ? { title: text('title'), description: text('description'), price: text('price') }
      : type === 'notice' ? { title: text('title'), body: text('description'), importance: text('importance') }
      : { subject: text('title'), message: text('description') };
    if (await action(kind, undefined, data, type === 'notice')) setModal(null);
  };
  const copyInvite = async () => {
    if (!inviteLink) return;
    await navigator.clipboard.writeText(new URL(inviteLink, window.location.origin).toString());
    setCopied(true); toast('Invite link copied. Share it directly with the resident.');
  };
  const openModal = (name: typeof modal) => setModal(name);
  const closeModal = (name: typeof modal) => { setModal(name); if (!name) { setInviteLink(''); setCopied(false); } };

  if (path === '/amenities' && role === 'resident') return <>
    <PageHead kicker={property?.name || membership.propertyName} title="Amenities calendar">Find an available time and reserve a shared space in your building.</PageHead>
    <Amenities key={membership.id} propertyId={membership.propertyId} membershipId={membership.id} />
  </>;
  if (path.endsWith('/document-requests')) return <>
    <PageHead kicker={property?.name || membership.propertyName} title="Document requests">{role === 'resident' ? 'Ask management for a document and download it here when it’s ready.' : 'Review requests and share PDFs privately with residents.'}</PageHead>
    <Maintenance key={`${membership.id}:${path}`} propertyId={membership.propertyId} membershipId={membership.id} staff={role !== 'resident'} documents />
  </>;
  if (path.endsWith('/maintenance') || path.endsWith('/complaints')) {
    const staff = role !== 'resident';
    const complaint = path.endsWith('/complaints');
    const subtitle = complaint
      ? (staff ? 'Review private messages sent by residents.' : 'Send a private message to building management and check its status.')
      : (staff ? 'Review resident requests and update their status.' : 'Report a problem in your home and follow its progress.');
    return <><PageHead kicker={property?.name || membership.propertyName} title={complaint ? 'Complaints' : 'Maintenance'}>{subtitle}</PageHead>
      <Maintenance key={`${membership.id}:${path}`} propertyId={membership.propertyId} membershipId={membership.id} staff={staff} complaint={complaint} /></>;
  }
  if (role === 'resident') return ResidentContent();
  if (role === 'building_manager') return ManagerContent();
  return OwnerContent();

  function ResidentContent() {
    const propertyName = property?.name || membership.propertyName;
    const rentAmount = typeof rent.balanceCents === 'number' ? dollars(rent.balanceCents) : valueOf(rent, ['amount', 'monthlyAmount', 'monthlyRent', 'totalDue', 'balance']);
    const rentDue = valueOf(rent, ['dueDate', 'dueAt', 'due']);
    const status = valueOf(rent, ['status', 'paymentStatus'], 'No current balance');
    if (currentPath === '/lobby') return <LobbyPage snapshot={snapshot} property={property} onAction={action} initialLocation={new URLSearchParams(search).get('location') || 'entrance'} />;
    if (currentPath === '/rent') return <><PageHead kicker="YOUR ACCOUNT" title="Rent & charges">Review your current balance, payment activity, and any questions for the office.</PageHead><div className="ll-grid"><div className="ll-stack"><Card><div className="ll-row ll-between"><span className="ll-eyebrow">TOTAL DUE</span><span className={`ll-pill ${status.toLowerCase().includes('due') ? 'warn' : ''}`}>{status}</span></div><p className="ll-amount">{rentAmount ? (/[$]/.test(rentAmount) ? rentAmount : `$${Number(rentAmount).toLocaleString()}`) : '—'}</p><p className="ll-copy">{rentDue ? `Due ${fmtDate(rentDue)}` : 'Your payment and charge details are maintained by your property team.'}</p>{Array.isArray(rent.history) && <div className="ll-list">{rows(rent.history).map((entry, i) => <DataRow key={i} item={entry} icon={<CreditCard size={17} />} />)}</div>}<p className="ll-copy">Online payments are unavailable for this property.</p>{rows(rent.charges).length > 0 && <details><summary>See what changed</summary>{rows(rent.charges).map((charge, i) => <p key={i}>{String(charge.label)} · {dollars(Number(charge.amountCents))}</p>)}</details>}</Card><Card><p className="ll-kicker">QUESTIONS ABOUT A CHARGE?</p><h2>Ask your property team.</h2><p className="ll-copy">Your message stays within your assigned property.</p><Button variant="secondary" onClick={() => openModal('question')}><MessageCircle size={15} /> Ask a question</Button>{rows(snapshot.chargeQuestions).map((item, i) => <DataRow key={i} item={item} icon={<CircleHelp size={17} />} />)}</Card></div><aside className="ll-stack"><Card><span className="ll-icon-tile"><ShieldCheck size={18} /></span><h2>Private, property-specific support.</h2><p className="ll-copy">Rent details are visible only to your household and authorized staff at {propertyName}.</p></Card></aside></div><ActionModal modal={modal} setModal={closeModal} submit={submitCreate} busy={busy || createInvite.isPending} invitation={inviteLink} copied={copied} copyInvite={copyInvite} uploadBusy={busy} units={staffUnits} /></>;
    if (currentPath === '/documents') return <><PageHead kicker="YOUR HOME, ON PAPER" title="Documents">Lease files and document requests, kept in one private place.</PageHead><div className="ll-document-request-entry"><Link className="ll-btn" href="/document-requests">Request documents <ArrowRight size={15} /></Link></div><div className="ll-stack">{docs.length ? docs.map((doc, i) => <DocumentCard key={valueOf(doc, ['id'], String(i))} item={doc} onUpload={(file) => void uploadThenSave(file, 'resident_document', valueOf(doc, ['id']) || undefined)} busy={busy} />) : <Card><div className="ll-empty"><FileText size={22} /><strong>No documents to review</strong>Your property hasn’t shared any documents or requests yet.</div></Card>}{lease && Object.keys(lease).length > 0 && <Card><p className="ll-kicker">LEASE SUMMARY</p><DataRow item={lease} icon={<KeyRound size={17} />} /></Card>}</div></>;
    if (currentPath === '/renewals') return <><PageHead kicker="YOUR NEXT CHAPTER" title="Lease renewal">Your renewal offer and conversations with the building team.</PageHead><div className="ll-grid"><div className="ll-stack">{lease && Object.keys(lease).length ? <Card><p className="ll-eyebrow">CURRENT LEASE</p><h2>{valueOf(lease, ['title', 'name'], 'Your lease')}</h2><div className="ll-list">{Object.entries(lease).map(([key, value]) => <div className="ll-list-item" key={key}><span className="ll-eyebrow">{key.replace(/([A-Z])/g, ' $1')}</span><strong style={{ marginLeft: 'auto' }}>{String(value)}</strong></div>)}</div><Button onClick={() => void action('ask_renewal_question', valueOf(lease, ['id']) || undefined, {})} variant="secondary">Ask about renewal</Button></Card> : <Card><div className="ll-empty"><KeyRound size={22} /><strong>No renewal offer yet</strong>When your property team shares an offer, it will appear here.</div></Card>}{rows(lease.renewals).map((item, i) => <Card key={i}><DataRow item={item} icon={<KeyRound size={17} />} /><div className="ll-action-row"><Button onClick={() => void action('decide_renewal', valueOf(item, ['id']), { decision: 'accept' }, false)}>Accept offer</Button><Button variant="secondary" onClick={() => void action('ask_renewal_question', valueOf(item, ['id']), {}, false)}>Ask a question</Button></div></Card>)}</div><Card><span className="ll-icon-tile"><MessageCircle size={18} /></span><h2>Need time or clarity?</h2><p className="ll-copy">Send a question to your building team before making a decision.</p></Card></div></>;
    if (currentPath === '/profile') return <><PageHead kicker="YOUR ACCOUNT" title="Profile">Your account details come from your verified Lease & Lobby sign-in.</PageHead><div className="ll-grid"><Card><div className="ll-row"><span className="ll-icon-tile"><Users size={20} /></span><div><h2>{session.user.displayName}</h2><p className="ll-copy">{membership.role.replace('_', ' ')} · Apartment {membership.unitLabel || '—'}</p></div></div><div className="ll-divider" /><div className="ll-list"><div className="ll-list-item"><span className="ll-copy">Email</span><strong>{session.user.email}</strong></div><div className="ll-list-item"><span className="ll-copy">Property</span><strong>{propertyName}</strong></div><div className="ll-list-item"><span className="ll-copy">Email verified</span><strong>{session.user.emailVerified ? 'Verified' : 'Not verified'}</strong></div></div></Card><Card><p className="ll-kicker">PREFERENCES</p><h2>Stay in the loop.</h2><p className="ll-copy">Notification preferences are controlled by your portal settings when available.</p><div className="ll-list">{Object.entries(asRecord(snapshot.settings)).map(([key, value]) => <div className="ll-list-item" key={key}><span className="ll-copy">{key.replace(/([A-Z])/g, ' $1')}</span><strong>{String(value)}</strong></div>)}</div></Card></div></>;
    const tasks = docs.filter((doc) => doc.status === 'requested' || doc.status === 'needs_replacement');
    const nextTask = tasks[0];
    const notice = notices[0];
    const buildingPhotos = rows(snapshot.gallery).filter((photo) => photo.published === true);
    return <>
      <ResidentHomeLayout propertyName={propertyName} unit={membership.unitLabel}
        photo={property?.coverPhotoPath ? <PrivateImage objectPath={property.coverPhotoPath} alt="" /> : undefined}>
      <div className="ll-resident-overview">
        <section className="ll-home-column ll-overview-lease" aria-labelledby="private-lease-column">
          <div className="ll-column-title"><h2 id="private-lease-column">Rent &amp; lease</h2></div>
          <div className="ll-ledger">
            <div className="ll-ledger-main">
              <div><p className="ll-card-label">Total due</p><strong className="ll-home-balance">{rentAmount || '—'}</strong></div>
              {rentDue && <span className="ll-state">Due {fmtDate(rentDue)}</span>}
            </div>
            {rentAmount ? <div className="ll-ledger-links"><Link className="ll-link ll-rent-action" href="/rent">View rent details <ArrowRight size={15} /></Link></div> : <p className="ll-lease-empty">Your property hasn’t shared a balance yet.</p>}
          </div>
          {nextTask && <Link className="ll-task-tile" href={`/documents#document-${String(nextTask.id)}`}>
            <span className="ll-task-icon"><FileText size={20} /></span><span><small>YOUR NEXT ACTION</small><strong>{nextTask.status === 'needs_replacement' ? 'Replace' : 'Submit'} {valueOf(nextTask, ['title'], 'your document')}</strong><span>{nextTask.expiresAt ? `Due ${fmtDate(String(nextTask.expiresAt))}` : 'Open the request for details'}</span></span><ArrowRight size={18} />
          </Link>}
          {lease.renewalStatus === 'pending' && <Link className="ll-task-tile" href="/renewals">
            <span className="ll-task-icon"><KeyRound size={20} /></span><span><small>YOUR LEASE</small><strong>Review your renewal offer</strong><span>{lease.renewalDeadline ? `Respond by ${fmtDate(String(lease.renewalDeadline))}` : 'Open the offer for details'}</span></span><ArrowRight size={18} />
          </Link>}
          {!nextTask && lease.renewalStatus !== 'pending' && <p className="ll-lease-empty">No outstanding requests.</p>}

        </section>
        <ResidentShortcuts />
        <BuildingUpdates notice={notice} />
        <ResidentSpaces photos={buildingPhotos} eventsEnabled={asRecord(snapshot.settings).eventsEnabled !== false} />
      </div>
      </ResidentHomeLayout>
    </>;
  }

  function ManagerContent() {
    return <><PageHead kicker={`BUILDING MANAGER · ${property?.name || membership.propertyName}`} title="Building workspace">Keep track of residents, requests, and what’s happening in your building.</PageHead>
      <div className="ll-grid"><div className="ll-stack"><Card><div className="ll-row ll-between"><h2>Work queue</h2><Button variant="secondary" onClick={() => openModal('notice')}>Publish notice</Button></div>{queue.length ? queue.map((item) => <QueueItem key={String(item.id)} item={item} onResolve={(kind, id, data) => void action(kind, id, data, true)} busy={busy} />) : <p className="ll-empty">No open tasks for this property.</p>}</Card>
      <Card><div className="ll-row ll-between"><h2>Residents &amp; Invitations</h2><Button disabled={!staffUnits.length} onClick={() => openModal('invite')}><Plus size={16} /> Invite resident</Button></div>
      <form className="ll-form" onSubmit={async (e) => { e.preventDefault(); const form = e.currentTarget; if (await action('create_unit', undefined, Object.fromEntries(new FormData(form)))) form.reset(); }}><label className="ll-field">Add a unit<input name="label" required maxLength={160} placeholder="Apartment 3B" /></label><Button type="submit" variant="secondary" disabled={busy}>Save unit</Button></form>
      <p className="ll-copy">{staffUnits.length} units · {roster.filter((member) => member.role === 'resident').length} active residents</p>
      {roster.filter((member) => member.role === 'resident').map((member) => <div key={String(member.id)} className="ll-list-item"><span>{String(member.email)}</span><Button variant="secondary" disabled={busy} onClick={() => void action('remove_membership', String(member.id))}>Revoke access</Button></div>)}
      {invitationList.isError ? <ErrorNotice message="Invitations could not be loaded." retry={() => invitationList.refetch()} /> : <InvitationsTable items={invitationList.data ?? []} onRevoke={(item) => void action('revoke_invitation', item.id)} />}</Card></div>
      <div className="ll-stack"><StaffProperty property={property} snapshot={snapshot} action={action} busy={busy} addPhoto={() => openModal('photo')} /></div></div>
      <ActionModal modal={modal} setModal={closeModal} submit={submitCreate} busy={busy || createInvite.isPending} invitation={inviteLink} copied={copied} copyInvite={copyInvite} uploadBusy={busy} units={staffUnits} />
    </>;
  }

  function OwnerContent() {
    return <><PageHead kicker={`BUILDING OWNER · ${property?.name || membership.propertyName}`} title="Property workspace">Manage building details and staff assignments.</PageHead><div className="ll-grid">
      <div className="ll-stack"><Card><h2>Managers</h2><p className="ll-copy">Appoint a manager with a verified staff account.</p>
      <form className="ll-form" onSubmit={async (e) => { e.preventDefault(); const form = e.currentTarget; if (await action('assign_manager', undefined, Object.fromEntries(new FormData(form)))) form.reset(); }}><label className="ll-field">Manager email<input name="email" type="email" required placeholder="manager@building.example" /></label><Button type="submit" disabled={busy}>Assign manager</Button></form>
      {roster.filter((member) => member.role === 'building_manager').map((member) => <div key={String(member.id)} className="ll-list-item"><span>{String(member.email)}</span><Button variant="secondary" disabled={busy} onClick={() => void action('remove_membership', String(member.id))}>Remove manager</Button></div>)}</Card>
      {session.memberships.some((member) => member.propertyId === membership.propertyId && member.role === 'building_manager') && <Link className="ll-btn secondary" href="/manager">Open manager workspace</Link>}</div>
      <div className="ll-stack"><StaffProperty property={property} snapshot={snapshot} action={action} busy={busy} addPhoto={() => openModal('photo')} /></div></div>
      <ActionModal modal={modal} setModal={closeModal} submit={submitCreate} busy={busy} invitation={inviteLink} copied={copied} copyInvite={copyInvite} uploadBusy={busy} units={staffUnits} />
    </>;
  }
}

function StaffProperty({ property, snapshot, action, addPhoto, busy }: {
  property: Property | null; snapshot: PortalSnapshot; busy: boolean; addPhoto: () => void;
  action: (kind: ActionInputAction, id?: string, data?: Dict) => Promise<unknown>;
}) {
  const [preview, setPreview] = useState(false);
  const settings = asRecord(snapshot.settings);
  const flags = [
    ['eventsEnabled', 'Events'], ['marketplaceEnabled', 'Marketplace'],
    ['residentPostingEnabled', 'Resident posting'], ['eventApprovalRequired', 'Require event approval'],
  ];
  const photos = rows(snapshot.gallery);
  return <>
    <Card><p className="ll-kicker">PROPERTY PROFILE</p><h2>Building &amp; Photos</h2>
      {property && <form className="ll-form" onSubmit={(e) => { e.preventDefault(); void action('update_property', property.id, Object.fromEntries(new FormData(e.currentTarget))); }}>
        <label className="ll-field">Property name<input name="name" required defaultValue={property.name} /></label>
        <label className="ll-field">Street address<input name="address" required defaultValue={property.address} /></label>
        <div className="ll-grid"><label className="ll-field">City<input name="city" required defaultValue={property.city} /></label><label className="ll-field">Region<input name="region" required defaultValue={property.region} /></label></div>
        <label className="ll-field">Postal code<input name="postalCode" required defaultValue={property.postalCode} /></label>
        <label className="ll-field">Description<textarea name="description" defaultValue={property.description} /></label>
        <Button disabled={busy} type="submit">Save building details</Button>
      </form>}
      <div className="ll-divider" />
      <div className="ll-action-row"><Button disabled={busy} variant="secondary" onClick={addPhoto}><Plus size={16} /> Add photo</Button><Button variant="ghost" onClick={() => setPreview(!preview)}>{preview ? 'Back to editing' : 'Preview as resident'}</Button></div>
      <p className="ll-copy">For the Lobby photo tour, upload a photo, choose the space it shows, and publish it. Choose Lobby entrance for the first view residents see.</p>
      {photos.map((photo) => <div key={String(photo.id)} className="ll-staff-photo">
        <PrivateImage className="ll-preview-image" objectPath={String(photo.objectPath)} alt={String(photo.altText)} />
        <strong>{String(photo.caption || photo.altText)}</strong><p className="ll-copy">{String(photo.location).replaceAll('_', ' ')} · {photo.published ? 'Published' : 'Draft'}</p>
        {!preview && <div className="ll-action-row">
          {!photo.published && <Button disabled={busy} onClick={() => void action('publish_photos', String(photo.id))}>Publish photo</Button>}
          {property?.coverPhotoPath !== photo.objectPath && <Button disabled={busy} variant="secondary" onClick={() => void action('publish_photos', String(photo.id), { cover: true })}>Publish as cover</Button>}
        </div>}
      </div>)}
    </Card>
    <Card><p className="ll-kicker">COMMUNITY FEATURES</p><h2>Building settings</h2>
      <form className="ll-form" onSubmit={(e) => {
        e.preventDefault();
        const data = new FormData(e.currentTarget);
        void action('update_features', undefined, {
          ...Object.fromEntries(flags.map(([key]) => [key, data.has(key)])),
          amenities: data.getAll('amenities'),
          amenityTimeZone: String(data.get('amenityTimeZone') || 'UTC'),
        });
      }}>
        {flags.map(([key, name]) => <label className="ll-check" key={key}><input type="checkbox" name={key} defaultChecked={settings[key] === true} />{name}</label>)}
        <fieldset className="ll-amenity-settings"><legend>Bookable amenities</legend>
          {amenityOptions.map(({ id, label }) => <label className="ll-check" key={id}><input type="checkbox" name="amenities" value={id} defaultChecked={Array.isArray(settings.amenities) && settings.amenities.includes(id)} />{label}</label>)}
          <label className="ll-field">Building time zone<input name="amenityTimeZone" defaultValue={String(settings.amenityTimeZone || 'UTC')} placeholder="America/Los_Angeles" required /></label>
        </fieldset>
        <Button type="submit" disabled={busy}>Save settings</Button>
      </form>
    </Card>
  </>;
}

function DataRow({ item, icon, href }: { item: Dict; icon: ReactNode; href?: string }) {
  const title = valueOf(item, ['title', 'name', 'label', 'type', 'subject', 'documentType'], 'Property update');
  const detail = valueOf(item, ['description', 'message', 'body', 'details', 'dueDate', 'status', 'date', 'startsAt']);
  const row = <div className="ll-list-item"><span className="ll-icon-tile">{icon}</span><div><strong>{title}</strong><small>{detail || 'Shared by your property team'}</small></div>{href && <ChevronRight size={16} color="#879187" />}</div>;
  return href ? <Link href={href} style={{ textDecoration: 'none' }}>{row}</Link> : row;
}
function DocumentCard({ item, onUpload, busy }: { item: Dict; onUpload: (file: File) => void; busy: boolean }) {
  const title = valueOf(item, ['title', 'name', 'documentType', 'type'], 'Requested document');
  const status = valueOf(item, ['status'], 'Available');
  const path = valueOf(item, ['objectPath', 'filePath']);
  const due = valueOf(item, ['expiresAt']);
  const reason = valueOf(item, ['reason', 'reviewMessage']);
  return <div id={`document-${String(item.id)}`}><Card>
    <div className="ll-row ll-between"><div><p className="ll-kicker">{valueOf(item, ['category'], 'Document')}</p><h2>{title}</h2></div><span className="ll-pill">{status.replaceAll('_', ' ')}</span></div>
    {due && <p className="ll-copy">Due {fmtDate(due)}</p>}
    {reason && status === 'needs_replacement' && <p className="ll-callout">{reason}</p>}
    {typeof item.submittedAt === 'string' && <p className="ll-copy">Last submitted {fmtDate(item.submittedAt)}</p>}
    <div className="ll-action-row">
      {path && <a className="ll-btn secondary" href={`/api/storage/object?objectPath=${encodeURIComponent(path)}`}>View submission</a>}
      {['requested', 'needs_replacement'].includes(status) && <label className="ll-field">{status === 'needs_replacement' ? 'Submit replacement' : 'Submit document'}<input type="file" accept="application/pdf,image/jpeg,image/png,image/webp" disabled={busy} onChange={(event) => { const file = event.currentTarget.files?.[0]; if (file) onUpload(file); event.currentTarget.value = ''; }} /></label>}
    </div>
  </Card></div>;
}
function QueueItem({ item, onResolve, busy }: { item: Dict; onResolve: (actionName: ActionInputAction, id?: string, data?: Dict) => void; busy: boolean }) {
  const type = String(item.type);
  const id = String(item.id);
  const title = valueOf(item, ['task', 'title'], 'Resident request');
  return <div className="ll-queue-item">
    <details><summary>{title} · {String(item.nextAction || 'Review')}</summary>
      {item.description != null && <p>{String(item.description)}</p>}
      {type === 'rent_question' && <form className="ll-form" onSubmit={(e) => { e.preventDefault(); onResolve('reply_charge_question', id, Object.fromEntries(new FormData(e.currentTarget))); }}><label className="ll-field">Reply<textarea name="reply" required maxLength={2000} /></label><Button type="submit" disabled={busy}>Send reply</Button></form>}
      {type === 'document_review' && <form className="ll-form" onSubmit={(e) => { e.preventDefault(); onResolve('review_document', id, Object.fromEntries(new FormData(e.currentTarget))); }}>
        {item.objectPath != null && <a className="ll-link" href={`/api/storage/object?objectPath=${encodeURIComponent(String(item.objectPath))}`}>Open submission</a>}
        <label className="ll-field">Status<select name="status"><option value="under_review">Under review</option><option value="accepted">Accepted</option><option value="needs_replacement">Needs replacement</option></select></label><label className="ll-field">Replacement reason<textarea name="reason" maxLength={2000} /></label><Button type="submit" disabled={busy}>Save review</Button></form>}
      {type === 'event_approval' && <Button onClick={() => onResolve('approve_event', id)} disabled={busy}>Approve event</Button>}
      {type === 'content_report' && <Button onClick={() => onResolve('review_report', id)} disabled={busy}>Mark reviewed</Button>}
    </details>
  </div>;
}
function InvitationsTable({ items, onRevoke }: { items: Invitation[]; onRevoke: (item: Invitation) => void }) {
  return <div className="ll-table-wrap"><table className="ll-table"><thead><tr><th>Resident</th><th>Unit</th><th>Status</th><th>Expires</th><th /></tr></thead><tbody>{items.map((invite) => <tr key={invite.id}><td>{invite.email}</td><td>{invite.unitLabel}</td><td><span className={`ll-pill ${invite.status !== 'pending' ? 'warn' : ''}`}>{invite.status}</span></td><td>{fmtDate(invite.expiresAt)}</td><td>{invite.status === 'pending' && <button className="ll-link" onClick={() => onRevoke(invite)}>Revoke</button>}</td></tr>)}</tbody></table></div>;
}
const lobbyAreas = [
  { id: 'entrance', demoImage: 'willow-court-lobby.jpg', name: 'Lobby entrance', icon: Image, title: 'Building gallery' },
  { id: 'leasing_desk', demoImage: 'willow-court-leasing.jpg', name: 'Leasing desk', icon: KeyRound, title: 'Your leasing office' },
  { id: 'noticeboard', demoImage: 'willow-court-noticeboard.jpg', name: 'Noticeboard', icon: Bell, title: 'From management' },
  { id: 'community_room', demoImage: 'willow-court-community.jpg', name: 'Community room', icon: Users, title: 'Hosted by a neighbor' },
  { id: 'courtyard', demoImage: 'willow-court-courtyard.jpg', name: 'Courtyard', icon: CalendarDays, title: 'Hosted by a neighbor' },
  { id: 'swap_shelf', demoImage: 'willow-court-swap.jpg', name: 'Swap shelf', icon: ShoppingBag, title: 'On the swap shelf' },
];
function LobbyPhotoTour({ name, photos, demoPhoto, demo, demoUpload }: {
  name: string; photos: Dict[]; demoPhoto?: string; demo: boolean; demoUpload: boolean;
}) {
  const [index, setIndex] = useState(0);
  const current = Math.min(index, Math.max(0, photos.length - 1));
  const photo = photos[current];
  return <figure className="ll-photo-tour">
    <div className="ll-photo-tour-image">
      {photo ? <PrivateImage key={String(photo.objectPath)} objectPath={String(photo.objectPath)} alt={String(photo.altText || name)} /> :
        demoPhoto ? <img src={demoPhoto} alt={demoUpload ? 'Lobby photo selected for the demo' : `Fictional Willow Court · ${name}`} /> :
        <div className="ll-photo-tour-empty"><Image size={27} /><p>{demo ? 'There’s no sample photo for this space yet.' : 'A photo will appear here when your building team publishes one.'}</p></div>}
    </div>
    <figcaption>
      <div aria-live="polite"><strong>{name}</strong><span>{photo ? String(photo.caption || `Photo ${current + 1} of ${photos.length}`) : demoPhoto ? (demoUpload ? 'Your demo photo · this tab only' : 'Illustrative image · fictional property') : 'Building photo tour'}</span></div>
      {photos.length > 1 && <div className="ll-photo-tour-controls">
        <button type="button" aria-label="Previous photo" onClick={() => setIndex((current + photos.length - 1) % photos.length)}><ChevronLeft size={18} /></button>
        <button type="button" aria-label="Next photo" onClick={() => setIndex((current + 1) % photos.length)}><ChevronRight size={18} /></button>
      </div>}
    </figcaption>
  </figure>;
}

function LobbyPage({ snapshot, property, onAction, demo = false, initialLocation = 'entrance', demoLobbyPhoto }: {
  snapshot: PortalSnapshot; property: Property | null; demo?: boolean; initialLocation?: string; demoLobbyPhoto?: string;
  onAction: (kind: ActionInputAction, targetId?: string, data?: Dict, manager?: boolean) => Promise<unknown>;
}) {
  const [selected, setSelected] = useState(initialLocation);
  const [tab, setTab] = useState<'events' | 'marketplace'>('events');
  const [modal, setModal] = useState<'event' | 'listing' | null>(null);
  const [pending, setPending] = useState(false);
  const [editing, setEditing] = useState<Dict | null>(null);
  const [report, setReport] = useState<{ type: 'event' | 'listing'; id: string } | null>(null);
  const [feedback, setFeedback] = useState('');
  const settings = asRecord(snapshot.settings);
  const eventsEnabled = settings.eventsEnabled !== false;
  const marketplaceEnabled = settings.marketplaceEnabled !== false;
  const canPost = settings.residentPostingEnabled !== false;
  const areas = lobbyAreas.filter(({ id }) => id === 'swap_shelf' ? marketplaceEnabled : !['community_room', 'courtyard'].includes(id) || eventsEnabled);
  const active = areas.find(({ id }) => id === selected) ?? areas[0];
  const events = eventsEnabled ? rows(snapshot.events) : [];
  const listings = marketplaceEnabled ? rows(snapshot.listings) : [];
  const photos = rows(snapshot.gallery).filter((item) => item.published === true);
  const areaPhotos = photos.filter((item) => item.location === active.id);
  const demoUpload = demo && active.id === 'entrance' ? demoLobbyPhoto : undefined;
  const demoPhoto = demo ? demoUpload || `${basePath}/${active.demoImage}` : undefined;
  const notice = rows(snapshot.notices)[0];
  const event = events.find((item) => item.status === 'approved' && (demo || new Date(String(item.startsAt)) > new Date()) && String(item.location).toLowerCase().includes(active.id === 'courtyard' ? 'courtyard' : 'community'));
  const listing = listings.find((item) => item.status === 'available');
  const currentTab = tab === 'events' && !eventsEnabled ? 'marketplace' : tab === 'marketplace' && !marketplaceEnabled ? 'events' : tab;
  const [detail, setDetail] = useState('');
  const run = async (kind: ActionInputAction, id?: string, data?: Dict) => {
    setPending(true);
    setFeedback('');
    try {
      const result = await onAction(kind, id, data, false);
      setFeedback(result ? 'Saved.' : 'That change couldn’t be saved. Please try again.');
      return result;
    } finally { setPending(false); }
  };
  const eventButton = (item: Dict) => <Button variant={item.isGoing ? 'secondary' : ''} disabled={pending}
    onClick={() => void run(item.isGoing ? 'cancel_rsvp' : 'rsvp_event', String(item.id))}>{item.isGoing ? 'Cancel RSVP' : 'RSVP'}{item.isGoing ? <Check size={15} /> : <ArrowRight size={15} />}</Button>;
  const jump = (next: 'events' | 'marketplace', id: string) => {
    setTab(next);
    setDetail(id);
    requestAnimationFrame(() => document.getElementById('community-board')?.focus());
  };
  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.currentTarget));
    const kind = modal === 'event' ? (editing ? 'update_event' : 'create_event') : (editing ? 'update_listing' : 'create_listing');
    const result = await run(kind, editing ? String(editing.id) : undefined, {
      ...data, ...(modal === 'event' ? { startsAt: new Date(String(data.startsAt)).toISOString() } : {}),
    });
    if (result) { setModal(null); setEditing(null); }
  };
  return <div className="ll-lobby-editorial">
    <PageHead kicker={property?.name || 'BUILDING COMMUNITY'} title="The Lobby">Find out what’s happening and make yourself at home.</PageHead>
    <div className="ll-explore-grid">
      <section aria-label="Explore your building">
        <LobbyPhotoTour key={active.id} name={active.name} photos={areaPhotos} demoPhoto={demoPhoto} demo={demo} demoUpload={Boolean(demoUpload)} />
        <nav className="ll-location-buttons" aria-label="Lobby locations">{areas.map(({ id, name, icon: Icon }) =>
          <button key={id} type="button" aria-pressed={id === active.id} onClick={() => setSelected(id)}><Icon size={16} />{name}</button>)}</nav>
      </section>
      <Card className="ll-location-preview">
        <p className="ll-kicker">{active.name}</p>
        <div aria-live="polite">
          <h2>{active.id === 'noticeboard' && notice ? String(notice.title) : event && ['courtyard', 'community_room'].includes(active.id) ? String(event.title) : active.id === 'swap_shelf' && listing ? String(listing.title) : active.title}</h2>
          {active.id === 'entrance' && <><p>Get to know the shared spaces at {property?.name}.</p>{demo ? <details><summary>View building photo</summary><img className="ll-preview-image" src={`${basePath}/willow-court-lobby.jpg`} alt="Illustrative photo of the fictional Willow Court lobby" /></details> : photos.length ? <details><summary>Open gallery</summary>{photos.map((item) => <figure key={String(item.id)}><PrivateImage className="ll-preview-image" objectPath={String(item.objectPath)} alt={String(item.altText)} /><figcaption>{String(item.caption || '')}</figcaption></figure>)}</details> : <p className="ll-copy">Building photos will appear here when published.</p>}</>}
          {active.id === 'leasing_desk' && <div className="ll-action-row"><Link className="ll-btn secondary" href={demo ? '/demo' : '/rent'}>Rent and charges</Link>{!demo && <Link className="ll-link" href="/documents">Documents</Link>}</div>}
          {active.id === 'noticeboard' && <><p className="ll-kicker">From management</p><p>{notice ? String(notice.summary) : 'No notices have been published yet.'}</p></>}
          {['courtyard', 'community_room'].includes(active.id) && <><p>{event ? String(event.description) : 'No upcoming gatherings in this space.'}</p>{event && <><p className="ll-copy">Hosted by a neighbor · {event.isGoing ? 'You’re going' : `${event.attendeeCount ?? 0} going`}</p>{eventButton(event)}</>}</>}
          {active.id === 'swap_shelf' && <><p>{listing ? String(listing.description) : 'There are no available items right now.'}</p>{listing && <Button variant="secondary" onClick={() => jump('marketplace', String(listing.id))}>View listing <ArrowRight size={15} /></Button>}</>}
        </div>
      </Card>
    </div>
    {(eventsEnabled || marketplaceEnabled) && <Card className="ll-community-board">
      <div className="ll-row ll-between ll-board-header">
        <div id="community-board" tabIndex={-1}><p className="ll-kicker">AROUND THE BUILDING</p><h2>Community board</h2></div>
        {canPost && <Button onClick={() => { setEditing(null); setModal(currentTab === 'events' ? 'event' : 'listing'); }}><Plus size={16} />{currentTab === 'events' ? 'Host an event' : 'List an item'}</Button>}
      </div>
      <div className="ll-location-buttons" aria-label="Community view">
        {eventsEnabled && <button aria-pressed={currentTab === 'events'} onClick={() => setTab('events')}>Events</button>}
        {marketplaceEnabled && <button aria-pressed={currentTab === 'marketplace'} onClick={() => setTab('marketplace')}>Marketplace</button>}
      </div>
      {currentTab === 'events' && (events.length ? events.map((item) => <article className="ll-board-record" key={String(item.id)}>
        <div><p className="ll-kicker">Hosted by a neighbor</p><h3>{String(item.title)}</h3><p>{String(item.description)}</p><small>{fmtDate(String(item.startsAt))} · {String(item.location)} · {item.isGoing ? 'You’re going' : String(item.status)}</small></div>
        <div className="ll-action-row">{item.status === 'approved' && eventButton(item)}
          {!demo && item.hostMembershipId === snapshot.membership?.id && item.status !== 'cancelled' && <><Button variant="secondary" onClick={() => { setEditing(item); setModal('event'); }}>Edit event</Button><Button variant="secondary" disabled={pending} onClick={() => void run('cancel_event', String(item.id))}>Cancel event</Button></>}
          {!demo && item.status === 'approved' && <Button variant="ghost" onClick={() => setReport({ type: 'event', id: String(item.id) })}>Report event</Button>}</div>
      </article>) : <p className="ll-empty">There are no events yet.</p>)}
      {currentTab === 'marketplace' && (listings.length ? listings.map((item) => <article className="ll-board-record" key={String(item.id)}>
        {demo && item.id === 'demo-oak-desk' && <img className="ll-item-thumb" src={`${basePath}/oak-desk.jpg`} alt="Fictional oak desk listing" />}
        <div><p className="ll-kicker">{String(item.status)}</p><h3>{String(item.title)}</h3><p>{String(item.description)}</p><small>{Number(item.priceCents) > 0 ? dollars(Number(item.priceCents)) : 'Free'} · {String(item.condition || 'Good condition')}</small>
        {detail === item.id && <>{rows(item.messages).map((message) => <p key={String(message.id)}>{String(message.body)}</p>)}
          {item.ownerMembershipId !== snapshot.membership?.id && !demo && <form className="ll-form" onSubmit={async (e) => { e.preventDefault(); const form = e.currentTarget; if (await run('send_listing_message', String(item.id), { body: new FormData(form).get('message') })) form.reset(); }}><label className="ll-field">Private message<input name="message" required maxLength={2000} /></label><Button type="submit" disabled={pending}>Send to seller</Button></form>}
          {!demo && item.ownerMembershipId === snapshot.membership?.id && <><Button variant="secondary" onClick={() => { setEditing(item); setModal('listing'); }}>Edit listing</Button>{rows(item.messages).filter((message) => message.recipientMembershipId === snapshot.membership?.id).map((message) => <form key={String(message.id)} className="ll-form" onSubmit={async (e) => { e.preventDefault(); const form = e.currentTarget; if (await run('send_listing_message', String(item.id), { body: new FormData(form).get('reply'), replyTo: String(message.id) })) form.reset(); }}><label className="ll-field">Reply to “{String(message.body)}”<input name="reply" required maxLength={2000} /></label><Button type="submit" disabled={pending}>Send private reply</Button></form>)}</>}
          {!demo && <Button variant="ghost" onClick={() => setReport({ type: 'listing', id: String(item.id) })}>Report listing</Button>}
          {(demo || item.ownerMembershipId === snapshot.membership?.id) && <div className="ll-action-row">{['available', 'reserved', 'sold'].filter((status) => status !== item.status).map((status) => <Button key={status} variant="secondary" disabled={pending} onClick={() => void run('update_listing', String(item.id), { status })}>Mark {status}</Button>)}</div>}
        </>}</div>
        <Button variant="secondary" onClick={() => setDetail(detail === item.id ? '' : String(item.id))}>{detail === item.id ? 'Close details' : 'View listing'}</Button>
      </article>) : <p className="ll-empty">The swap shelf is clear.</p>)}
    </Card>}
    <p className="ll-feedback" role="status">{feedback}</p>
    {report && <dialog open className="ll-modal ll-lobby-dialog" aria-labelledby="report-title"><div className="ll-modal-head"><h2 id="report-title">Report {report.type}</h2><button className="ll-close" onClick={() => setReport(null)} aria-label="Close"><X size={18} /></button></div><form className="ll-form" onSubmit={async (e) => { e.preventDefault(); if (await run('report_content', report.id, { contentType: report.type, reason: new FormData(e.currentTarget).get('reason') })) setReport(null); }}><label className="ll-field">Reason<textarea name="reason" required maxLength={2000} /></label><p role="status">{feedback}</p><Button type="submit" disabled={pending}>Send report</Button></form></dialog>}
    {modal && <dialog open className="ll-modal ll-lobby-dialog" aria-labelledby="lobby-modal-title">
      <div className="ll-modal-head"><h2 id="lobby-modal-title">{modal === 'event' ? (editing ? 'Edit event' : 'Host an event') : (editing ? 'Edit listing' : 'List an item')}</h2><button className="ll-close" onClick={() => setModal(null)} aria-label="Close"><X size={18} /></button></div>
      <form className="ll-form" onSubmit={(e) => void submit(e)}>
        <label className="ll-field">Title<input name="title" required maxLength={120} defaultValue={String(editing?.title || '')} /></label>
        <label className="ll-field">Description<textarea name="description" required maxLength={2000} defaultValue={String(editing?.description || '')} /></label>
        {modal === 'event' ? <><label className="ll-field">Date and time<input name="startsAt" type="datetime-local" required defaultValue={localDateTime(editing?.startsAt)} /></label><label className="ll-field">Location<input name="location" required placeholder="Courtyard" defaultValue={String(editing?.location || '')} /></label><label className="ll-field">Capacity (optional)<input name="capacity" type="number" min="1" max="1000" defaultValue={String(editing?.capacity || '')} /></label></> :
        <><label className="ll-field">Condition<select name="condition" defaultValue={String(editing?.condition || 'Good')}><option>Good</option><option>Like new</option><option>Fair</option></select></label><label className="ll-field">Price<input name="price" type="number" min="0" step=".01" placeholder="Free" defaultValue={editing ? Number(editing.priceCents || 0) / 100 : undefined} /></label></>}
        <p role="status">{feedback}</p><Button type="submit" disabled={pending}>{pending ? 'Saving…' : 'Share with neighbors'}</Button>
      </form>
    </dialog>}
  </div>;
}
function ActionModal({ modal, setModal, submit, busy, invitation, copied, copyInvite, uploadBusy, units }: {
  modal: 'event' | 'listing' | 'photo' | 'notice' | 'invite' | 'question' | null;
  setModal: (value: 'event' | 'listing' | 'photo' | 'notice' | 'invite' | 'question' | null) => void;
  submit: (event: FormEvent<HTMLFormElement>, type: 'event' | 'listing' | 'photo' | 'notice' | 'invite' | 'question') => void;
  busy: boolean; invitation: string; copied: boolean; copyInvite: () => void; uploadBusy: boolean; units: Dict[];
}) {
  if (!modal) return invitation ? <aside className="ll-modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setModal(null); }}><section className="ll-modal" role="dialog" aria-modal="true" aria-labelledby="invite-link-title"><div className="ll-modal-head"><h2 id="invite-link-title">Share the invite link</h2><button className="ll-close" onClick={() => setModal(null)} aria-label="Close"><X size={18} /></button></div><p className="ll-copy">Email isn’t connected. Copy this unique invitation link and share it directly with the resident.</p><input readOnly value={new URL(invitation, window.location.origin).toString()} aria-label="Invitation link" style={{ width: '100%', margin: '14px 0', padding: 12, border: '1px solid #ddd8cd', borderRadius: 8 }} /><Button onClick={copyInvite}>{copied ? <><Check size={15} /> Copied</> : 'Copy invite link'}</Button></section></aside> : null;
  const title = modal === 'event' ? 'Host a building event' : modal === 'listing' ? 'List an item' : modal === 'photo' ? 'Add a building photo' : modal === 'notice' ? 'Create a notice' : modal === 'invite' ? 'Invite a resident' : 'Ask about a charge';
  return <div className="ll-modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setModal(null); }}><section className="ll-modal" role="dialog" aria-modal="true" aria-labelledby="action-modal-title"><div className="ll-modal-head"><h2 id="action-modal-title">{title}</h2><button className="ll-close" onClick={() => setModal(null)} aria-label="Close"><X size={18} /></button></div><form className="ll-form" onSubmit={(event) => submit(event, modal)}>{modal === 'invite' ? <><label className="ll-field">Resident email<input type="email" name="email" required placeholder="resident@example.com" /></label><label className="ll-field">Apartment<select name="unitId" required defaultValue=""><option value="" disabled>Select an apartment</option>{units.map((unit) => <option key={String(unit.id)} value={String(unit.id)}>{String(unit.label)}</option>)}</select></label><p className="ll-callout">The invitation will be property-scoped. If email delivery is unavailable, you’ll receive a private link to copy and share.</p></> : modal === 'photo' ? <><label className="ll-upload"><Image size={22} /><strong>{uploadBusy ? 'Uploading securely…' : 'Choose a property photo'}</strong><span>JPG, PNG, or WebP · Up to 10 MB</span><input name="file" type="file" accept="image/jpeg,image/png,image/webp" required /></label><label className="ll-field">Alt text<input name="altText" required maxLength={160} placeholder="Describe what’s visible in the photo" /></label><label className="ll-field">Caption<input name="caption" maxLength={250} /></label><label className="ll-field">Location<select name="location"><option value="gallery">Gallery</option>{lobbyAreas.map(({ id, name }) => <option key={id} value={id}>{name}</option>)}</select></label><p className="ll-copy">Files are uploaded directly to private storage using a signed URL.</p></> : <><label className="ll-field">{modal === 'question' ? 'Subject' : 'Title'}<input name="title" required placeholder={modal === 'question' ? 'Question about a charge' : 'Give this update a clear title'} /></label><label className="ll-field">{modal === 'question' ? 'Your question' : 'Details'}<textarea name="description" required placeholder="Add the details people need." /></label>{modal === 'event' && <><label className="ll-field">Date and time<input type="datetime-local" name="date" required /></label><label className="ll-field">Location<input name="location" required placeholder="Community room" /></label></>}{modal === 'listing' && <label className="ll-field">Price<input name="price" placeholder="Free or $ amount" /></label>}{modal === 'notice' && <label className="ll-field">Importance<select name="importance"><option value="routine">Routine</option><option value="important">Important</option></select></label>}</>}<div className="ll-action-row"><Button type="submit" disabled={busy || uploadBusy}>{busy || uploadBusy ? 'Saving…' : modal === 'invite' ? 'Create invitation' : modal === 'photo' ? 'Upload photo' : 'Send to your property'} <ArrowRight size={15} /></Button></div></form></section></div>;
}

function AppRoutes() {
  const auth = useAuth();
  const sessionQuery = useGetSession<SessionResponse>({ query: { enabled: auth.isSignedIn === true, queryKey: [...getGetSessionQueryKey(), auth.userId] } });
  const [, setLocation] = useLocation();
  const path = window.location.pathname.replace(basePath, '') || '/';
  if (path === '/activate') return <InvitationFlow />;
  if (path === '/sign-up' || path.startsWith('/sign-up/')) return <InvitationFlow signup />;
  if (path === '/sign-in' || path.startsWith('/sign-in/')) return <SignInPage />;
  if (path === '/') return <PublicHome authenticated={auth.isSignedIn === true} session={sessionQuery.data} />;
  if (path === '/demo') return <DemoPage />;
  if (['/setup', '/resident', '/lobby', '/rent', '/documents', '/renewals', '/maintenance', '/complaints', '/document-requests', '/amenities', '/profile', '/manager', '/manager/maintenance', '/manager/complaints', '/manager/document-requests', '/owner', '/owner/maintenance', '/owner/complaints', '/owner/document-requests'].includes(path)) return <PortalRouter session={sessionQuery.data} sessionLoading={sessionQuery.isLoading} sessionError={sessionQuery.error} refetchSession={() => { void sessionQuery.refetch(); }} />;
  void setLocation;
  return <NotFoundPage />;
}
const homeBackgrounds = [
  { id: 'white', label: 'Clean white' },
  { id: 'black', label: 'Black' },
  { id: 'sand', label: 'Warm sand' },
  { id: 'sage', label: 'Soft sage' },
  { id: 'mist', label: 'Blue mist' },
  { id: 'blush', label: 'Soft blush' },
] as const;
const homeBackgroundKey = 'lease-lobby-home-background';

function ResidentHomeLayout({ propertyName, unit, photo, children }: {
  propertyName: string; unit?: string | null; photo?: ReactNode; children: ReactNode;
}) {
  const [background, setBackground] = useState(() => {
    try {
      const saved = localStorage.getItem(homeBackgroundKey);
      return homeBackgrounds.find(({ id }) => id === saved)?.id ?? 'white';
    } catch {
      return 'white';
    }
  });

  function changeBackground(value: string) {
    const option = homeBackgrounds.find(({ id }) => id === value);
    if (!option) return;
    setBackground(option.id);
    try {
      localStorage.setItem(homeBackgroundKey, option.id);
    } catch {
      // The current selection still works when browser storage is unavailable.
    }
  }

  return <div className="ll-resident-home" data-background={background}>
    <header className="ll-resident-heading">
      <div className="ll-resident-property-image">
        <Building2 size={24} aria-hidden="true" />
        {photo}
      </div>
      <div className="ll-resident-identity"><h1>{propertyName}</h1><p>{unit ? (/^apartment\b/i.test(unit) ? unit : `Apartment ${unit}`) : 'Resident portal'}</p></div>
      <label className="ll-background-control">
        <span>Background</span>
        <select value={background} onChange={(event) => changeBackground(event.currentTarget.value)}>
          {homeBackgrounds.map(({ id, label }) => <option key={id} value={id}>{label}</option>)}
        </select>
      </label>
    </header>
    {children}
  </div>;
}

function BuildingUpdates({ notice, children, navigate }: {
  notice?: Dict; children?: ReactNode; navigate?: (view: string, location?: string) => void;
}) {
  const noticeLink = <><Bell size={16} aria-hidden="true" /> Noticeboard <ArrowRight size={15} aria-hidden="true" /></>;
  return <section className="ll-home-column ll-overview-lobby" aria-labelledby="building-updates-heading">
    <div className="ll-column-title"><h2 id="building-updates-heading">Building updates</h2></div>
    <div className="ll-building-updates">
      {notice ? <article className="ll-home-notice">
        <p className="ll-notice-source"><Bell size={14} aria-hidden="true" /> From management {notice.urgent === true && <span>Important</span>}</p>
        <h3>{valueOf(notice, ['title'])}</h3>
        <p className="ll-home-notice-summary">{valueOf(notice, ['summary', 'body'])}</p>
      </article> : <p className="ll-home-notice">No new building notices.</p>}
      {children}
      {navigate
        ? <button className="ll-home-notice-link" type="button" onClick={() => navigate('lobby', 'noticeboard')}>{noticeLink}</button>
        : <Link className="ll-home-notice-link" href="/lobby?location=noticeboard">{noticeLink}</Link>}
    </div>
  </section>;
}

function ResidentSpaces({ photos, navigate, demoLobbyPhoto, eventsEnabled = true }: {
  photos?: Dict[]; navigate?: (view: string, location?: string) => void; demoLobbyPhoto?: string; eventsEnabled?: boolean;
}) {
  const spaces = lobbyAreas.filter(({ id }) => id === 'entrance' || (eventsEnabled && ['community_room', 'courtyard'].includes(id)));
  return <section className="ll-resident-spaces" aria-labelledby="resident-spaces-heading">
    <div className="ll-column-title">
      <h2 id="resident-spaces-heading">Shared spaces</h2>
      {navigate
        ? <button type="button" className="ll-link" onClick={() => navigate('lobby')}>Open the Lobby <ArrowRight size={16} /></button>
        : <Link className="ll-link" href="/lobby">Open the Lobby <ArrowRight size={16} /></Link>}
    </div>
    <div className="ll-resident-spaces-grid">
      {spaces.map(({ id, name, icon: Icon, demoImage }) => {
        const path = valueOf(photos?.find((item) => item.location === id) ?? {}, ['objectPath']);
        if (!navigate && !path) return null;
        const content = <><span className="ll-space-photo"><Icon size={30} aria-hidden="true" />{navigate
          ? <img src={id === 'entrance' && demoLobbyPhoto ? demoLobbyPhoto : `${basePath}/${demoImage}`} alt="" loading="lazy" />
          : <PrivateImage objectPath={path} alt="" />}</span><strong>{name}</strong><ArrowRight size={16} aria-hidden="true" /></>;
        return navigate
          ? <button key={id} type="button" className="ll-space-link" onClick={() => navigate('lobby', id)}>{content}</button>
          : <Link key={id} className="ll-space-link" href={`/lobby?location=${id}`}>{content}</Link>;
      })}
    </div>
  </section>;
}

function ResidentShortcuts({ navigate, updates }: {
  navigate?: (view: string) => void;
  updates?: Partial<Record<string, string>>;
}) {
  const actions = [
    { id: 'maintenance', title: 'Maintenance', subtitle: 'Request a repair', icon: Wrench },
    { id: 'complaints', title: 'Complaints', subtitle: 'Contact management privately', icon: MessageCircle },
    { id: 'document-requests', title: 'Request documents', subtitle: 'Get a lease or statement', icon: FileText },
    { id: 'amenities', title: 'Book an amenity', subtitle: 'View the availability calendar', icon: CalendarDays },
  ];
  return <section className="ll-overview-services" aria-labelledby="resident-services-heading">
    <div className="ll-column-title"><h2 id="resident-services-heading">Resident services</h2></div>
    <div className="ll-resident-shortcuts">
    {actions.map(({ id, title, subtitle, icon: Icon }) => {
      const content = <><span className="ll-shortcut-icon"><Icon size={19} aria-hidden="true" /></span><span><strong>{title}</strong><small className={updates?.[id] ? 'll-shortcut-update' : undefined}>{updates?.[id] || subtitle}</small></span><ArrowRight className="ll-shortcut-arrow" size={16} aria-hidden="true" /></>;
      return navigate
        ? <button key={id} className="ll-shortcut" type="button" onClick={() => navigate(id)}>{content}</button>
        : <Link key={id} className="ll-shortcut" href={`/${id}`}>{content}</Link>;
    })}
    </div>
  </section>;
}

function DemoHome({ snapshot, balance, payment, photo, lobbyPhoto, updates, navigate, rsvp }: {
  snapshot: PortalSnapshot; balance: number; payment: string; photo: string;
  lobbyPhoto: string; updates: Partial<Record<string, string>>;
  navigate: (view: string, location?: string) => void;
  rsvp: (going: boolean, eventId: string) => void;
}) {
  const [showCharges, setShowCharges] = useState(false);
  const event = rows(snapshot.events).find((item) => item.id === 'demo-courtyard-tea');
  const notice = rows(snapshot.notices)[0];
  const cover = photo || `${basePath}/willow-court-editorial.jpg`;
  return <ResidentHomeLayout propertyName="Willow Court" unit="3B" photo={<img src={cover} alt="" />}>
    <div className="ll-resident-overview">
      <section className="ll-home-column ll-overview-lease" aria-labelledby="lease-column">
        <div className="ll-column-title"><h2 id="lease-column">Rent &amp; lease</h2></div>
        <div className="ll-ledger">
          <div className="ll-ledger-main">
            <div><p className="ll-card-label">Total due</p><strong className="ll-home-balance">{dollars(balance)}</strong></div>
            <span className={`ll-state ${payment === 'confirmed' ? 'is-paid' : ''}`}>{payment === 'confirmed' ? 'Paid' : payment === 'pending' ? 'Payment pending' : 'Due November 1'}</span>
          </div>
          <div className="ll-ledger-links"><button type="button" aria-expanded={showCharges} aria-controls="demo-charge-preview" onClick={() => setShowCharges(!showCharges)}>See what changed <ChevronDown size={16} /></button><button type="button" className="ll-rent-action" onClick={() => navigate('rent')}>View rent details <ArrowRight size={15} /></button></div>
          {showCharges && <div id="demo-charge-preview" className="ll-charge-preview"><div><span>Previous total</span><strong>$2,100.00</strong></div><div><span>New utility charge</span><strong>+$45.00</strong></div><button className="ll-link" onClick={() => navigate('rent')}>Open sample statement <ArrowRight size={14} /></button></div>}
        </div>
        <button className="ll-task-tile" onClick={() => navigate('documents')}>
          <span className="ll-task-icon"><FileText size={20} /></span><span><small>YOUR NEXT ACTION</small><strong>Replace your insurance document</strong><span>The expiration date was missing.</span></span><ArrowRight size={18} />
        </button>

      </section>
      <ResidentShortcuts navigate={navigate} updates={updates} />
      <BuildingUpdates notice={notice} navigate={navigate}>
        {event && <div className="ll-quick-event">
          <span className="ll-shortcut-icon"><CalendarDays size={20} aria-hidden="true" /></span>
          <div><strong>{String(event.title)}</strong><small>{fmtDate(String(event.startsAt))} · {String(event.location)}</small><small>Hosted by a neighbor</small></div>
          <button aria-pressed={Boolean(event.isGoing)} onClick={() => rsvp(!event.isGoing, String(event.id))}>{event.isGoing ? <><Check size={15} /> Going</> : <>RSVP <Plus size={15} /></>}</button>
        </div>}
      </BuildingUpdates>
      <ResidentSpaces navigate={navigate} demoLobbyPhoto={lobbyPhoto} />
    </div>
  </ResidentHomeLayout>;
}

function DemoPage() {
  const [bookings, setBookings] = useState<Booking[]>(() => demoBookings(localDay()));
  const [role, setRole] = useState<'resident' | 'manager'>('resident');
  const search = useSearch();
  const preview = new URLSearchParams(search).get('preview');
  const previewLocation = preview === 'events' ? 'community_room' : preview === 'marketplace' ? 'swap_shelf' : 'entrance';
  const [view, setView] = useState(preview === 'building' || preview === 'events' || preview === 'marketplace' ? 'lobby' : 'home');
  const [lobbyLocation, setLobbyLocation] = useState(previewLocation);
  const navigate = (next: string, location = 'entrance') => {
    setLobbyLocation(location);
    setView(next);
    window.scrollTo(0, 0);
  };
  const [snapshot, setSnapshot] = useState<PortalSnapshot>(() => structuredClone(demoSnapshot) as unknown as PortalSnapshot);
  const [payment, setPayment] = useState<'idle' | 'pending' | 'confirmed' | 'failed'>('idle');
  const [question, setQuestion] = useState('');
  const [reply, setReply] = useState('');
  const [photo, setPhoto] = useState('');
  const [lobbyPhoto, setLobbyPhoto] = useState('');
  const [lobbyPhotoError, setLobbyPhotoError] = useState('');
  useEffect(() => () => { if (lobbyPhoto) URL.revokeObjectURL(lobbyPhoto); }, [lobbyPhoto]);
  useEffect(() => () => { if (photo) URL.revokeObjectURL(photo); }, [photo]);
  const demoAction = async (action: ActionInputAction, id?: string, data?: Dict) => {
    setSnapshot((current) => {
      if (action === 'rsvp_event' || action === 'cancel_rsvp') {
        const going = action === 'rsvp_event';
        return { ...current, events: rows(current.events).map((item) => item.id === id && item.isGoing !== going
          ? { ...item, isGoing: going, attendeeCount: Number(item.attendeeCount ?? 0) + (going ? 1 : -1) } : item) };
      }
      if (action === 'update_listing') return { ...current, listings: rows(current.listings).map((item) => item.id === id ? { ...item, ...data } : item) };
      if (action === 'create_event') return { ...current, events: [...rows(current.events), { ...data, id: crypto.randomUUID(), status: 'approved', attendeeCount: 0, isGoing: false }] };
      if (action === 'create_listing') return { ...current, listings: [...rows(current.listings), { ...data, id: crypto.randomUUID(), status: 'available', priceCents: Math.round(Number(data?.price || 0) * 100) }] };
      return current;
    });
    return true;
  };
  type DemoRequestKind = 'maintenance' | 'complaints' | 'document-requests';
  const [maintenanceRequests, setMaintenanceRequests] = useState<(MaintenanceRequest & { kind: DemoRequestKind })[]>([]);
  const maintenancePhotoUrls = useRef<string[]>([]);
  useEffect(() => () => maintenancePhotoUrls.current.forEach((url) => URL.revokeObjectURL(url)), []);
  const demoRequests = (kind: DemoRequestKind): NonNullable<Parameters<typeof Maintenance>[0]['demo']> => ({
    requests: maintenanceRequests.filter((item) => item.kind === kind),
    create: (input, photo) => {
      const demoPhoto = photo ? URL.createObjectURL(photo) : undefined;
      if (demoPhoto) maintenancePhotoUrls.current.push(demoPhoto);
      const now = new Date().toISOString();
      setMaintenanceRequests((items) => [{ ...input, kind, demoPhoto, createdAt: now, updatedAt: now, unitLabel: '3B', status: 'submitted' }, ...items]);
    },
    update: (id, { status, document, managementResponse }) => {
      const demoDocument = document ? URL.createObjectURL(document) : undefined;
      if (demoDocument) maintenancePhotoUrls.current.push(demoDocument);
      setMaintenanceRequests((items) => items.map((item) => item.id === id
        ? {
          ...item, status,
          demoDocument: demoDocument ?? item.demoDocument,
          managementResponse: managementResponse ?? item.managementResponse,
          updatedAt: new Date().toISOString(),
        } : item));
    },
  });
  const [staffInbox, setStaffInbox] = useState<DemoRequestKind>('maintenance');
  const tabs = primaryHomeLinks.map(({ path, label, icon }) => ({ id: path === '/resident' ? 'home' : path.slice(1), label, icon }));
  const updates: Partial<Record<string, string>> = {};
  for (const kind of ['maintenance', 'complaints', 'document-requests'] as const) {
    const requests = maintenanceRequests.filter((item) => item.kind === kind);
    const count = requests.filter((item) => item.status !== 'completed').length;
    if (kind === 'document-requests' && requests.some((item) => item.demoDocument)) updates[kind] = 'Document ready to download';
    else if (kind === 'complaints' && requests.some((item) => item.managementResponse)) updates[kind] = 'View management response';
    else if (count) updates[kind] = `${count} open ${count === 1 ? 'request' : 'requests'}`;
  }
  const balance = payment === 'confirmed' ? 0 : 214500;
  return <div className="ll-app ll-demo">
    <header className="ll-header ll-discovery-header">
      <Brand />
      {role === 'resident' && <nav className="ll-discovery-nav" aria-label="Demo navigation">{tabs.map(({ id, label, icon: Icon }) => <button key={id} aria-current={view === id ? 'page' : undefined} onClick={() => navigate(id)}><Icon size={19} strokeWidth={1.7} />{label}</button>)}</nav>}
      <div className="ll-header-actions"><label className="ll-sr-only" htmlFor="demo-role">Demo role</label><select id="demo-role" value={role} onChange={(event) => { setRole(event.target.value as typeof role); window.scrollTo(0, 0); }}><option value="resident">Resident demo</option><option value="manager">Manager demo</option></select>{portfolioDemo ? <a className="ll-icon-btn" href="/cases/lease-and-lobby.html" aria-label="Return to case study"><X size={18} /></a> : <Link className="ll-icon-btn" href="/" aria-label="Exit demo"><X size={18} /></Link>}</div>
    </header>
    <div className="ll-frame">
      <main className="ll-main"><div className="ll-content">
        {role === 'manager' ? <>
          <PageHead kicker="WILLOW COURT · BUILDING MANAGER · DEMO" title="Building workspace">Review resident requests and preview how building photos will look.</PageHead>
          <div className="ll-location-buttons" role="group" aria-label="Management inbox">
            <button type="button" aria-pressed={staffInbox === 'maintenance'} onClick={() => setStaffInbox('maintenance')}>Maintenance requests</button>
            <button type="button" aria-pressed={staffInbox === 'complaints'} onClick={() => setStaffInbox('complaints')}>Complaints</button>
            <button type="button" aria-pressed={staffInbox === 'document-requests'} onClick={() => setStaffInbox('document-requests')}>Document requests</button>
          </div>
          <Maintenance key={staffInbox} staff complaint={staffInbox === 'complaints'} documents={staffInbox === 'document-requests'} demo={demoRequests(staffInbox)} />
          <div className="ll-grid"><Card><p className="ll-kicker">WORK QUEUE</p><h2>Resident requests</h2>{question ? <form className="ll-form" onSubmit={(event) => { event.preventDefault(); setReply(String(new FormData(event.currentTarget).get('reply'))); }}><h3>Utility charge · Maya</h3><p>{question}</p>{reply ? <p>Replied: {reply}</p> : <><label className="ll-field">Reply<textarea name="reply" required /></label><Button type="submit">Save demo reply</Button></>}</form> : <p>No rent questions yet. Send one from the resident demo to see it here.</p>}</Card><Card><p className="ll-kicker">PROPERTY PROFILE</p><h2>Building &amp; Photos</h2><p>Preview a cover photo for Willow Court. This preview stays in this browser tab.</p>{photo && <img className="ll-preview-image" src={photo} alt="Willow Court cover preview" />}<label className="ll-field">Preview a cover photo<input type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => { const file = e.currentTarget.files?.[0]; if (file && file.size <= 10 * 1024 * 1024 && ['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) setPhoto(URL.createObjectURL(file)); }} /></label><label className="ll-field">Try a lobby photo<input type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => {
            const file = e.currentTarget.files?.[0];
            if (!file) return;
            if (file.size > 10 * 1024 * 1024 || !['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
              setLobbyPhotoError('Choose a JPEG, PNG, or WebP image under 10 MB.');
              return;
            }
            setLobbyPhotoError('');
            setLobbyPhoto(URL.createObjectURL(file));
          }} /></label>{lobbyPhotoError && <ErrorNotice message={lobbyPhotoError} />}{lobbyPhoto && <p className="ll-copy" role="status">Photo ready. Switch to Resident demo and open the Lobby entrance to see it.</p>}</Card></div>
        </> : view === 'lobby' ? <LobbyPage demo demoLobbyPhoto={lobbyPhoto} initialLocation={lobbyLocation} snapshot={snapshot} property={snapshot.property ?? null} onAction={demoAction} /> :
        view === 'amenities' ? <><PageHead kicker="WILLOW COURT · DEMO" title="Amenities calendar">See which times are booked and try reserving a shared space. Demo reservations stay in this tab.</PageHead><Amenities demo={{
          bookings,
          reserve: (slot) => setBookings((items) => items.some((item) => item.amenity === slot.amenity && item.day === slot.day && item.slot === slot.slot)
            ? items : [...items, { ...slot, id: crypto.randomUUID() }]),
          cancel: (id) => setBookings((items) => items.filter((item) => item.id !== id)),
        }} /></> :
        view === 'document-requests' ? <><PageHead kicker="WILLOW COURT · DEMO" title="Document requests">Ask management for a lease copy, rent statement, or another document. Demo requests stay in this tab.</PageHead><Maintenance key="resident-document-requests" documents demo={demoRequests('document-requests')} /></> :
        view === 'complaints' ? <><PageHead kicker="WILLOW COURT · DEMO" title="Complaints">Try sending a private message to building management. Demo messages stay in this tab.</PageHead><Maintenance key="resident-complaints" complaint demo={demoRequests('complaints')} /></> :
        view === 'maintenance' ? <><PageHead kicker="WILLOW COURT · DEMO" title="Maintenance">Try submitting a request for apartment 3B. Demo requests stay in this tab.</PageHead><Maintenance key="resident-maintenance" demo={demoRequests('maintenance')} /></> :
        view === 'rent' ? <><PageHead kicker="WILLOW COURT · DEMO" title="Rent & charges">Fictional charges and a simulated payment for apartment 3B.</PageHead><div className="ll-grid"><Card className="ll-statement-card"><p className="ll-kicker">TOTAL DUE</p><p className="ll-amount">{dollars(balance)}</p><p>{payment === 'confirmed' ? 'Demo receipt · Payment confirmed for $2,145.' : payment === 'pending' ? 'Simulated payment pending. The balance stays due until confirmation.' : payment === 'failed' ? 'Simulated payment failed. Your balance is unchanged.' : 'Due November 1'}</p><details><summary>See what changed</summary><p>The $45 utility charge increased the total from $2,100 to $2,145.</p><details><summary>Open sample statement</summary><p>Base rent · $2,100</p><p>Utilities · $45</p></details></details><div className="ll-action-row">{payment === 'pending' ? <><Button onClick={() => setPayment('confirmed')}>Simulate confirmation</Button><Button variant="secondary" onClick={() => setPayment('failed')}>Simulate failure</Button></> : payment !== 'confirmed' && <Button onClick={() => setPayment('pending')}>{payment === 'failed' ? 'Retry demo payment' : 'Simulate payment'}</Button>}</div></Card><Card><p className="ll-kicker">UTILITY CHARGE · $45</p><h2>Ask about this charge</h2>{question ? <><p>{question}</p><p className="ll-copy">{reply || 'Awaiting the building manager’s reply.'}</p></> : <form className="ll-form" onSubmit={(event) => { event.preventDefault(); setQuestion(String(new FormData(event.currentTarget).get('question'))); }}><label className="ll-field">Your question<textarea name="question" required /></label><Button type="submit">Send demo question</Button></form>}</Card></div></> :
        view === 'documents' ? <><PageHead kicker="WILLOW COURT · DEMO" title="Documents">Fictional lease records for apartment 3B.</PageHead><div className="ll-document-request-entry"><button className="ll-btn" type="button" onClick={() => navigate('document-requests')}>Request documents <ArrowRight size={15} /></button></div><div className="ll-grid"><Card><span className="ll-icon-tile"><FileText size={19} /></span><p className="ll-pill warn ll-document-status">Needs replacement</p><h2>Proof of renters insurance</h2><p>The policy expiration date is missing.</p></Card><Card><span className="ll-icon-tile"><KeyRound size={19} /></span><p className="ll-kicker ll-document-status">SAMPLE RENEWAL</p><h2>Review your renewal</h2><p>Current rent {dollars(214500)} · Proposed rent {dollars(214500)} · No increase</p><p>December 1, 2026 – November 30, 2027 · Respond by November 15, 2026</p></Card></div></> :
        view === 'profile' ? <><PageHead kicker="WILLOW COURT · DEMO" title="Maya Chen">Resident · Apartment 3B</PageHead><Card className="ll-account-card"><span className="ll-account-avatar" aria-hidden="true">MC</span><div><h2>Demo account</h2><p>maya@example.test</p><Link className="ll-btn secondary" href="/demo/invitation">Preview a sample invitation <ArrowRight size={15} /></Link></div></Card></> :
        <DemoHome snapshot={snapshot} balance={balance} payment={payment} photo={photo} lobbyPhoto={lobbyPhoto} updates={updates} navigate={navigate} rsvp={(going, id) => void demoAction(going ? 'rsvp_event' : 'cancel_rsvp', id)} />}
      </div></main>
    </div>
    {role === 'resident' && <nav className="ll-bottom-nav" aria-label="Demo quick navigation">{tabs.map(({ id, label, icon: Icon }) => <button key={id} aria-current={view === id ? 'page' : undefined} onClick={() => navigate(id)}><Icon size={18} />{label}</button>)}</nav>}
  </div>;
}
function DemoInvitation() {
  return <main className="ll-welcome">
    <div className="ll-welcome-top"><Brand /><Link className="ll-link" href="/demo">Back to demo</Link></div>
    <div className="ll-sign-in-grid">
      <section><p className="ll-kicker">SAMPLE RESIDENT INVITATION</p><h1 className="ll-title">You’re invited to Willow Court.</h1>
        <p className="ll-subtitle">Your leasing office invited you to join your building’s private community.</p>
        <Card><div className="ll-row"><span className="ll-icon-tile"><KeyRound size={20} /></span><div><h2>Apartment 3B</h2><p className="ll-copy">Sample verified email · maya@example.test</p></div></div>
          <div className="ll-action-row"><Link className="ll-btn" href="/demo">Join the demo <ArrowRight size={16} /></Link></div></Card>
      </section>
      <aside className="ll-sign-in-art"><img className="ll-preview-image" src={`${basePath}/willow-court-lobby.jpg`} alt="Fictional Willow Court lobby" /><p className="ll-copy">Fictional demo image</p></aside>
    </div>
  </main>;
}

function NotFoundPage() {
  return <div className="ll-welcome"><div className="ll-welcome-top"><Brand /></div><div className="ll-content" style={{ maxWidth: 600, margin: '100px auto' }}><p className="ll-kicker">A WRONG TURN</p><h1 className="ll-title">This page isn’t here.</h1><p className="ll-subtitle">Let’s get you back to a place you can access.</p><Link className="ll-btn" href="/">Return home <ArrowRight size={15} /></Link></div></div>;
}
function ClerkCacheInvalidator() {
  const clerk = useClerk();
  const cache = useQueryClient();
  useEffect(() => {
    let previous = clerk.user?.id;
    return clerk.addListener(({ user }) => {
      if (previous === user?.id) return;
      previous = user?.id;
      for (const path of ['/api/session', '/api/portal', '/api/storage/object', '/api/manager/invitations', 'maintenance', 'amenities']) {
        cache.removeQueries({ queryKey: [path] });
      }
    });
  }, [clerk, cache]);
  return null;
}
function App() {
  return <WouterRouter base={basePath}><QueryClientProvider client={queryClient}><AppEntry /></QueryClientProvider></WouterRouter>;
}

function AppEntry() {
  const [location, navigate] = useLocation();
  const stripBase = (path: string) => basePath && path.startsWith(basePath + '/') ? path.slice(basePath.length) : path;
  if (location === '/demo/invitation' || (portfolioDemo && location === '/demo/invitation/')) return <DemoInvitation />;
  if (location === '/demo' || portfolioDemo) return <DemoPage />;
  if (!clerkPubKey) {
    if (location === '/') return <PublicHome authenticated={false} />;
    if (location === '/sign-in') return <SignInLayout><div className="ll-auth-preview"><p>Resident sign-in is unavailable in this local preview.</p><Link className="ll-btn" href="/demo">Explore the resident demo <ArrowRight size={16} /></Link></div></SignInLayout>;
    return <InviteGuard title="Activate your account" detail="Ask your leasing office for an invitation. Private activation becomes available after authentication is configured." />;
  }
  return <ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} appearance={clerkAppearance} signInUrl={`${basePath}/sign-in`} signUpUrl={`${basePath}/activate`} localization={{ signIn: { start: { title: 'Welcome back', subtitle: 'Use your resident account to continue' } }, signUp: { start: { title: 'Join your building', subtitle: 'Create an account from your verified invitation' } } }} routerPush={(to) => navigate(stripBase(to))} routerReplace={(to) => navigate(stripBase(to), { replace: true })}>
      <ClerkCacheInvalidator /><Switch><Route path="/sign-in/*?" component={SignInPage} /><Route path="/sign-up/*?" component={() => <InvitationFlow signup />} /><Route><AppRoutes /></Route></Switch>
    </ClerkProvider>;
}

export default App;
