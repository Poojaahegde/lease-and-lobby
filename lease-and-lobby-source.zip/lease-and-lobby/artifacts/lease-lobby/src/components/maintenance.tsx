import { useRef, useState, type FormEvent } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ClipboardList, FileText, Plus, Wrench } from 'lucide-react';

const demoCategories: Record<string, readonly string[]> = {
  Plumbing: ['Leak', 'Drain or toilet', 'No hot water'],
  Electrical: ['Outlet or switch', 'Lighting', 'Power issue'],
  'Heating & cooling': ['No heat', 'No cooling', 'Thermostat'],
  Appliances: ['Refrigerator', 'Oven or stove', 'Dishwasher', 'Washer or dryer'],
  'Doors & windows': ['Lock or handle', 'Door', 'Window'],
  'Pest control': ['Insects', 'Rodents', 'Other pests'],
  'General repairs': ['Walls or ceiling', 'Flooring', 'Other'],
};
const demoComplaintCategories = Object.fromEntries(
  ['Noise', 'Pet waste', 'Smoking or vaping', 'Shared spaces', 'Parking', 'Other'].map((name) => [name, []]),
);
const demoDocumentCategories = Object.fromEntries(
  ['Signed lease', 'Lease addendum', 'Rent statement', 'Payment receipt', 'Proof of residency', 'Other'].map((name) => [name, []]),
);
const priorities = { low: 'Low', medium: 'Medium', high: 'High', urgent: 'Urgent' } as const;
type Priority = keyof typeof priorities;
const statuses = { submitted: 'Submitted', in_progress: 'In progress', completed: 'Completed' } as const;
type Status = keyof typeof statuses;
type RequestInput = {
  id: string; category: string; issue: string; location: string; description: string;
  priority: Priority; entryAllowed: boolean; accessInstructions: string;
};
export type MaintenanceRequest = Omit<RequestInput, 'priority'> & {
  priority: Priority | 'routine';
  status: Status; createdAt: string; updatedAt: string; unitLabel: string;
  photoId?: string | null; demoPhoto?: string; documentId?: string | null; demoDocument?: string;
  managementResponse?: string | null;
};
type DemoMaintenance = {
  requests: MaintenanceRequest[];
  create: (input: RequestInput, photo?: File) => void;
  update: (id: string, update: { status: Status; document?: File; managementResponse?: string }) => void;
};

async function request(url: string, options?: RequestInit) {
  const response = await fetch(url, options);
  if (!response.ok) {
    const body = await response.json().catch(() => null);
    throw new Error(body?.error || (response.status === 403 ? 'You don’t have access to these requests.' : 'The request couldn’t be completed. Please try again.'));
  }
  return response;
}

function json(method: string, body: unknown): RequestInit {
  return { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
}

export default function Maintenance({ propertyId, membershipId, staff = false, complaint = false, documents = false, demo }: {
  propertyId?: string; membershipId?: string; staff?: boolean; complaint?: boolean; documents?: boolean; demo?: DemoMaintenance;
}) {
  const kind = documents ? 'document-requests' : complaint ? 'complaints' : 'maintenance';
  const isRepair = kind === 'maintenance';
  const endpoint = `/api/${kind}/${propertyId}`;
  const singular = documents ? 'document request' : complaint ? 'complaint' : 'request';
  const plural = documents ? 'document requests' : complaint ? 'complaints' : 'requests';
  const query = useQuery({
    queryKey: ['maintenance', propertyId, membershipId, staff, kind],
    enabled: !demo && !!propertyId,
    queryFn: async (): Promise<{ requests: MaintenanceRequest[]; categories: Record<string, string[]> }> =>
      (await request(endpoint + (staff ? '?view=staff' : ''))).json(),
  });
  const defaultView = !staff && (documents || complaint) ? 'all' : 'open';
  const [view, setView] = useState<'open' | 'all' | 'new'>(defaultView);
  const [category, setCategory] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const submissionId = useRef<string | undefined>(undefined);
  const pending = useRef(false);
  const categories = demo ? (documents ? demoDocumentCategories : complaint ? demoComplaintCategories : demoCategories) : query.data?.categories ?? {};
  const records = demo?.requests ?? query.data?.requests ?? [];
  const visible = view === 'all' ? records : records.filter((item) => item.status !== 'completed');

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (pending.current) return;
    const data = new FormData(event.currentTarget);
    const value = (name: string) => String(data.get(name) ?? '').trim();
    const description = value('description') || (documents && category !== 'Other' ? `Please share a copy of my ${category.toLowerCase()}.` : '');
    if (description.length < 10) { setError('Describe the issue in at least 10 characters.'); return; }
    const file = data.get('photo');
    const photo = file instanceof File && file.size > 0 ? file : undefined;
    if (photo && (photo.size > 10 * 1024 * 1024 || !['image/jpeg', 'image/png', 'image/webp'].includes(photo.type))) {
      setError('Choose a JPEG, PNG, or WebP image up to 10 MB.'); return;
    }
    submissionId.current ??= crypto.randomUUID();
    const input: RequestInput = {
      id: submissionId.current, category, issue: documents ? category : value('issue'), description,
      location: value('location'), priority: isRepair ? value('priority') as Priority : 'medium',
      entryAllowed: value('entry') === 'yes', accessInstructions: value('access'),
    };
    pending.current = true;
    setBusy(true);
    setError('');
    setMessage('');
    try {
      if (demo) demo.create(input, photo);
      else {
        let photoId: string | undefined;
        if (photo) {
          const upload = await (await request('/api/storage/upload-url', json('POST', {
            propertyId, purpose: 'maintenance_photo', fileName: photo.name, contentType: photo.type, size: photo.size,
          }))).json();
          await request(upload.uploadURL, { method: 'PUT', headers: { 'Content-Type': photo.type }, body: photo });
          photoId = upload.objectPath;
        }
        await request(endpoint, json('POST', { ...input, photoId }));
        await query.refetch();
      }
      submissionId.current = undefined;
      setCategory('');
      setView(defaultView);
      setMessage(documents ? (demo ? 'Demo document request sent.' : 'Your document request was sent to management.') : complaint ? (demo ? 'Demo complaint sent to management.' : 'Your complaint was sent to the management inbox.') : (demo ? 'Demo request submitted.' : 'Your request was submitted to the building team.'));
    } catch (err) { setError(err instanceof Error ? err.message : 'Could not submit the request.'); }
    finally { pending.current = false; setBusy(false); }
  }

  async function update(event: FormEvent<HTMLFormElement>, id: string) {
    event.preventDefault();
    if (pending.current) return;
    const form = event.currentTarget;
    const data = new FormData(form);
    const status = data.get('status') as Status;
    const managementResponse = complaint ? String(data.get('managementResponse') ?? '').trim() || undefined : undefined;
    const file = data.get('document');
    const document = file instanceof File && file.size > 0 ? file : undefined;
    if (documents && status === 'completed' && (!document || document.type !== 'application/pdf' || document.size > 10 * 1024 * 1024)) {
      setError('Choose a PDF up to 10 MB to share.'); return;
    }
    pending.current = true;
    setBusy(true);
    setError('');
    setMessage('');
    try {
      if (demo) demo.update(id, { status, document, managementResponse });
      else {
        let documentId: string | undefined;
        if (document) {
          const upload = await (await request('/api/storage/upload-url', json('POST', {
            propertyId, purpose: 'requested_document', fileName: document.name, contentType: document.type, size: document.size,
          }))).json();
          await request(upload.uploadURL, { method: 'PUT', headers: { 'Content-Type': document.type }, body: document });
          documentId = upload.objectPath;
        }
        await request(`${endpoint}/${id}`, json('PATCH', { status, documentId, managementResponse }));
        await query.refetch();
      }
      if (managementResponse) {
        const field = form.elements.namedItem('managementResponse');
        if (field instanceof HTMLTextAreaElement) field.value = '';
      }
      setMessage(document ? 'Document shared with the resident.' : managementResponse ? 'Response shared with the resident.' : complaint ? 'Complaint status updated.' : 'Request status updated.');
    } catch (err) { setError(err instanceof Error ? err.message : 'Could not update the request.'); }
    finally { pending.current = false; setBusy(false); }
  }

  function changeView(next: typeof view) {
    setError('');
    setMessage('');
    if (view === 'new' && next !== 'new') { setCategory(''); submissionId.current = undefined; }
    setView(next);
  }

  return <section className="ll-maintenance" aria-label={documents ? 'Document requests' : complaint ? 'Complaints inbox' : 'Maintenance requests'}>
    <div className="ll-maintenance-toolbar">
      <div className="ll-location-buttons" role="group" aria-label={`Filter ${plural}`}>
        <button type="button" aria-pressed={view === 'open'} disabled={busy} onClick={() => changeView('open')}>Open {plural}</button>
        <button type="button" aria-pressed={view === 'all'} disabled={busy} onClick={() => changeView('all')}>All {plural}</button>
      </div>
      {!staff && view !== 'new' && <button className="ll-btn" type="button" disabled={!demo && !query.data} onClick={() => changeView('new')}><Plus size={16} /> New {singular}</button>}
    </div>
    {message && <p role="status" className="ll-maintenance-message">{message}</p>}
    {error && <p role="alert" className="ll-error">{error}</p>}
    {!demo && query.isLoading && <p role="status">Loading {plural}…</p>}
    {!demo && query.isError && <p role="alert">Couldn’t load {plural}. <button className="ll-link" type="button" onClick={() => void query.refetch()}>Try again</button></p>}
    {view === 'new' ? <form className="ll-card ll-form ll-maintenance-form" onSubmit={submit}>
      <h2>{documents ? <><FileText size={19} /> Request a document</> : complaint ? <><ClipboardList size={19} /> Send a complaint</> : <><Wrench size={19} /> Request maintenance</>}</h2>
      <p className="ll-callout">{documents ? 'Management will share the requested PDF here when it’s ready.' : complaint ? 'Your message goes to the building management inbox. Other residents cannot see it.' : 'For emergencies, call your building’s emergency maintenance line. For immediate danger, call local emergency services.'}</p>
      <fieldset disabled={busy}>
        <legend>{documents ? 'Which document do you need?' : complaint ? 'What happened?' : 'What needs attention?'}</legend>
        <div className="ll-maintenance-fields">
          <label className="ll-field">{documents ? 'Document type' : 'Category'}<select value={category} onChange={(e) => setCategory(e.currentTarget.value)} required><option value="">{documents ? 'Choose a document' : 'Choose a category'}</option>{Object.keys(categories).map((name) => <option key={name}>{name}</option>)}</select></label>
          {!documents && (complaint ? <label className="ll-field">Subject<input name="issue" required maxLength={80} placeholder="e.g. Repeated late-night noise" /></label> : <label className="ll-field">Issue<select key={category} name="issue" required disabled={!category} defaultValue=""><option value="">Choose an issue</option>{categories[category]?.map((issue) => <option key={issue}>{issue}</option>)}</select></label>)}
          {!documents && <label className="ll-field">Location <small>(optional)</small><input name="location" maxLength={120} placeholder="e.g. Kitchen" /></label>}
          {isRepair && <label className="ll-field">Priority<select name="priority" defaultValue="medium">{Object.entries(priorities).map(([value, label]) => <option value={value} key={value}>{label}</option>)}</select></label>}
        </div>
        <label className="ll-field">{documents ? 'Details' : 'Description'}{documents && category !== 'Other' && <small>(optional)</small>}<textarea name="description" required={!documents || category === 'Other'} minLength={10} maxLength={1500} placeholder={documents ? 'Add a date range or details that will help management find the file.' : complaint ? 'Describe what happened, where, and when.' : 'Tell us what happened and when you first noticed it.'} /></label>
        {isRepair && <label className="ll-field">Add a photo <small>(optional · up to 10 MB)</small><input type="file" name="photo" accept="image/jpeg,image/png,image/webp" /></label>}
      </fieldset>
      {isRepair && <fieldset disabled={busy}>
        <legend>Access to your home</legend>
        <label className="ll-field">Permission to enter<select name="entry" required defaultValue=""><option value="">Choose permission</option><option value="no">No · contact me to arrange a visit</option><option value="yes">Yes · staff may enter while I’m away</option></select></label>
        <label className="ll-field">Access instructions <small>(optional)</small><textarea name="access" maxLength={500} placeholder="e.g. A dog is in the bedroom. Please knock first." /></label>
      </fieldset>}
      <div className="ll-action-row"><button className="ll-btn" type="submit" disabled={busy}>{busy ? 'Sending…' : documents ? 'Send document request' : complaint ? 'Send to management' : 'Submit request'}</button><button className="ll-btn secondary" type="button" disabled={busy} onClick={() => changeView(defaultView)}>Cancel</button></div>
    </form> : (demo || query.isSuccess) && <div className="ll-stack">
      {visible.length === 0 && <div className="ll-card ll-empty"><ClipboardList size={23} /><strong>{view === 'open' ? `No open ${plural}` : `No ${plural} yet`}</strong>{staff ? `New ${plural} from residents will appear here.` : `Your ${plural} and updates will appear here.`}</div>}
      {visible.map((item) => <article className="ll-card ll-maintenance-record" key={item.id}>
        <div className="ll-row ll-between"><p className="ll-kicker">{item.category}{staff ? ` · Apartment ${item.unitLabel}` : ''}</p><span className={`ll-pill ${item.status === 'submitted' ? 'warn' : ''}`}>{documents && item.status === 'completed' ? 'Ready to download' : statuses[item.status]}</span></div>
        <h2>{item.issue}</h2>
        <p className="ll-copy">{isRepair && <>{priorities[item.priority === 'routine' ? 'medium' : item.priority]} priority · </>}{item.location ? `${item.location} · ` : ''}{new Date(item.createdAt).toLocaleDateString()}</p>
        <p className="ll-maintenance-description">{item.description}</p>
        {complaint && item.managementResponse && <div className="ll-callout">
          <strong>Latest response from management</strong>
          <p className="ll-maintenance-description">{item.managementResponse}</p>
        </div>}
        {isRepair && <details><summary>Access details</summary><p>{item.entryAllowed ? 'Entry allowed when the resident is away.' : 'Contact the resident before entering.'}</p>{item.accessInstructions && <p className="ll-maintenance-description">{item.accessInstructions}</p>}</details>}
        {(item.photoId || item.demoPhoto) && <a className="ll-link" target="_blank" rel="noreferrer" href={item.demoPhoto || `/api/storage/object?objectPath=${encodeURIComponent(item.photoId!)}`}>View attached photo</a>}
        {documents && (item.documentId || item.demoDocument) && <a className="ll-btn secondary" download="requested-document.pdf" href={item.demoDocument || `/api/storage/object?objectPath=${encodeURIComponent(item.documentId!)}`}>Download PDF</a>}
        {staff && documents && item.status !== 'completed' && <form className="ll-maintenance-status" onSubmit={(event) => void update(event, item.id)}>
          <input type="hidden" name="status" value="completed" />
          <label className="ll-field">Attach requested PDF<input type="file" name="document" accept="application/pdf" required disabled={busy} /></label>
          <button className="ll-btn" type="submit" disabled={busy}>Share PDF</button>
        </form>}
        {staff && !documents && <form className="ll-maintenance-status" onSubmit={(event) => void update(event, item.id)}>
          {complaint && <label className="ll-field ll-complaint-response">
            Response to resident <small>(optional)</small>
            <textarea name="managementResponse" maxLength={1500} disabled={busy} placeholder="Share what management did or what happens next." />
            {item.managementResponse && <small>A new response replaces the previous one.</small>}
          </label>}
          <label className="ll-field">
            {complaint ? 'Complaint status' : 'Request status'}
            <select key={item.status} name="status" defaultValue={item.status} disabled={busy}>
              {Object.entries(statuses).map(([value, label]) => <option value={value} key={value}>{label}</option>)}
            </select>
          </label>
          <button className="ll-btn secondary" type="submit" disabled={busy}>{complaint ? 'Save complaint update' : 'Save status'}</button>
        </form>}
      </article>)}
    </div>}
  </section>;
}
