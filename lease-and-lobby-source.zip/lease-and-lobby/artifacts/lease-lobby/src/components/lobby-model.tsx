import { useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, Layers2, RotateCcw } from 'lucide-react';
import * as THREE from 'three';

const spots = [
  { id: 'entrance', label: 'Entrance', point: [-3.4, 0.2, 2.6] },
  { id: 'leasing_desk', label: 'Leasing desk', point: [-3.3, 0.8, -1] },
  { id: 'noticeboard', label: 'Noticeboard', point: [-2.4, 1.7, -3] },
  { id: 'community_room', label: 'Community room', point: [0.2, 0.6, -1.7] },
  { id: 'courtyard', label: 'Courtyard', point: [3.1, 0.5, 0] },
  { id: 'swap_shelf', label: 'Swap shelf', point: [0.4, 0.9, 2.1] },
];

export default function LobbyModel({ name, active, enabled, select }: {
  name: string; active: string; enabled: string[]; select: (id: string) => void;
}) {
  const mount = useRef<HTMLDivElement>(null);
  const labels = useRef<Record<string, HTMLButtonElement | null>>({});
  const draw = useRef<() => void>(() => {});
  const orbit = useRef({ yaw: .65, height: 7.7 });
  const drag = useRef<{ x: number; y: number } | null>(null);
  const [exploring, setExploring] = useState(false);
  const [unavailable, setUnavailable] = useState(false);
  const [plan, setPlan] = useState(false);
  const showPlan = plan || unavailable;
  const rotate = (delta: number) => {
    orbit.current.yaw = Math.min(1.18, Math.max(-.15, orbit.current.yaw + delta));
    draw.current();
  };
  useEffect(() => {
    const el = mount.current;
    if (!el) return;
    let renderer: THREE.WebGLRenderer;
    try { renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true }); }
    catch { setUnavailable(true); return; }
    const scene = new THREE.Scene();
    const camera = new THREE.OrthographicCamera();
    const canvas = renderer.domElement;
    canvas.setAttribute('aria-hidden', 'true');
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.17;
    el.append(canvas);
    scene.add(new THREE.HemisphereLight('#fff5dd', '#6c806d', 2.0));
    const sun = new THREE.DirectionalLight('#fff0d4', 3.0);
    sun.position.set(-4, 8, 5);
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    Object.assign(sun.shadow.camera, { left: -8, right: 8, bottom: -8, top: 8, near: .5, far: 24 });
    sun.shadow.normalBias = .025;
    scene.add(sun);
    const block = (x: number, y: number, z: number, w: number, h: number, d: number, color: string) => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshStandardMaterial({ color }));
      mesh.position.set(x, y, z);
      mesh.castShadow = h > .11;
      mesh.receiveShadow = true;
      scene.add(mesh);
    };
    block(0, -.35, 0, 10.5, .6, 7.7, '#bc9b73');
    block(0, -.02, 0, 10.2, .12, 7.4, '#ded0b2');
    for (let x = -4.78; x < 1.83; x += .55) {
      for (let z = -3.25; z < 3.54; z += .55) {
        const tone = Math.round((x + z + 10) * 11) % 3;
        block(x, .058, z, .53, .035, .53, ['#d4bf9a', '#dbc7a3', '#cdb794'][tone]);
      }
    }
    block(-1.3, .09, -3.35, 7.5, .16, .28, '#967d5c');
    block(-1.3, 1.25, -3.44, 7.5, 2.45, .18, '#ecdfc2');
    block(-1.3, 2.49, -3.44, 7.63, .12, .28, '#d3b88f');
    for (const x of [-.35, 1.4]) {
      block(x, 1.53, -3.31, 1.18, 1.25, .12, '#536453');
      block(x, 1.53, -3.24, 1.02, 1.09, .04, '#9ea796');
      block(x, 1.53, -3.2, .045, 1.1, .04, '#536453');
      block(x, 1.52, -3.2, 1.04, .045, .04, '#536453');
      block(x, .91, -3.2, 1.27, .1, .24, '#b39a74');
    }
    block(-4.94, 1.0, -.95, .18, 2, 5.05, '#d2ba98');
    block(3.35, .07, .15, 2.8, .12, 5.8, '#80946a');
    block(3.35, .16, .32, 1.35, .06, 3.4, '#d8c4a0');
    block(-3.3, .44, -1.1, 2.0, .78, .7, '#a96e46');
    block(-3.3, .86, -1.1, 2.1, .12, .8, '#714f36');
    block(-3.6, .96, -1.18, .49, .065, .34, '#cfc6ad');
    block(-3.6, 1.13, -1.26, .52, .32, .06, '#50635b');
    block(-2.61, .96, -.98, .28, .045, .22, '#eee0b9');
    block(-2.4, 1.73, -3.29, 1.65, .93, .14, '#966547');
    for (let i = 0; i < 3; i++) block(-2.87 + i * .42, 1.78, -3.2, .25, .34, .025, i === 1 ? '#e0ae81' : '#f2e5c6');
    block(.15, .15, -1.58, 2.9, .08, 2.55, '#af6b53');
    block(.15, .64, -1.57, 1.5, .12, .87, '#805a3d');
    block(.1, .73, -1.51, .38, .055, .26, '#eee0b9');
    block(.45, .73, -1.51, .23, .055, .22, '#b9825d');
    for (const z of [-2.59, -.58]) block(.15, .56, z, 1.4, .44, .13, '#5a725c');
    for (const x of [-.42, .72]) block(x, .35, -1.57, .12, .55, .55, '#805a3d');
    for (const z of [-2.4, -.76]) block(.15, .35, z, 1.4, .45, .38, '#6c8062');
    for (let y = .24; y < 1.2; y += .38) block(.4, y, 2.16, 1.75, .1, .46, '#9a6845');
    for (const x of [-.42, 1.22]) block(x, .63, 2.16, .12, 1.18, .48, '#9a6845');
    block(.15, .82, 2.16, .28, .28, .28, '#c4825f');
    block(.6, .44, 2.16, .48, .22, .26, '#70856a');
    block(-3.45, 1.07, 2.9, 2.2, .17, .28, '#805a3d');
    for (const x of [-4.44, -2.46]) block(x, .57, 2.9, .15, 1.1, .18, '#805a3d');
    for (let z = -1.35; z < 2; z += .45) block(3.36, .2, z, 1.17, .04, .42, '#c8b48e');
    for (const x of [2.59, 4.10]) {
      block(x, .39, 1.14, .64, .11, .75, '#896449');
      block(x, .58, 1.44, .64, .28, .11, '#896449');
      block(x, .25, 1.14, .11, .28, .52, '#735840');
    }
    const signCanvas = document.createElement('canvas');
    signCanvas.width = 512;
    signCanvas.height = 96;
    const signCtx = signCanvas.getContext('2d');
    const signTexture = new THREE.CanvasTexture(signCanvas);
    if (signCtx) {
      signCtx.fillStyle = '#284c3e';
      signCtx.fillRect(0, 0, 512, 96);
      signCtx.strokeStyle = '#c6b684';
      signCtx.lineWidth = 4;
      signCtx.strokeRect(7, 7, 498, 82);
      signCtx.font = '600 41px Georgia';
      signCtx.fillStyle = '#fff0cc';
      signCtx.textAlign = 'center';
      signCtx.textBaseline = 'middle';
      signCtx.fillText(name, 256, 50, 469);
      signTexture.colorSpace = THREE.SRGBColorSpace;
      const sign = new THREE.Mesh(new THREE.PlaneGeometry(1.85, .35), new THREE.MeshBasicMaterial({ map: signTexture }));
      sign.position.set(-3.45, 1.20, 3.07);
      scene.add(sign);
    }
    for (const [x, z, size] of [[4.17,-2.4,.8],[4.5,2.2,.64],[2.42,-2.34,.54],[-4.5,1.95,.55],[1.4,-2.88,.47]]) {
      block(x, .19, z, size * .65, .34, size * .65, '#b67857');
      const tree = new THREE.Mesh(new THREE.IcosahedronGeometry(size, 1), new THREE.MeshStandardMaterial({ color: '#617b54' }));
      tree.castShadow = true;
      tree.receiveShadow = true;
      tree.position.set(x, size + .25, z);
      tree.scale.set(.68, .95, .68);
      scene.add(tree);
    }
    draw.current = () => {
      const { clientWidth: width, clientHeight: height } = el;
      if (!width || !height) return;
      const span = Math.max(8, 13.6 * height / width);
      camera.left = -span * width / height / 2;
      camera.right = -camera.left;
      camera.top = span / 2;
      camera.bottom = -camera.top;
      camera.updateProjectionMatrix();
      const { yaw, height: elevation } = orbit.current;
      camera.position.set(Math.sin(yaw) * 11, elevation, Math.cos(yaw) * 11);
      camera.lookAt(0, .2, 0);
      camera.updateMatrixWorld();
      renderer.setSize(width, height, false);
      renderer.render(scene, camera);
      for (const { id, point } of spots) {
        const label = labels.current[id];
        if (!label) continue;
        const projected = new THREE.Vector3(...point).project(camera);
        label.style.left = `${(projected.x + 1) * 50}%`;
        label.style.top = `${(1 - projected.y) * 50}%`;
      }
    };
    const resize = new ResizeObserver(() => draw.current());
    const onLost = (event: Event) => { event.preventDefault(); setUnavailable(true); };
    canvas.addEventListener('webglcontextlost', onLost);
    resize.observe(el);
    draw.current();
    return () => {
      resize.disconnect();
      canvas.removeEventListener('webglcontextlost', onLost);
      scene.traverse((node) => {
        if (node instanceof THREE.Mesh) { node.geometry.dispose(); node.material.dispose(); }
      });
      signTexture.dispose();
      renderer.dispose();
      canvas.remove();
      draw.current = () => {};
    };
  }, [name]);
  useEffect(() => draw.current(), [active, enabled, showPlan]);

  return <div className="ll-model">
    <div className="ll-model-bar"><span><small>ARCHITECTURAL MODEL</small><strong>{name}</strong></span>
      {!unavailable && <div><button type="button" aria-pressed={plan} onClick={() => { setPlan(!plan); setExploring(false); }}><Layers2 size={15} /> {plan ? '3D model' : 'Floor plan'}</button>{!plan && <><button className="ll-model-explore"  type="button" onClick={() => setExploring(!exploring)} aria-pressed={exploring}>{exploring ? 'Done exploring' : 'Explore in 3D'}</button><button type="button" onClick={() => { orbit.current = { yaw: .65, height: 7.7 }; draw.current(); }}><RotateCcw size={15} /> Reset view</button></>}</div>}
    </div>
    <div className={`ll-model-stage ${exploring ? 'is-exploring' : ''}`} onPointerDown={(event) => {
      if (showPlan || (event.target as HTMLElement).closest('button') || (event.pointerType !== 'mouse' && !exploring)) return;
      drag.current = { x: event.clientX, y: event.clientY };
      event.currentTarget.setPointerCapture(event.pointerId);
    }} onPointerMove={(event) => {
      if (!drag.current) return;
      orbit.current.yaw = Math.min(1.18, Math.max(-.15, orbit.current.yaw + (event.clientX - drag.current.x) * .006));
      orbit.current.height = Math.min(11, Math.max(5, orbit.current.height + (event.clientY - drag.current.y) * .04));
      drag.current = { x: event.clientX, y: event.clientY };
      draw.current();
    }} onLostPointerCapture={() => { drag.current = null; }}>
      <div ref={mount} className="ll-model-webgl" hidden={showPlan} />
      {showPlan && <div className="ll-model-fallback" aria-label="Illustrated building floor plan">{spots.filter(({ id }) => enabled.includes(id)).map(({ id, label }) => <button type="button" key={id} aria-pressed={active === id} onClick={() => select(id)}><small>{String(spots.findIndex((spot) => spot.id === id) + 1).padStart(2, '0')}</small>{label}</button>)}</div>}
      {!showPlan && spots.filter(({ id }) => enabled.includes(id)).map(({ id, label }) => <button className="ll-model-pin" key={id} ref={(el) => { labels.current[id] = el; }} aria-label={label} aria-pressed={id === active} onClick={() => select(id)}>{spots.findIndex((spot) => spot.id === id) + 1}</button>)}
    </div>
    <div className="ll-model-footer"><p className="ll-model-hint">{showPlan ? 'Choose a space to see what’s there.' : 'Drag to rotate, or choose a marker to explore.'}</p>{!showPlan && <div className="ll-camera-buttons"><button type="button" aria-label="Rotate left" onClick={() => rotate(-.2)}><ChevronLeft size={19} /></button><button type="button" aria-label="Rotate right" onClick={() => rotate(.2)}><ChevronRight size={19} /></button></div>}</div>
  </div>;
}
