import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ChevronLeft, ChevronRight, Flame, PartyPopper, Waves } from 'lucide-react';

export const amenityOptions = [
  { id: 'party_room', label: 'Party room', icon: PartyPopper, description: 'Get together indoors.' },
  { id: 'pool_area', label: 'Pool area', icon: Waves, description: 'Reserve time by the pool.' },
  { id: 'bbq_area', label: 'BBQ area', icon: Flame, description: 'Save a spot for a cookout.' },
] as const;
type Amenity = typeof amenityOptions[number]['id'];
type Slot = { amenity: Amenity; day: string; slot: number };
export type Booking = Slot & { id?: string };
const slots = ['9 am – noon', 'Noon – 3 pm', '3 – 6 pm', '6 – 9 pm'];
const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export function localDay(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}
function offsetDay(day: string, offset: number) {
  const date = new Date(`${day}T12:00:00`);
  date.setDate(date.getDate() + offset);
  return localDay(date);
}

export function demoBookings(today: string): Booking[] {
  return [
    { amenity: 'party_room', day: offsetDay(today, 1), slot: 3 },
    { amenity: 'party_room', day: offsetDay(today, 4), slot: 1 },
    { amenity: 'pool_area', day: offsetDay(today, 1), slot: 2 },
    { amenity: 'bbq_area', day: offsetDay(today, 2), slot: 2 },
  ];
}

async function api(url: string, options?: RequestInit) {
  const response = await fetch(url, options);
  if (!response.ok) {
    const error = await response.json().catch(() => null);
    throw new Error(error?.error || 'The calendar could not complete your request.');
  }
  return response;
}

export default function Amenities({ propertyId, membershipId, demo }: {
  propertyId?: string;
  membershipId?: string;
  demo?: { bookings: Booking[]; reserve: (slot: Slot) => void; cancel: (id: string) => void };
}) {
  const localToday = localDay();
  const [month, setMonth] = useState(localToday.slice(0, 7));
  const [day, setDay] = useState(localToday);
  const [selected, setSelected] = useState<Amenity>('party_room');
  const [choice, setChoice] = useState<number | null>(null);
  const [canceling, setCanceling] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const endpoint = `/api/amenities/${propertyId}`;
  const query = useQuery({
    queryKey: ['amenities', propertyId, membershipId, month],
    enabled: !demo && !!propertyId,
    queryFn: async (): Promise<{ amenities: Amenity[]; bookings: Booking[]; today: string; hour: number; timeZone: string }> =>
      (await api(`${endpoint}?month=${month}`)).json(),
  });
  const bookings = demo?.bookings ?? query.data?.bookings ?? [];
  const availableAmenities = amenityOptions.filter(({ id }) =>
    demo || query.data?.amenities.includes(id) || bookings.some((item) => item.amenity === id && item.id),
  );
  const active = availableAmenities.find(({ id }) => id === selected) ?? availableAmenities[0];
  const today = query.data?.today ?? localToday;
  const hour = query.data?.hour ?? new Date().getHours();
  const lastDay = offsetDay(today, 90);
  const first = new Date(`${month}-01T12:00:00`);
  const monthLabel = first.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
  const monthLength = new Date(first.getFullYear(), first.getMonth() + 1, 0).getDate();
  const selectedDate = new Date(`${day}T12:00:00`).toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' });
  const enabled = !!active && (!!demo || !!query.data?.amenities.includes(active.id));

  function resetChoice() { setChoice(null); setCanceling(null); setMessage(''); setError(''); }
  function changeMonth(offset: number) {
    const date = new Date(first);
    date.setMonth(date.getMonth() + offset);
    const next = localDay(date);
    setMonth(next.slice(0, 7));
    setDay(next.slice(0, 7) === today.slice(0, 7) ? today : next);
    resetChoice();
  }

  async function confirm(slot?: number, bookingId?: string) {
    if (busy || !active) return;
    setBusy(true);
    setError('');
    setMessage('');
    try {
      if (bookingId) {
        if (demo) demo.cancel(bookingId);
        else await api(`${endpoint}/${bookingId}`, { method: 'DELETE' });
      } else if (slot !== undefined) {
        const reservation = { amenity: active.id, day, slot };
        if (demo) demo.reserve(reservation);
        else await api(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(reservation) });
      }
      setChoice(null);
      setCanceling(null);
      setMessage(bookingId ? 'Reservation canceled.' : `${active.label} reserved for ${selectedDate}.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Please try again.');
    } finally {
      if (!demo) await query.refetch();
      setBusy(false);
    }
  }

  return <section className="ll-amenities" aria-label="Amenities calendar">
    {query.isLoading && <p role="status">Loading the calendar…</p>}
    {query.isError && <p role="alert">Couldn’t load the calendar. <button type="button" className="ll-link" onClick={() => void query.refetch()}>Try again</button></p>}
    {!query.isLoading && !query.isError && !active && <div className="ll-card ll-empty">Your building hasn’t opened any amenities for reservations yet.</div>}
    {active && <>
      <div className="ll-amenity-picker" role="group" aria-label="Choose an amenity">
        {availableAmenities.map(({ id, label, description, icon: Icon }) =>
          <button type="button" key={id} disabled={busy} aria-pressed={active.id === id} onClick={() => { setSelected(id); resetChoice(); }}>
            <span className="ll-amenity-icon"><Icon size={23} /></span><span><strong>{label}</strong><small>{description}</small></span>
          </button>,
        )}
      </div>
      <div className="ll-amenity-layout">
        <div className="ll-card ll-calendar">
          <div className="ll-row ll-between ll-calendar-head">
            <button type="button" className="ll-icon-btn" aria-label="Previous month" disabled={busy || month <= today.slice(0, 7)} onClick={() => changeMonth(-1)}><ChevronLeft size={18} /></button>
            <h2 aria-live="polite">{monthLabel}</h2>
            <button type="button" className="ll-icon-btn" aria-label="Next month" disabled={busy || month >= lastDay.slice(0, 7)} onClick={() => changeMonth(1)}><ChevronRight size={18} /></button>
          </div>
          <div className="ll-calendar-days">
            {days.map((name) => <span className="ll-calendar-weekday" key={name}>{name}</span>)}
            {Array.from({ length: first.getDay() }, (_, index) => <span key={`blank-${index}`} aria-hidden="true" />)}
            {Array.from({ length: monthLength }, (_, index) => {
              const cell = `${month}-${String(index + 1).padStart(2, '0')}`;
              const count = bookings.filter((item) => item.amenity === active.id && item.day === cell).length;
              return <button type="button" key={cell} disabled={busy || cell < today || cell > lastDay}
                aria-pressed={cell === day} aria-current={cell === today ? 'date' : undefined}
                aria-label={`${new Date(cell + 'T12:00:00').toLocaleDateString(undefined, { month: 'long', day: 'numeric' })}, ${count} booked ${count === 1 ? 'slot' : 'slots'}`}
                onClick={() => { setDay(cell); resetChoice(); }}>
                {index + 1}{count > 0 && <span aria-hidden="true" className="ll-calendar-dot" />}
              </button>;
            })}
          </div>
          <p className="ll-copy ll-calendar-legend"><span className="ll-calendar-dot" /> At least one time booked</p>
        </div>
        <div className="ll-card ll-calendar-times">
          <p className="ll-kicker">{active.label}</p>
          <h2>{selectedDate}</h2>
          <p className="ll-copy">{demo ? 'Demo availability' : `Building time · ${query.data?.timeZone ?? 'UTC'}`}</p>
          {message && <p role="status" className="ll-maintenance-message">{message}</p>}
          {error && <p role="alert" className="ll-error">{error}</p>}
          {slots.map((label, slot) => {
            const booking = bookings.find((item) => item.amenity === active.id && item.day === day && item.slot === slot);
            const past = day < today || (day === today && 9 + slot * 3 <= hour);
            const selectable = !booking && !past && day <= lastDay && enabled;
            return <div key={label} className="ll-calendar-slot">
              <div><strong>{label}</strong><small>{booking?.id ? 'Your reservation' : booking ? 'Booked' : past ? 'Past time' : enabled ? 'Available' : 'Unavailable'}</small></div>
              {booking?.id && !past && (canceling === booking.id
                ? <button type="button" className="ll-btn secondary" disabled={busy} onClick={() => void confirm(undefined, booking.id)}>Confirm cancellation</button>
                : <button type="button" className="ll-btn secondary" disabled={busy} onClick={() => { resetChoice(); setCanceling(booking.id!); }}>Cancel</button>)}
              {selectable && (choice === slot
                ? <button type="button" className="ll-btn" disabled={busy} onClick={() => void confirm(slot)}>Confirm reservation</button>
                : <button type="button" className="ll-btn secondary" disabled={busy} onClick={() => { resetChoice(); setChoice(slot); }}>Select</button>)}
            </div>;
          })}
          {(choice !== null || canceling) && <button type="button" disabled={busy} className="ll-link ll-calendar-back" onClick={resetChoice}>Go back</button>}
        </div>
      </div>
    </>}
  </section>;
}
