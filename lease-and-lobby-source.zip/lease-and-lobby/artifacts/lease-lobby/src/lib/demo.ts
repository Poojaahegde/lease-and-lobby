function demoEventDate(daysAhead: number, hour: number) {
  const date = new Date();
  date.setDate(date.getDate() + daysAhead);
  date.setHours(hour, 0, 0, 0);
  return date.toISOString();
}

export const demoSnapshot = {
    mode: "demo",
    session: {
      user: {
        id: "demo-maya",
        email: "maya@example.test",
        displayName: "Maya Chen",
        emailVerified: true,
      },
      memberships: [{
        id: "demo-resident",
        propertyId: "willow-court-demo",
        propertyName: "Willow Court",
        unitId: "demo-unit-3b",
        unitLabel: "Apartment 3B",
        householdId: "demo-household",
        role: "resident",
        active: true,
      }],
      setupAvailable: false,
    },
    property: {
      id: "willow-court-demo",
      name: "Willow Court",
      address: "48 Garden Street",
      city: "Portland",
      region: "OR",
      postalCode: "97205",
      description: "A friendly apartment community in the heart of Portland.",
      coverPhotoPath: null,
      published: true,
    },
    membership: {
      id: "demo-resident",
      propertyId: "willow-court-demo",
      propertyName: "Willow Court",
      unitId: "demo-unit-3b",
      unitLabel: "Apartment 3B",
      householdId: "demo-household",
      role: "resident",
      active: true,
    },
    unit: { id: "demo-unit-3b", label: "Apartment 3B" },
    rent: {
      balanceCents: 214500,
      dueDate: "2026-11-01",
      status: "due",
      lastMonthCents: 210000,
      charges: [
        { label: "November base rent", amountCents: 210000 },
        { label: "Utility charge", amountCents: 4500 },
      ],
    },
    lease: {
      startDate: "2026-12-01",
      endDate: "2027-11-30",
      monthlyRentCents: 214500,
      proposedRentCents: 214500,
      renewalDeadline: "2026-11-15",
      renewalStatus: "pending",
    },
    documents: [{
      id: "demo-insurance",
      title: "Proof of renters insurance",
      category: "insurance",
      status: "needs_replacement",
      reason: "The policy expiration date is missing.",
      expiresAt: null,
    }],
    notices: [
      { id: "demo-notice-urgent", title: "Water service interruption", summary: "Water will be briefly off in the east wing tomorrow, 10–11 AM, for scheduled maintenance.", urgent: true, publishedAt: new Date().toISOString(), sender: "From management" },
      { id: "demo-notice-routine", title: "Package room hours updated", summary: "The package room is now open until 8 PM on weekdays.", urgent: false, publishedAt: "2026-10-24T12:00:00.000Z", sender: "From management" },
    ],
    events: [
      { id: "demo-courtyard-tea", title: "Courtyard tea", description: "Bring a mug and catch up with your neighbors by the garden.", startsAt: demoEventDate(3, 15), location: "Courtyard", status: "approved", attendeeCount: 3, isGoing: false },
      { id: "demo-game-night", title: "Game night", description: "Bring a favorite game or just come by.", startsAt: demoEventDate(5, 19), location: "Community room", status: "approved", attendeeCount: 4, isGoing: false },
    ],
    listings: [{ id: "demo-oak-desk", title: "Oak desk", description: "Good condition · pickup in the lobby", priceCents: 3000, status: "available" }],
    gallery: [],
    managerQueue: [],
    invitations: [],
    settings: { eventsEnabled: true, marketplaceEnabled: true, residentPostingEnabled: true, eventApprovalRequired: false },
  } as const;
