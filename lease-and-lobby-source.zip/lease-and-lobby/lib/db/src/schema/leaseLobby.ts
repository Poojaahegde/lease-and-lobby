import {
  customType,
  boolean,
  date,
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

const bytea = customType<{ data: Buffer }>({ dataType: () => "bytea" });

export type PropertySettings = {
  eventsEnabled: boolean;
  marketplaceEnabled: boolean;
  residentPostingEnabled: boolean;
  eventApprovalRequired: boolean;
  amenities?: ("party_room" | "pool_area" | "bbq_area")[];
  amenityTimeZone?: string;
};

export const properties = pgTable("ll_properties", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  region: text("region").notNull(),
  postalCode: text("postal_code").notNull(),
  description: text("description").notNull().default(""),
  coverPhotoPath: text("cover_photo_path"),
  draftData: jsonb("draft_data").$type<Record<string, unknown>>().notNull().default({}),
  settings: jsonb("settings").$type<PropertySettings>().notNull().default({
    eventsEnabled: true,
    marketplaceEnabled: true,
    residentPostingEnabled: true,
    eventApprovalRequired: false,
  }),
  published: boolean("published").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const units = pgTable(
  "ll_units",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    propertyId: uuid("property_id").notNull().references(() => properties.id, { onDelete: "cascade" }),
    label: text("label").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("ll_units_property_label_idx").on(table.propertyId, table.label)],
);

export const households = pgTable(
  "ll_households",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    propertyId: uuid("property_id").notNull().references(() => properties.id, { onDelete: "cascade" }),
    unitId: uuid("unit_id").notNull().references(() => units.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("ll_households_unit_idx").on(table.unitId)],
);

export const memberships = pgTable(
  "ll_memberships",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: text("user_id").notNull(),
    email: text("email").notNull(),
    displayName: text("display_name").notNull().default(""),
    propertyId: uuid("property_id").notNull().references(() => properties.id, { onDelete: "cascade" }),
    unitId: uuid("unit_id").references(() => units.id, { onDelete: "set null" }),
    householdId: uuid("household_id").references(() => households.id, { onDelete: "set null" }),
    role: text("role", { enum: ["building_owner", "building_manager", "resident"] }).notNull(),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("ll_memberships_property_user_role_idx").on(table.propertyId, table.userId, table.role),
    index("ll_memberships_user_active_idx").on(table.userId, table.active),
    index("ll_memberships_property_role_active_idx").on(table.propertyId, table.role, table.active),
  ],
);

export const invitations = pgTable(
  "ll_invitations",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    tokenHash: text("token_hash").notNull().unique(),
    propertyId: uuid("property_id").notNull().references(() => properties.id, { onDelete: "cascade" }),
    unitId: uuid("unit_id").notNull().references(() => units.id, { onDelete: "cascade" }),
    householdId: uuid("household_id").notNull().references(() => households.id, { onDelete: "cascade" }),
    email: text("email").notNull(),
    role: text("role", { enum: ["resident"] }).notNull().default("resident"),
    status: text("status", { enum: ["pending", "accepted", "expired", "revoked"] }).notNull().default("pending"),
    invitedBy: uuid("invited_by").notNull().references(() => memberships.id),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    acceptedAt: timestamp("accepted_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("ll_invitations_property_status_idx").on(table.propertyId, table.status),
    index("ll_invitations_email_idx").on(table.email),
  ],
);

export const staffInvitations = pgTable(
  "ll_staff_invitations",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    tokenHash: text("token_hash").notNull().unique(),
    propertyId: uuid("property_id").notNull().references(() => properties.id, { onDelete: "cascade" }),
    email: text("email").notNull(),
    role: text("role", { enum: ["building_owner", "building_manager"] }).notNull(),
    status: text("status", { enum: ["pending", "accepted", "expired", "revoked"] }).notNull().default("pending"),
    invitedBy: uuid("invited_by").notNull().references(() => memberships.id),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    acceptedAt: timestamp("accepted_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("ll_staff_invitations_property_status_idx").on(table.propertyId, table.status)],
);

export const rentAccounts = pgTable(
  "ll_rent_accounts",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    propertyId: uuid("property_id").notNull().references(() => properties.id, { onDelete: "cascade" }),
    householdId: uuid("household_id").notNull().references(() => households.id, { onDelete: "cascade" }),
    balanceCents: integer("balance_cents").notNull().default(0),
    lastMonthCents: integer("last_month_cents").notNull().default(0),
    dueDate: date("due_date").notNull(),
    status: text("status", { enum: ["due", "pending", "paid"] }).notNull().default("due"),
    charges: jsonb("charges").$type<Array<{ label: string; amountCents: number; statementPath?: string }>>().notNull().default([]),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("ll_rent_accounts_household_idx").on(table.householdId)],
);

export const payments = pgTable(
  "ll_payments",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    rentAccountId: uuid("rent_account_id").notNull().references(() => rentAccounts.id, { onDelete: "cascade" }),
    amountCents: integer("amount_cents").notNull(),
    status: text("status", { enum: ["pending", "confirmed", "failed"] }).notNull().default("pending"),
    methodLabel: text("method_label").notNull().default("Demo payment"),
    createdByUserId: text("created_by_user_id").notNull(),
    confirmedByMembershipId: uuid("confirmed_by_membership_id").references(() => memberships.id),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    confirmedAt: timestamp("confirmed_at", { withTimezone: true }),
  },
  (table) => [index("ll_payments_account_status_idx").on(table.rentAccountId, table.status)],
);

export const leases = pgTable(
  "ll_leases",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    propertyId: uuid("property_id").notNull().references(() => properties.id, { onDelete: "cascade" }),
    householdId: uuid("household_id").notNull().references(() => households.id, { onDelete: "cascade" }),
    startDate: date("start_date").notNull(),
    endDate: date("end_date").notNull(),
    monthlyRentCents: integer("monthly_rent_cents").notNull(),
    proposedRentCents: integer("proposed_rent_cents"),
    renewalDeadline: date("renewal_deadline"),
    renewalStatus: text("renewal_status", { enum: ["not_offered", "pending", "accepted", "declined"] }).notNull().default("not_offered"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("ll_leases_household_idx").on(table.householdId)],
);

export const documents = pgTable(
  "ll_documents",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    propertyId: uuid("property_id").notNull().references(() => properties.id, { onDelete: "cascade" }),
    householdId: uuid("household_id").notNull().references(() => households.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    category: text("category").notNull(),
    status: text("status", { enum: ["requested", "received", "under_review", "accepted", "needs_replacement"] }).notNull().default("requested"),
    reason: text("reason").notNull().default(""),
    objectPath: text("object_path"),
    expiresAt: date("expires_at"),
    submittedAt: timestamp("submitted_at", { withTimezone: true }),
    reviewedByMembershipId: uuid("reviewed_by_membership_id").references(() => memberships.id),
    reviewMessage: text("review_message"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("ll_documents_household_status_idx").on(table.householdId, table.status)],
);

export const chargeQuestions = pgTable(
  "ll_charge_questions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    propertyId: uuid("property_id").notNull().references(() => properties.id, { onDelete: "cascade" }),
    rentAccountId: uuid("rent_account_id").notNull().references(() => rentAccounts.id, { onDelete: "cascade" }),
    householdId: uuid("household_id").notNull().references(() => households.id, { onDelete: "cascade" }),
    askedByUserId: text("asked_by_user_id").notNull(),
    chargeLabel: text("charge_label").notNull(),
    question: text("question").notNull(),
    reply: text("reply"),
    status: text("status", { enum: ["open", "answered", "closed"] }).notNull().default("open"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    repliedAt: timestamp("replied_at", { withTimezone: true }),
  },
  (table) => [index("ll_charge_questions_property_status_idx").on(table.propertyId, table.status)],
);

export const notices = pgTable(
  "ll_notices",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    propertyId: uuid("property_id").notNull().references(() => properties.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    summary: text("summary").notNull(),
    urgent: boolean("urgent").notNull().default(false),
    publishedAt: timestamp("published_at", { withTimezone: true }),
    createdByMembershipId: uuid("created_by_membership_id").notNull().references(() => memberships.id),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("ll_notices_property_published_idx").on(table.propertyId, table.publishedAt)],
);

export const events = pgTable(
  "ll_events",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    propertyId: uuid("property_id").notNull().references(() => properties.id, { onDelete: "cascade" }),
    hostMembershipId: uuid("host_membership_id").notNull().references(() => memberships.id),
    title: text("title").notNull(),
    description: text("description").notNull().default(""),
    startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
    location: text("location").notNull(),
    capacity: integer("capacity"),
    status: text("status", { enum: ["pending", "approved", "rejected", "cancelled"] }).notNull().default("approved"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("ll_events_property_status_starts_idx").on(table.propertyId, table.status, table.startsAt)],
);

export const eventRsvps = pgTable(
  "ll_event_rsvps",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    eventId: uuid("event_id").notNull().references(() => events.id, { onDelete: "cascade" }),
    membershipId: uuid("membership_id").notNull().references(() => memberships.id, { onDelete: "cascade" }),
    status: text("status", { enum: ["going", "cancelled"] }).notNull().default("going"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("ll_event_rsvps_event_member_idx").on(table.eventId, table.membershipId)],
);

export const listings = pgTable(
  "ll_listings",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    propertyId: uuid("property_id").notNull().references(() => properties.id, { onDelete: "cascade" }),
    ownerMembershipId: uuid("owner_membership_id").notNull().references(() => memberships.id),
    title: text("title").notNull(),
    description: text("description").notNull().default(""),
    condition: text("condition").notNull().default("good"),
    priceCents: integer("price_cents"),
    status: text("status", { enum: ["available", "reserved", "sold"] }).notNull().default("available"),
    imagePath: text("image_path"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("ll_listings_property_status_idx").on(table.propertyId, table.status)],
);

export const listingMessages = pgTable(
  "ll_listing_messages",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    listingId: uuid("listing_id").notNull().references(() => listings.id, { onDelete: "cascade" }),
    senderMembershipId: uuid("sender_membership_id").notNull().references(() => memberships.id, { onDelete: "cascade" }),
    recipientMembershipId: uuid("recipient_membership_id").notNull().references(() => memberships.id, { onDelete: "cascade" }),
    body: text("body").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("ll_listing_messages_participants_idx").on(table.listingId, table.senderMembershipId, table.recipientMembershipId)],
);

export const contentReports = pgTable(
  "ll_content_reports",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    propertyId: uuid("property_id").notNull().references(() => properties.id, { onDelete: "cascade" }),
    reporterMembershipId: uuid("reporter_membership_id").notNull().references(() => memberships.id),
    contentType: text("content_type", { enum: ["event", "listing"] }).notNull(),
    contentId: uuid("content_id").notNull(),
    reason: text("reason").notNull(),
    status: text("status", { enum: ["open", "reviewed", "dismissed"] }).notNull().default("open"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("ll_content_reports_property_status_idx").on(table.propertyId, table.status)],
);

export const propertyPhotos = pgTable(
  "ll_property_photos",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    propertyId: uuid("property_id").notNull().references(() => properties.id, { onDelete: "cascade" }),
    objectPath: text("object_path").notNull(),
    location: text("location", { enum: ["entrance", "leasing_desk", "noticeboard", "community_room", "courtyard", "swap_shelf", "gallery"] }).notNull().default("gallery"),
    caption: text("caption").notNull().default(""),
    altText: text("alt_text").notNull(),
    sortIndex: integer("sort_index").notNull().default(0),
    published: boolean("published").notNull().default(false),
    uploadedByMembershipId: uuid("uploaded_by_membership_id").notNull().references(() => memberships.id),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("ll_property_photos_property_published_idx").on(table.propertyId, table.published, table.sortIndex)],
);

export const rentStatements = pgTable(
  "ll_rent_statements",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    rentAccountId: uuid("rent_account_id").notNull().references(() => rentAccounts.id, { onDelete: "cascade" }),
    label: text("label").notNull(),
    statementDate: date("statement_date").notNull(),
    objectPath: text("object_path"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("ll_rent_statements_account_date_idx").on(table.rentAccountId, table.statementDate)],
);

// The bytes stay private and share the database's durability and backup policy.
export const portalUploads = pgTable("ll_portal_uploads", {
  id: uuid("id").defaultRandom().primaryKey(),
  propertyId: uuid("property_id").notNull().references(() => properties.id, { onDelete: "cascade" }),
  membershipId: uuid("membership_id").notNull().references(() => memberships.id),
  purpose: text("purpose", { enum: ["property_photo", "resident_document", "maintenance_photo", "requested_document"] }).notNull(),
  contentType: text("content_type").notNull(),
  size: integer("size").notNull(),
  data: bytea("data"),
  attached: boolean("attached").notNull().default(false),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});

export const maintenanceRequests = pgTable("ll_maintenance_requests", {
  id: uuid("id").primaryKey(),
  propertyId: uuid("property_id").notNull().references(() => properties.id, { onDelete: "cascade" }),
  householdId: uuid("household_id").notNull().references(() => households.id, { onDelete: "cascade" }),
  unitId: uuid("unit_id").notNull().references(() => units.id, { onDelete: "cascade" }),
  submittedBy: uuid("submitted_by").references(() => memberships.id, { onDelete: "set null" }),
  kind: text("kind", { enum: ["maintenance", "complaint", "document"] }).notNull().default("maintenance"),
  category: text("category").notNull(),
  issue: text("issue").notNull(),
  location: text("location").notNull(),
  description: text("description").notNull(),
  priority: text("priority", { enum: ["routine", "low", "medium", "high", "urgent"] }).notNull(),
  entryAllowed: boolean("entry_allowed").notNull(),
  accessInstructions: text("access_instructions").notNull(),
  photoId: uuid("photo_id").references(() => portalUploads.id, { onDelete: "set null" }),
  documentId: uuid("document_id").references(() => portalUploads.id, { onDelete: "set null" }),
  managementResponse: text("management_response"),
  status: text("status", { enum: ["submitted", "in_progress", "completed"] }).notNull().default("submitted"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("ll_maintenance_property_created_idx").on(table.propertyId, table.createdAt),
  index("ll_maintenance_household_created_idx").on(table.householdId, table.createdAt),
]);

export const amenityBookings = pgTable("ll_amenity_bookings", {
  id: uuid("id").defaultRandom().primaryKey(),
  propertyId: uuid("property_id").notNull().references(() => properties.id, { onDelete: "cascade" }),
  membershipId: uuid("membership_id").references(() => memberships.id, { onDelete: "set null" }),
  amenity: text("amenity", { enum: ["party_room", "pool_area", "bbq_area"] }).notNull(),
  day: date("day").notNull(),
  slot: integer("slot").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  uniqueIndex("ll_amenity_booking_slot_idx").on(table.propertyId, table.amenity, table.day, table.slot),
]);
