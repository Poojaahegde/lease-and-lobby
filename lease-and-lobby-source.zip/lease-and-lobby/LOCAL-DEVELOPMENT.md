# Lease & Lobby locally

Use Node 24 and pnpm. Install the locked workspace dependencies with `pnpm install --frozen-lockfile`.

Start the UI with `PORT=4173 BASE_PATH=/ pnpm --filter @workspace/lease-lobby exec vite --host 127.0.0.1`. Open `http://127.0.0.1:4173/demo` for Willow Court. It uses fictional data in browser memory. Reloading resets the demo. The role menu changes the sample view.

## Private portal

Use a separate development PostgreSQL database and Clerk instance. Set `DATABASE_URL`, `CLERK_SECRET_KEY`, `CLERK_PUBLISHABLE_KEY`, `LEASE_LOBBY_SETUP_EMAIL`, and `LEASE_LOBBY_ORIGIN=http://127.0.0.1:4173` in the API environment. Set `VITE_CLERK_PUBLISHABLE_KEY` in the web app environment. Do not place the secret key or database connection string in the web environment. Run `pnpm --filter @workspace/db run push` against the development database, then run `PORT=8787 pnpm --filter @workspace/api-server run dev`. The Vite server proxies `/api` to port 8787. Production needs a same-origin API route and its own values. Set `LEASE_LOBBY_ORIGIN` to the exact public HTTPS origin, with no path or query. The API uses this origin to validate browser requests and Clerk sessions. Keep the Clerk secret and database URL in server environment variables. `VITE_CLERK_PUBLISHABLE_KEY` is the public browser key. Configure request and upload rate limits at your hosting edge before exposing the production API.

Use the verified Clerk account that matches the configured setup email to create the first building. Create and verify the staff account in Clerk before assigning the manager by email. Sign in as that manager to create an invitation and copy the link. Resident invitation email delivery is not configured. Use separate browser profiles for each role when testing.

New private uploads use PostgreSQL. Existing files stored by Replit need a separate data migration. The export did not contain hosted database records or private files.

## Rent system integration

A future authorized Yardi integration would need stable property, unit, household, lease, resident, and charge identifiers, balance snapshots with an effective time, itemized charges, due dates, statements, payment status and receipt references, document requests, and renewal terms and deadlines. Keep reads scoped to the assigned household. Reconcile payment events with idempotent provider references before updating balances. The demo uses fictional records and simulated payments. The private portal has no live payment collection or signing integration.

Maintenance requests use the `ll_maintenance_requests` table. Run the database schema update described above before starting a configured private portal. Residents can submit and view requests for their assigned household. Managers and owners can review and update requests for their property. Demo requests and photos are held in the browser tab.
The maintenance schema also stores complaints with a separate record type. Apply the schema update to add the complaint type and management response columns to existing installs. Complaints go to the management inbox. Authorized staff can share a response and update the status. The submitting resident and authorized staff for that property can read the latest response in the portal, including after completion.

The amenities calendar uses the `ll_amenity_bookings` table. Apply the schema update, then enable the spaces your building offers under **Building settings** and set its time zone. The calendar uses four three-hour slots per day, starting at 9 am in building time. Other residents see occupied slots without the booker's identity.

Document requests also use `ll_maintenance_requests`. Apply the schema update before using the live inbox. Staff can attach a PDF to an open request. The requested PDF is accessible to the requesting resident and authorized staff for the property.
